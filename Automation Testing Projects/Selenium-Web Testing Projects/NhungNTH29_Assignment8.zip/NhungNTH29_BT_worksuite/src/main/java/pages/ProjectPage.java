package pages;

import core.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.List;

public class ProjectPage extends BasePage {
    public ProjectPage(WebDriver webDriver) {
        super(webDriver);
    }
    @FindBy(xpath = "//input[@id=\"search-text-field\"]")
    private WebElement searchInput;
    @FindBy(xpath = "((//tbody//tr)[1]//td)[4]//a")
    private WebElement searchResult;
    @FindBy(xpath = "(//span[text()=\"Members\"]//..)[1]")
    private WebElement memberButton;
    @FindBy(xpath = "//tbody//tr")
    private List<WebElement> listMem;
    @FindBy(xpath = "(//p[@class=\"f-15 mb-0\"])[1]")
    private WebElement startDate;
    @FindBy(xpath = "(//p[@class=\"f-15 mb-0\"])[2]")
    private WebElement endDate;
    @FindBy(xpath = "//a[@class=\"text-dark\"]")
    private WebElement client;

    @FindBy(xpath = "//h5[contains(text(),\"Project Budget\")]")
    private WebElement projectBudget;
    @FindBy(xpath = "//h5[contains(text(),\"Earning\")]")
    private WebElement earning;
    @FindBy(xpath = "//h5[contains(text(),\"Hours\")]")
    private WebElement hourLogger;
    @FindBy(xpath = "//h5[contains(text(),\"Expen\")]")
    private WebElement expense;
    @FindBy(xpath = "//div[@class=\"text-dark-grey mb-0 ql-editor p-0\"]")
    private WebElement projectDetail;
    @FindBy(xpath = "//tbody//tr")
    private List<WebElement> listProject;


    public void searchAndValidate(String searchtxt){
        //Verify: 4. The table displayed 20 Projects: Failed
//        Assert.assertEquals(listProject.size(), 20);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(searchInput)).sendKeys(searchtxt);
        //6. Click to view project
        getWebDriverWait().until(ExpectedConditions.visibilityOf(searchResult)).click();
        //6. Verify: The project detail page displayed:
        //+ Project Progress: Start Date (30-04-2022) and Deadline(30-08-2022)
        //+ Client: General Schroeder IV
        //+ Statistics: Project Budget, Earnings, Hours Logged, Expenses
        Assert.assertEquals(startDate.getText(), "30-04-2022");
        Assert.assertEquals(endDate.getText(), "30-08-2022");
//        Assert.assertEquals(client.getText(), "General Schroeder IV"); //Client: Failed
        getWebDriverWait().until(ExpectedConditions.visibilityOf(projectBudget));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(earning));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(hourLogger));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(expense));
        //Project detail: Failed
//        Assert.assertEquals(projectDetail.getText(), "Similique velit ex soluta et rerum. Sint consequuntur praesentium est ipsa alias vitae magni. Laboriosam ut enim quisquam ad. Reprehenderit voluptatem eaque ut soluta.");
        //7. Click to the Members tab
        getWebDriverWait().until(ExpectedConditions.visibilityOf(memberButton)).click();
        //Verify
        //7. The page display 3 member: Sophia Cole, Prof. Troy Goldner, Dr. Vena Balistreri
        Assert.assertEquals(listMem.size(), 3);

    }
}
