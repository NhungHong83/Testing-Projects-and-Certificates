package pages;

import core.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class HR_EmployeePage extends BasePage {

    public HR_EmployeePage(WebDriver webDriver) {
        super(webDriver);
    }
    @FindBy(xpath = "//button[@data-id=\"designation\"]")
    private WebElement designationSelect;
    @FindBy(xpath = "//a[@id=\"bs-select-2-4\"]")
    private WebElement firstResultTeamleads;
//    @FindBy(xpath = "((//tbody//tr)[1]//td[7]//a)[1]")
    @FindBy(xpath = "((//tbody//tr)[1]//td[7]//div)[1]")

    private WebElement actionFirstResult;
    @FindBy(xpath = "(//a[@class=\"dropdown-item openRightModal\"])[1]")
    private WebElement actionEdit;
    @FindBy(id="name")
    private WebElement empName;
    @FindBy(id="email")
    private WebElement empEmail;
    @FindBy(xpath = "(//label[contains(text(),\"Department\")])[2]/following-sibling::div/descendant::div[@class=\"filter-option-inner-inner\"]")
    private WebElement department;
    @FindBy(xpath = "//input[@id=\"joining_date\"]")
    private WebElement joiningDate;
    @FindBy(xpath = "//input[@id=\"login-yes\"]")
    private WebElement loginYes;
    @FindBy(xpath = "//input[@id=\"notification-yes\"]")
    private WebElement notiYes;
    @FindBy(xpath = "//input[@id=\"status-active\"]")
    private WebElement statusActive;
    @FindBy(xpath = "//input[@id=\"hourly_rate\"]")
    private WebElement hourlyRate;




    public void clickDestinationTeamLead() throws InterruptedException {
        getWebDriverWait().until(ExpectedConditions.visibilityOf(designationSelect)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(firstResultTeamleads)).click();
//        getWebDriverWait().until(ExpectedConditions.visibilityOf(actionFirstResult)).click();
//        Thread.sleep(5000);
    }
    public void verifyEmpDetail(String ename,String email,String departm,String joindate,String login,String noti,String statusAc,String hrate) throws InterruptedException {
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(actionFirstResult)).click();
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(actionEdit)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(empName));
        WebElement namee=getWebDriverWait().until(ExpectedConditions.visibilityOf(empName));
        Assert.assertEquals(namee.getAttribute("value"), ename);
        WebElement emaill=getWebDriverWait().until(ExpectedConditions.visibilityOf(empEmail));
        Assert.assertEquals(emaill.getAttribute("value"), email);

        WebElement departmen=getWebDriverWait().until(ExpectedConditions.visibilityOf(department));
        Assert.assertEquals(departmen.getText(), departm);
        WebElement joinDate=getWebDriverWait().until(ExpectedConditions.visibilityOf(joiningDate));
        Assert.assertEquals(joinDate.getAttribute("value"), joindate);
        WebElement loginyes=getWebDriverWait().until(ExpectedConditions.visibilityOf(loginYes));
        Assert.assertEquals(loginyes.getAttribute("value").equals("enable"), true);
        WebElement notiyes=getWebDriverWait().until(ExpectedConditions.visibilityOf(notiYes));
        Assert.assertEquals(notiyes.getAttribute("value").equals("1"), true);
        WebElement status=getWebDriverWait().until(ExpectedConditions.visibilityOf(statusActive));
        Assert.assertEquals(status.getAttribute("value").equals("active"), true);
        WebElement hourly=getWebDriverWait().until(ExpectedConditions.visibilityOf(hourlyRate));
        Assert.assertEquals(hourly.getAttribute("value"), hrate);
    }
}
