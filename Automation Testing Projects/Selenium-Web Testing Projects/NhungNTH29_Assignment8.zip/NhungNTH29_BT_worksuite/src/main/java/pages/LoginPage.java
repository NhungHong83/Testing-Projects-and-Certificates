package pages;

import core.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends BasePage {

    public LoginPage(WebDriver webDriver) {
        super(webDriver);
    }

    @FindBy(id="email")
    private WebElement email;

    @FindBy(name="password")
    private WebElement password;

    @FindBy(id="submit-login")
    private WebElement loginButton;

    public void navigateTo(String url){
        getWebDriver().get(url);
    }

    public void login(String u, String p){
        WebElement emailElement=getWebDriverWait().until(ExpectedConditions.visibilityOf(email));
        emailElement.clear();
        emailElement.sendKeys(u);
        password.clear();
        password.sendKeys(p);
        loginButton.click();
    }
}
