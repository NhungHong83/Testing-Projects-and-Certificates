package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

public class ClientsPage extends BasePage {
    public ClientsPage(WebDriver webDriver) {
        super(webDriver);
    }
    @FindBy(id="datatableRange")
    private WebElement startDate;
    @FindBy(xpath = "//li[text()=\"Last 6 Months\"]")
    private WebElement lastSixMonth;
    @FindBy(id = "search-text-field")
    private WebElement searchField;
    @FindBy(xpath = "((//tbody//tr)[1]//td[7]//a)[1]")
    private WebElement actionButton;
    @FindBy(xpath = "//a[@class=\"dropdown-item openRightModal\"]")
    private WebElement editButton;

    @FindBy(xpath = "//input[@id=\"name\"]")
    private WebElement clientName;
    @FindBy(xpath = "//input[@id=\"email\"]")
    private WebElement clientEmail;
    @FindBy(xpath = "(//div[@class=\"form-check-inline custom-control custom-radio mt-2 mr-3\"])[3]")
    private WebElement notiYes;
    @FindBy(xpath = "(//div[@class=\"form-check-inline custom-control custom-radio mt-2 mr-3\"])[5]")
    private WebElement statusActive;
    @FindBy(xpath = "//input[@id=\"company_name\"]")
    private WebElement companyname;
    @FindBy(xpath = "//input[@id=\"website\"]")
    private WebElement OfficialWebsite;
    @FindBy(xpath = "(//div[@id=\"table-actions\"]//a)[1]")
    private WebElement addClientButton;
    @FindBy(xpath = "//input[@id=\"name\"]")
    private WebElement nameInput;
    @FindBy(xpath = "//input[@id=\"email\"]")
    private WebElement emailInput;
    @FindBy(xpath = "(//div[@class=\"form-check-inline custom-control custom-radio mt-2 mr-3\"])[3]")
    private WebElement notificationYes;
    @FindBy(xpath = "(//div[@class=\"form-check-inline custom-control custom-radio mt-2 mr-3\"])[1]")
    private WebElement activeYes;
    @FindBy(xpath = "//button[@id=\"save-client-form\"]")
    private WebElement saveButton;
    @FindBy(xpath = "(//div[@class=\"blockUI blockOverlay\"])[1]")
    private WebElement blockOverLay;


    public void verify(String cname,String email, String canNoti,String status, String companyName,String officialWeb){
            WebElement element = getWebDriverWait().until(ExpectedConditions.visibilityOf(clientName));
            Assert.assertEquals(element.getAttribute("value"), cname);
            WebElement element2 = getWebDriverWait().until(ExpectedConditions.visibilityOf(clientEmail));
            Assert.assertEquals(element2.getAttribute("value"), email);
            WebElement eleme = getWebDriverWait().until(ExpectedConditions.visibilityOf(notiYes));
            Assert.assertEquals(eleme.isSelected(), false);
            WebElement element3 = getWebDriverWait().until(ExpectedConditions.visibilityOf(statusActive));
            Assert.assertEquals(element3.isSelected(), false);
            WebElement element4 = getWebDriverWait().until(ExpectedConditions.visibilityOf(companyname));
            Assert.assertEquals(element4.getAttribute("value"), companyName);
            WebElement element5 = getWebDriverWait().until(ExpectedConditions.visibilityOf(OfficialWebsite));
            Assert.assertEquals(element5.getAttribute("value"), officialWeb);
    }

    public void addClient_clickStartDateAndSearch(String cName,String cemail,String ccompanyname,String cowebsite){
        //Add Client
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addClientButton)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(clientName)).sendKeys(cName);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(emailInput)).sendKeys(cemail);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(companyname)).sendKeys(ccompanyname);
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(notificationYes)).click();
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(activeYes)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(OfficialWebsite)).sendKeys(cowebsite);
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(saveButton)).click();
        //clickStartDate
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(blockOverLay));
        WebElement startD=getWebDriverWait().until(ExpectedConditions.visibilityOf(startDate));
        startD.click();
        WebElement selected=getWebDriverWait().until(ExpectedConditions.visibilityOf(lastSixMonth));
        selected.click();
        //Search
        WebElement search=getWebDriverWait().until(ExpectedConditions.visibilityOf(searchField));
        search.sendKeys(cName);
        WebElement action=getWebDriverWait().until(ExpectedConditions.visibilityOf(actionButton));
        action.click();
        WebElement edit=getWebDriverWait().until(ExpectedConditions.visibilityOf(editButton));
        edit.click();
    }
}
