package pages;

import core.BasePage;
import core.BaseTest;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class LeadsPage extends BasePage {
    public LeadsPage(WebDriver webDriver) {
        super(webDriver);
        webDriver.manage().window().maximize();
    }

    @FindBy(id="search-text-field")
    private WebElement searchTextField;

    @FindBy(xpath = "(//tbody//tr)[1]")
    private WebElement firstCol;
    @FindBy(xpath = "((//tbody//tr)[1]//td)[3]//a")
    private WebElement name;

    @FindBy(xpath = "(//p[@class=\"mb-0 f-12 text-dark-grey\"])[2]")
    private WebElement companyName;

    @FindBy(xpath = "(//tr//td)[6]")
    private WebElement created;

    @FindBy(xpath = "(//div[@id=\"table-actions\"]//a)[1]")
    private WebElement addClientButton;
    @FindBy(xpath = "(//div[@id=\"table-actions\"]//a)[1]")
    private WebElement addLeadsButton;
    @FindBy(xpath = "//input[@id=\"client_name\"]")
    private WebElement leadNameInput;
    @FindBy(xpath = "//a[@class=\"text-dark toggle-other-details\"]")
    private WebElement companyDropdown;
    @FindBy(xpath = "//input[@id=\"company_name\"]")
    private WebElement companyNameInput;
    @FindBy(xpath = "//input[@id=\"mobile\"]")
    private WebElement mobileInput;
    @FindBy(xpath = "//button[@id=\"save-lead-form\"]")
    private WebElement saveButton;
    @FindBy(xpath = "//input[@id=\"client_email\"]")
    private WebElement emailInput;
    @FindBy(xpath = "//textarea[@id=\"address\"]")
    private WebElement addressInput;
    @FindBy(xpath = "//select[@id=\"status\"]/following-sibling::button")
    private WebElement statusButton;
    @FindBy(xpath = "(//a[@aria-posinset=\"1\"])[10]//..")
    private WebElement statusValue;
    @FindBy(xpath = "//div[@class=\"row p-20 d-none\"]")
    private WebElement noneCompanyButton;
    @FindBy(xpath = "//a[@class=\"text-dark toggle-other-details\"]")
    private WebElement companyDetailButton;



    public void addAndSearch(String leadname,String companyName, String email, String address) throws InterruptedException {
        //add Lucy Thompson
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addLeadsButton)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(leadNameInput)).sendKeys(leadname);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(emailInput)).sendKeys(email);
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(companyDetailButton)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(companyNameInput)).sendKeys(companyName);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addressInput)).sendKeys(address);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(mobileInput)).sendKeys("123456789");

        getWebDriverWait().until(ExpectedConditions.visibilityOf(saveButton)).click();
        //Search with key: Lucy Thompson
        WebElement searchField=getWebDriverWait().until(ExpectedConditions.visibilityOf(searchTextField));
        searchField.sendKeys(leadname);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(name));
    }
    public void clickFirstResult() throws InterruptedException {
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(name)).click();
    }
    public void verifyLeadsTable(String leadname,String company) throws InterruptedException {
        Thread.sleep(10000);
        WebElement namee = getWebDriverWait().until(ExpectedConditions.visibilityOf(name));
        Assert.assertEquals(namee.getText(), leadname);
        WebElement eleme = getWebDriverWait().until(ExpectedConditions.visibilityOf(companyName));
        Assert.assertEquals(eleme.getText().toLowerCase(), company.toLowerCase());
    }
    @FindBy(xpath = "//span[text()=\"Profile\"]/..")
    private WebElement tabProfile;
    @FindBy(xpath = "//span[text()=\"Files\"]/..")
    private WebElement tabFiles;
    @FindBy(xpath = "//span[text()=\"Follow Up\"]/..")
    private WebElement tabFollowUp;
    @FindBy(xpath = "//span[text()=\"Proposal\"]/..")
    private WebElement tabProposal;
    @FindBy(xpath = "//span[text()=\"Notes\"]/..")
    private WebElement tabNotes;

    @FindBy(xpath = "//p[text()=\"Lead Name\"]//..//p[2]")
    private WebElement leadName;
    @FindBy(xpath = "//p[text()=\"Lead Email\"]//..//p[2]")
    private WebElement leadEmail;
    @FindBy(xpath = "//p[text()=\"Company Name\"]//..//p[2]")
    private WebElement companyLeadName;
    @FindBy(xpath = "//p[text()=\"Address\"]//..//p[2]")
    private WebElement address;
    @FindBy(xpath = "//p[text()=\"Status\"]//..//p[2]")
    private WebElement status;
    public void verifyLeadDetail(String lname, String companyName, String email, String aaddress, String status){
        WebElement leadname = getWebDriverWait().until(ExpectedConditions.visibilityOf(leadName));
        Assert.assertEquals(leadname.getText(), lname);
        WebElement leademail = getWebDriverWait().until(ExpectedConditions.visibilityOf(leadEmail));
        Assert.assertEquals(leademail.getText(), email);
        WebElement element = getWebDriverWait().until(ExpectedConditions.visibilityOf(companyLeadName));
        Assert.assertEquals(element.getText().toLowerCase(), companyName.toLowerCase());
        WebElement addr = getWebDriverWait().until(ExpectedConditions.visibilityOf(address));
        Assert.assertEquals(addr.getText(), aaddress);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(tabProfile));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(tabFiles));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(tabFollowUp));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(tabProposal));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(tabNotes));
    }
}
