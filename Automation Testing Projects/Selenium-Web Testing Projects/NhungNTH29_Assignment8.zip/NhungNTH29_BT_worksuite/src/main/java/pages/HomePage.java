package pages;

import core.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends BasePage {

    public HomePage(WebDriver webDriver) {
        super(webDriver);
    }

    //Menu Left
    @FindBy(xpath = "//a[@title=\"Private Dashboard\"]")
    private WebElement privateDashboard;

    @FindBy(xpath = "//a[@title=\"Advanced Dashboard\"]")
    private WebElement adminDashboard;

    @FindBy(xpath = "//a[@title=\"Leads\"]")
    private WebElement leads;

    @FindBy(xpath = "//a[@title=\"Clients\"]")
    private WebElement clients;

    @FindBy(xpath = "//a[@title=\"HR\"]")
    private WebElement HR;

    @FindBy(xpath = "//a[@title=\"Work\"]")
    private WebElement work;

    @FindBy(xpath = "//a[@title=\"Finance\"]")
    private WebElement finance;

    @FindBy(xpath = "//a[@title=\"Products\"]")
    private WebElement products;

    @FindBy(xpath = "//a[@title=\"Orders\"]")
    private WebElement orders;

    @FindBy(xpath = "//a[@title=\"Tickets\"]")
    private WebElement tickets;

    @FindBy(xpath = "//a[@title=\"Events\"]")
    private WebElement events;

    //Menu top
    @FindBy(xpath = "(//span[text()=\"Overview\"]//..)[1]")
    private WebElement overview;

    @FindBy(xpath = "(//span[text()=\"Project\"]//..)[1]")
    private WebElement project;

    @FindBy(xpath = "(//span[text()=\"Client\"]//..)[1]")
    private WebElement client;

    @FindBy(xpath = "(//span[text()=\"HR\"]//..)[3]")
    private WebElement HR_menuTop;

    @FindBy(xpath = "(//span[text()=\"Ticket\"]//..)[1]")
    private WebElement tickets_menuTop;

    @FindBy(xpath = "(//span[text()=\"Finance\"]//..)[3]")
    private WebElement finance_menuTop;

    //Widget
    @FindBy(xpath = "(//h5[contains(text(),\"Total Clients\")]//..//..//..)[1]")
    private WebElement totalClient;

    @FindBy(xpath = "//h5[contains(text(),\"Total Employees\")]")
    private WebElement totalEmployees;

    @FindBy(xpath = "//h5[contains(text(),\"Total Projects\")]")
    private WebElement totalProjects;

    @FindBy(xpath = "//h5[contains(text(),\"Due Invoices\")]")
    private WebElement dueInvoices;

    @FindBy(xpath = "//h5[contains(text(),\"Hours Logged\")]")
    private WebElement hoursLogged;

    @FindBy(xpath = "//h5[contains(text(),\"Pending Tasks\")]")
    private WebElement pendingTasks;

    @FindBy(xpath = "//h5[contains(text(),\"Today Attendance\")]")
    private WebElement todayAttendance;

    @FindBy(xpath = "//h5[contains(text(),\"Unresolved Tickets\")]")
    private WebElement unresolvedTickets;

    @FindBy(xpath = "//h4[@class=\"f-18 f-w-500 mb-0\"][contains(text(),\"Earnings \")]                                                                                                                                          ")
    private WebElement earnings;

    @FindBy(xpath = "//h4[@class=\"f-18 f-w-500 mb-0\"][contains(text(),\"Time Logs\")]")
    private WebElement timeLogs;

    @FindBy(xpath = "//h4[@class=\"f-18 f-w-500 mb-0\"][contains(text(),\"Pending Leaves\")]")
    private WebElement pendingLeaves;

    @FindBy(xpath = "//h4[@class=\"f-18 f-w-500 mb-0\"][contains(text(),\"Open Tickets\")]")
    private WebElement openTickets;

    @FindBy(xpath = "//h4[@class=\"f-18 f-w-500 mb-0\"][contains(text(),\"Pending FollowUp\")]")
    private WebElement pendingFollowUp;

    @FindBy(xpath = "//h4[@class=\"f-18 f-w-500 mb-0\"][contains(text(),\"Project Activity Timeline\")]")
    private WebElement projectActivityTimeline;

    @FindBy(xpath = "//h4[@class=\"f-18 f-w-500 mb-0\"][contains(text(),\"Project Activity Timeline\")]")
    private WebElement userActivityTimeline;

    @FindBy(xpath = "//a[text()=\"Employees\"]")
    private WebElement employeeButton;

    public void getLeadsScreen(){
        WebElement leadsButton = getWebDriverWait().until(ExpectedConditions.visibilityOf(leads));
        leadsButton.click();
    }
    public void getClientsScreen(){
        WebElement clientsButton = getWebDriverWait().until(ExpectedConditions.visibilityOf(clients));
        clientsButton.click();
    }
    public void getHR_Client_Page(){
        WebElement HRButton = getWebDriverWait().until(ExpectedConditions.visibilityOf(HR));
        HRButton.click();
        WebElement employeeBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(employeeButton));
        employeeBtn.click();
    }
    @FindBy(xpath = "//a[text()=\"Projects\"]")
    private WebElement projectButton;

    public void getWork_Project_Page(){
        WebElement workButton = getWebDriverWait().until(ExpectedConditions.visibilityOf(work));
        workButton.click();
        WebElement projectBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(projectButton));
        projectBtn.click();
    }
    public void verify() {
        getWebDriverWait().until(ExpectedConditions.visibilityOf(privateDashboard));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(adminDashboard));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(leads));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(clients));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(HR));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(work));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(finance));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(products));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(orders));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(tickets));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(events));

        //
        WebElement advanceDashbroad = getWebDriverWait().until(ExpectedConditions.visibilityOf(adminDashboard));
        advanceDashbroad.click();

        getWebDriverWait().until(ExpectedConditions.visibilityOf(overview));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(project));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(client));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(HR_menuTop));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(tickets_menuTop));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(finance_menuTop));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(totalClient));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(totalEmployees));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(totalProjects));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(dueInvoices));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(hoursLogged));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(pendingTasks));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(todayAttendance));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(unresolvedTickets));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(earnings));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(timeLogs));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(pendingLeaves));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(openTickets));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(pendingFollowUp));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(projectActivityTimeline));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(userActivityTimeline));
    }

}
