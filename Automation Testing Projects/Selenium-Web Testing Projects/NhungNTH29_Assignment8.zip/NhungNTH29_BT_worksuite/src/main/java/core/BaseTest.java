package core;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

public class BaseTest {
    private WebDriver webDriver;

    @BeforeSuite
    public void beforeSuite(){
        webDriver=new ChromeDriver();
    }

    @AfterSuite
    public void afterSuite(){
        webDriver.quit();
    }

    public WebDriver getWebDriver(){
        return webDriver;
    }
}
