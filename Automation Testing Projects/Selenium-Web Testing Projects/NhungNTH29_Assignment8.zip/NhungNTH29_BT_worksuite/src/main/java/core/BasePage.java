package core;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BasePage {
    private WebDriver webDriver;

    private WebDriverWait webDriverWait;

    public BasePage(WebDriver webDriver) {
        this.webDriver = webDriver;
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
        webDriverWait=new WebDriverWait(webDriver,Duration.ofSeconds(50));
        PageFactory.initElements(webDriver,this);
        //initElements: Khởi tạo tất cả element
        //implicit wait áp dụng initElement
    }

    public WebDriver getWebDriver() {
        return webDriver;
    }

    public WebDriverWait getWebDriverWait() {
        return webDriverWait;
    }

}
