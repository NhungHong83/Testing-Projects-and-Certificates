package tests.TC04;

import core.BasePage;
import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.ClientsPage;
import pages.HR_EmployeePage;
import pages.HomePage;
import pages.LoginPage;

public class TC04_Verify_Employees_Detail extends BaseTest {
    @Test(dataProvider = "testdata")
    public void test(String TCID,String username,String password){
        LoginPage loginPage=new LoginPage(getWebDriver());
        loginPage.navigateTo("https://demo.worksuite.biz/login");
        loginPage.login(username,password);
    }
    @Test(dataProvider = "testdata04",priority = 1)
    public void verifyEmployeeDetail(String name,String email, String department,String joinDate, String canlogin,
                                     String canreceiveEmail,String status,String horlyRate) throws InterruptedException {
        HomePage homePage=new HomePage(getWebDriver());
        homePage.getHR_Client_Page();
        HR_EmployeePage hr_employeePage=new HR_EmployeePage(getWebDriver());
        hr_employeePage.clickDestinationTeamLead();
        //6. Click to Edit Emp with id: EMP-45 (ko tìm thấy
        // => Chuyển thành verify Employee đầu tiên của Team Lead)
        hr_employeePage.verifyEmpDetail(name,email,department,joinDate,canlogin,canreceiveEmail,status,horlyRate);

    }
    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\Assignment\\NhungNTH29_BT_worksuite\\src\\main\\resources\\TestData\\TestData.xlsx"
                , "TC01" ,0,3  );
    }
    @DataProvider(name="testdata04")
    public Object[][] getTestData04(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\Assignment\\NhungNTH29_BT_worksuite\\src\\main\\resources\\TestData\\TestData.xlsx"
                , "TC04" ,0,8  );
    }
}
