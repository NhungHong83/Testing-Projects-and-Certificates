package tests.TC05;

import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.HR_EmployeePage;
import pages.HomePage;
import pages.LoginPage;
import pages.ProjectPage;

public class TC05_Verify_Projects_Detail extends BaseTest {
    @Test(dataProvider = "testdata")
    public void test(String TCID,String username,String password){
        LoginPage loginPage=new LoginPage(getWebDriver());
        loginPage.navigateTo("https://demo.worksuite.biz/login");
        loginPage.login(username,password);
        HomePage homePage=new HomePage(getWebDriver());
        homePage.getWork_Project_Page();
        //5. Search with key: Payment Billing System
        //6. Click to view project
        //7. Click to the Members tab
        ProjectPage projectPage=new ProjectPage(getWebDriver());
        projectPage.searchAndValidate("Payment Billing System");

    }
    @Test(dataProvider = "testdata04",priority = 1)
    public void verifyEmployeeDetail(String clientName,String email, String canNoti,String status, String companyName,String officialWeb){

        //Add trc mới search


    }
    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\Assignment\\NhungNTH29_BT_worksuite\\src\\main\\resources\\TestData\\TestData.xlsx"
                , "TC01" ,0,3  );
    }

}
