package tests.TC02;

import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LeadsPage;
import pages.LoginPage;

public class TC02_Verify_Leads_Detail extends BaseTest {
    @Test(dataProvider = "testdata")
    public void test(String TCID,String username,String password,String name, String companyName, String email, String address, String status) throws InterruptedException {
        LoginPage loginPage=new LoginPage(getWebDriver());
        loginPage.navigateTo("https://demo.worksuite.biz/login");
        loginPage.login(username,password);

        HomePage homePage=new HomePage(getWebDriver());
        homePage.getLeadsScreen();
        LeadsPage leadsPage=new LeadsPage(getWebDriver());
        leadsPage.addAndSearch(name,companyName,email,address);
        leadsPage.verifyLeadsTable(name,companyName);
        leadsPage.clickFirstResult();
        leadsPage.verifyLeadDetail(name,companyName,email,address,status);
        Thread.sleep(20000);
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\Assignment\\NhungNTH29_BT_worksuite\\src\\main\\resources\\TestData\\TestData.xlsx"
                , "TC02" ,0,8  );
    }
}
