package tests.TC01;

import core.BaseTest;
import core.ExcelUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

import java.time.Duration;

//VD có 6 testcase thì tạo 6 class trong package tests này
public class TC01_Verify_Dashboard extends BaseTest {
    @Test(dataProvider = "testdata")
    public void test(String TCID,String username,String password){
        LoginPage loginPage=new LoginPage(getWebDriver());
        loginPage.navigateTo("https://demo.worksuite.biz/login");
        loginPage.login(username,password);
        //Verify Dashboard
        //+ Menu Left: Admin Dashboard, Private Dashboard, Leads, Clients, HR, Work, Finance, Products, Orders, Tickets, Events.

        HomePage homePage=new HomePage(getWebDriver());
        homePage.verify();
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\Assignment\\NhungNTH29_BT_worksuite\\src\\main\\resources\\TestData\\TestData.xlsx"
                , "TC01" ,0,3  );
    }
}
