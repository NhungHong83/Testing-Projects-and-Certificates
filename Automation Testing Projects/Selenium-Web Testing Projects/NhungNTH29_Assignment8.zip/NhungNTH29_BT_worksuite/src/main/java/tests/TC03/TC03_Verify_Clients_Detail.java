package tests.TC03;

import core.BasePage;
import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import pages.ClientsPage;
import pages.HomePage;
import pages.LeadsPage;
import pages.LoginPage;

public class TC03_Verify_Clients_Detail extends BaseTest {
    @Test(dataProvider = "testdata",priority = 0)
    public void test(String TCID,String username,String password){
        LoginPage loginPage=new LoginPage(getWebDriver());
        loginPage.navigateTo("https://demo.worksuite.biz/login");
        loginPage.login(username,password);


    }
    @Test(dataProvider = "testdata03",priority = 1)
    public void verifyClientDetail(String clientName,String email, String canNoti,String status, String companyName,String officialWeb){
        HomePage homePage=new HomePage(getWebDriver());
        homePage.getClientsScreen();
        ClientsPage clientsPage=new ClientsPage(getWebDriver());
        clientsPage.addClient_clickStartDateAndSearch(clientName,email,companyName,officialWeb);
        clientsPage.verify(clientName, email,  canNoti, status,  companyName, officialWeb);
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\Assignment\\NhungNTH29_BT_worksuite\\src\\main\\resources\\TestData\\TestData.xlsx"
                , "TC01" ,0,3  );
    }
    @DataProvider(name="testdata03")
    public Object[][] getTestData03(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\Assignment\\NhungNTH29_BT_worksuite\\src\\main\\resources\\TestData\\TestData.xlsx"
                , "TC03" ,0,6  );
    }
}
