package pages;

import core.BasePage;
import entity.Product;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class ProductPage extends BasePage {

    public ProductPage(RemoteWebDriver webDriver) {
        super(webDriver);
    }
    @FindBy(xpath = "//a[@class=\"btn btn-primary\"]")
    private WebElement addNewProductButton;
    @FindBy(xpath = "//button[@class=\"btn btn-success dropdown-toggle\"]")
    private WebElement exportButton;
    @FindBy(xpath = "//button[@name=\"importexcel\"]")
    private WebElement importButton;
    @FindBy(xpath = "//button[@id=\"delete-selected\"]")
    private WebElement deleteButton;
    @FindBy(xpath = "//label[text()=\"Product name\"]")
    private WebElement productname;
    @FindBy(xpath = "//label[text()=\"Warehouse\"]")
    private WebElement warehouse;
    @FindBy(xpath = "//label[text()=\"Category\"]")
    private WebElement category;
    @FindBy(xpath = "//label[text()=\"Product type\"]")
    private WebElement productType;
    @FindBy(xpath = "//i[@class=\"far fa-angle-down\"]")
    private WebElement downButton;
    @FindBy(xpath = "//a[text()=\"Logout\"]")
    private WebElement logoutButton;
    @FindBy(xpath = "//div[text()=\"Product info\"]/following-sibling::div//button//i[@class=\"fa toggle-icon fa-plus\"]")
    private WebElement plusButton;
    @FindBy(xpath = "//div[text()=\"Prices\"]/following-sibling::div//button//i[@class=\"fa toggle-icon fa-plus\"]")
    private WebElement plusPriceButton;

    @FindBy(id="Name")
    private WebElement nameInput;
    @FindBy(id="ShortDescription")
    private WebElement shortDes;
    @FindBy(id="Sku")
    private WebElement sku;
    @FindBy(xpath = "(//div[@class=\"k-multiselect-wrap k-floatwrap\"])[1]")
    private WebElement categoriesSelect;
    @FindBy(xpath = "(//input[@class=\"k-input k-readonly\"])[1]")
    private WebElement categoriesInput;
    @FindBy(xpath = "(//input[@class=\"k-formatted-value k-input\"])[2]")
    private WebElement priceInput;
    @FindBy(xpath = "(//input[@class=\"k-formatted-value k-input\"])[3]")
    private WebElement oldpriceInput;

    @FindBy(xpath = "//div[@class=\"alert alert-success alert-dismissable\"]")
    private WebElement successMessage;
    @FindBy(xpath = "//button[@name=\"save\"]")
    private WebElement saveButton;
    @FindBy(xpath = "(//button[@class=\"close\"])[1]")
    private WebElement xText;
    @FindBy(xpath = "(//li[contains(text(),\"Test 1\")])[1]")
    private WebElement firstResult;


    public void addNewProduct(Product p,String msgSucess){
        //3
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(addNewProductButton)).click();
        //4
        try{
            WebElement element=getWebDriverWait().until(ExpectedConditions.elementToBeClickable(plusButton));
            element.click();
        }catch (Exception e){
        }
        getWebDriverWait().until(ExpectedConditions.visibilityOf(nameInput)).sendKeys(p.getProductName());
        getWebDriverWait().until(ExpectedConditions.visibilityOf(shortDes)).sendKeys(p.getShortDescription());
        getWebDriverWait().until(ExpectedConditions.visibilityOf(sku)).sendKeys(p.getSKU());
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(categoriesSelect)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(categoriesInput)).sendKeys(p.getCategories());
        try{
            WebElement element=getWebDriverWait().until(ExpectedConditions.elementToBeClickable(plusPriceButton));
            element.click();
        }catch (Exception e){
        }
        getWebDriverWait().until(ExpectedConditions.visibilityOf(priceInput)).sendKeys(p.getPrice());
        getWebDriverWait().until(ExpectedConditions.visibilityOf(oldpriceInput)).sendKeys(p.getOldPrice());
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(saveButton)).click();
        WebElement successMsg=getWebDriverWait().until(ExpectedConditions.visibilityOf(successMessage));
        WebElement xtext=getWebDriverWait().until(ExpectedConditions.visibilityOf(xText));
        String msg=successMsg.getText().replace(xtext.getText(),"").trim();
        Assert.assertEquals(msgSucess, msg);
    }
    public void verifyProductPage(){
        try{
            WebElement element=getWebDriverWait().until(ExpectedConditions.elementToBeClickable(downButton));
            element.click();
        }catch (Exception e){
        }
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addNewProductButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(exportButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(importButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(deleteButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(productname));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(warehouse));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(category));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(productType));
    }
    public void logout(){//6
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(logoutButton)).click();
    }
}
