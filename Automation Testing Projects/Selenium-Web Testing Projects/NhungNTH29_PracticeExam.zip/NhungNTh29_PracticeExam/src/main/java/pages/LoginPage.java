package pages;

import core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends BasePage {

    public LoginPage(RemoteWebDriver remoteWebDriver) {
        super(remoteWebDriver);
    }


    @FindBy(id="Email")
    private WebElement email;
    @FindBy(id = "Password")
    private WebElement password;
    @FindBy(xpath = "//button[@class=\"button-1 login-button\"]")
    private WebElement loginButton;
    public void navigateTo(String url){
        getRemoteWebDriver().get(url);
    }

    public void login(String u, String p){
        WebElement userName=getWebDriverWait().until(ExpectedConditions.visibilityOf(this.email));
        userName.clear();
        userName.sendKeys(u);
        password.clear();
        password.sendKeys(p);
        loginButton.click();
    }
}
