package pages;

import core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class AdminPage extends BasePage {

    public AdminPage(RemoteWebDriver remoteWebDriver) {
        super(remoteWebDriver);
    }

    //Menu Left
    @FindBy(xpath = "//div[@class=\"os-content\"]")
    private WebElement menuLeft;
    @FindBy(xpath = "(//p[contains(text(),\"Catalog\")]//..)[1]")
    private WebElement catalogButton;
    @FindBy(xpath = "(//p[contains(text(),\"Categories\")]//..)[1]")
    private WebElement categoriesButton;
    @FindBy(xpath = "(//p[contains(text(),\"Products\")]//..)[1]")
    private WebElement productButton;



    public void goToProductsPage(){
        getWebDriverWait().until(ExpectedConditions.visibilityOf(catalogButton)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(productButton)).click();
    }
    public void goToCategoriesPage(){
        getWebDriverWait().until(ExpectedConditions.visibilityOf(catalogButton)).click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(categoriesButton)).click();
    }


    public void verifyAdminPage(){
        getWebDriverWait().until(ExpectedConditions.visibilityOf(menuLeft));
    }




}
