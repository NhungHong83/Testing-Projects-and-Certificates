package pages;

import core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class CategoriesPage extends BasePage {
    public CategoriesPage(RemoteWebDriver webDriver) {
        super(webDriver);
    }
    @FindBy(xpath = "(//div[@class=\"float-right\"]//a)[1]")
    private WebElement addNewCateButton;
    @FindBy(xpath = "//button[@class=\"btn btn-success dropdown-toggle\"]")
    private WebElement exportButton;
    @FindBy(xpath = "//button[@name=\"importexcel\"]")
    private WebElement importButton;
    @FindBy(xpath = "//button[@id=\"delete-selected\"]")
    private WebElement deleteButton;
    @FindBy(xpath = "(//label[text()=\"Category name\"]//..//../following-sibling::div)[2]//input")
    private WebElement namedisplay;
    @FindBy(xpath = "//select[@id=\"SearchPublishedId\"]")
    private WebElement publishedSelect;
    @FindBy(id="Name")
    private WebElement nameInput;
    @FindBy(xpath = "//button[@name=\"save\"]")
    private WebElement saveButton;
    @FindBy(xpath = "//div[@class=\"alert alert-success alert-dismissable\"]")
    private WebElement successMessage;
    @FindBy(xpath = "(//button[@class=\"close\"])[1]")
    private WebElement xText;
    @FindBy(xpath = "//a[text()=\"Logout\"]")
    private WebElement logoutButton;
    @FindBy(xpath = "//div[text()=\"Category info\"]/following-sibling::div//button//i[@class=\"fa toggle-icon fa-plus\"]")
    private WebElement plusButton;


    public void logout(){//6
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(logoutButton)).click();
    }
    public void addNewCategory(String categoryName,String msgSucess){
        //3
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(addNewCateButton)).click();
        //4
        try{
            WebElement element=getWebDriverWait().until(ExpectedConditions.elementToBeClickable(plusButton));
            element.click();
        }catch (Exception e){
        }
        getWebDriverWait().until(ExpectedConditions.visibilityOf(nameInput)).sendKeys(categoryName);
        //5
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(saveButton)).click();
        WebElement successMsg=getWebDriverWait().until(ExpectedConditions.visibilityOf(successMessage));
        WebElement xtext=getWebDriverWait().until(ExpectedConditions.visibilityOf(xText));
        String msg=successMsg.getText().replace(xtext.getText(),"").trim();
        Assert.assertEquals(msgSucess, msg);
    }

    public void verifyCategoriesPage(){
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addNewCateButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(exportButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(importButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(deleteButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(namedisplay));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(publishedSelect));
    }
}
