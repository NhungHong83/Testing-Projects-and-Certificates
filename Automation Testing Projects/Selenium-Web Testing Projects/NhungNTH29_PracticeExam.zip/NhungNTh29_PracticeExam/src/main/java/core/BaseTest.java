package core;

import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.AfterSuite;

import java.net.MalformedURLException;
import java.net.URL;

public class BaseTest {
    private RemoteWebDriver remoteWebDriver;


    @AfterSuite
    public void afterSuite(){
        remoteWebDriver.close();
    }

    public RemoteWebDriver getRemoteWebDriver(String browserName) throws MalformedURLException {
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setPlatform(Platform.WINDOWS);
        desiredCapabilities.setBrowserName(browserName);
        remoteWebDriver=new RemoteWebDriver(new URL("http://localhost:4444"),desiredCapabilities);
        return remoteWebDriver;
    }
    public RemoteWebDriver getRemoteWD(){
        return  remoteWebDriver;
    }

}
