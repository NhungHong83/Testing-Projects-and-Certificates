package core;

import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BasePage {
    private RemoteWebDriver remoteWebDriver;

    private WebDriverWait webDriverWait;

    public BasePage(RemoteWebDriver webDriver) {
        this.remoteWebDriver = webDriver;
        webDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(500));
        webDriverWait=new WebDriverWait(webDriver,Duration.ofSeconds(500));
        PageFactory.initElements(webDriver,this);
        //initElements: Khởi tạo tất cả element
        //implicit wait áp dụng initElement
    }

    public RemoteWebDriver getRemoteWebDriver() {

        return remoteWebDriver;
    }

    public WebDriverWait getWebDriverWait() {
        return webDriverWait;
    }

}
