package entity;

public class Product {
    private String productName;
    private String shortDescription;
    private String SKU;
    private String categories;
    private String price;
    private String oldPrice;

    public Product() {
    }

    public Product(String productName, String shortDescription, String SKU, String categories, String price, String oldPrice) {
        this.productName = productName;
        this.shortDescription = shortDescription;
        this.SKU = SKU;
        this.categories = categories;
        this.price = price;
        this.oldPrice = oldPrice;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getSKU() {
        return SKU;
    }

    public void setSKU(String SKU) {
        this.SKU = SKU;
    }

    public String getCategories() {
        return categories;
    }

    public void setCategories(String categories) {
        this.categories = categories;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getOldPrice() {
        return oldPrice;
    }

    public void setOldPrice(String oldPrice) {
        this.oldPrice = oldPrice;
    }
}
