package tests.TC_CreateNewCustomer;

import core.BaseTest;
import core.ExcelUtils;
import entity.Product;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.AdminPage;
import pages.LoginPage;
import pages.ProductPage;

import java.net.MalformedURLException;

public class TC_CreateNewProduct extends BaseTest {
    public LoginPage loginPage;
    @Test (priority = 0)
    @Parameters({"browserName"})
    public void init(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void createNewProduct(String url,String email,String password,String productName,String shortDes,String SKU,
                                  String categories,String price, String oldPrice,String msg)  {
        //1
        loginPage.navigateTo(url);
        loginPage.login(email,password);
        AdminPage adminPage=new AdminPage(getRemoteWD());
        adminPage.verifyAdminPage();
        //2
        adminPage.goToProductsPage();

        ProductPage productPage=new ProductPage(getRemoteWD());
        productPage.verifyProductPage();
        //3-5
        Product p=new Product(productName,shortDes,SKU,categories,price,oldPrice);
        productPage.addNewProduct(p,msg);
        //6
        productPage.logout();
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTh29_PracticeExam\\src\\main\\resources\\TestData.xlsx"
                , "TC_CreateNewProduct" ,1,0,10 );
    }


}
