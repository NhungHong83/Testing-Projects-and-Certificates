package tests.TC_CreateNewCategory;

import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.AdminPage;
import pages.CategoriesPage;
import pages.LoginPage;

import java.net.MalformedURLException;

public class TC_CreateNewCategory extends BaseTest {
    public LoginPage loginPage;
    @Test (priority = 0)
    @Parameters({"browserName"})
    public void init(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void createNewCategory(String url,String email,String password,String categoryName,String msg)  {
        //1
        loginPage.navigateTo(url);
        loginPage.login(email,password);
        AdminPage adminPage=new AdminPage(getRemoteWD());
        adminPage.verifyAdminPage();
        //2
        adminPage.goToCategoriesPage();
        CategoriesPage categoriesPage=new CategoriesPage(getRemoteWD());
        categoriesPage.verifyCategoriesPage();
        //3-5
        categoriesPage.addNewCategory(categoryName,msg);
        //6
        categoriesPage.logout();
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTh29_PracticeExam\\src\\main\\resources\\TestData.xlsx"
                , "TC_CreateNewCatedoty" ,1,0,5 );
    }


}
