package TC_09;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC09_Verify_Create_New_Product_Sccessfully {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();

        //4. Click to the Store on the left menu.
        //5. Click to the Product
        WebElement storeButton=driver.findElement(By.xpath("//a//span[text()=\"Stores\"]"));
        WebElement productButton=driver.findElement(By.xpath("//a//span[text()=\"Product\"]"));
        Actions actions=new Actions(driver);
        actions.contextClick(storeButton).moveToElement(productButton).click().perform();

        //6. Click to the Add New Attribute button
        WebElement addButton=driver.findElement(By.xpath("//button[@id=\"add\"]"));
        addButton.click();

        //7. Input Default Label
        //Catalog Input Type for Store Owner: text editor
        //Values Required: No
        WebElement defaultLabel=driver.findElement(By.xpath("//input[@id=\"attribute_label\"]"));
        defaultLabel.sendKeys("Test01");
        Select inputType=new Select(driver.findElement(By.xpath("//select[@id=\"frontend_input\"]")));
        inputType.selectByIndex(0);

        //8. Click to the Save
        WebElement saveButton=driver.findElement(By.xpath("//button[@id=\"save\"]"));
        saveButton.click();

        //Verify the message : You saved the product attribute.
        try{
            WebElement successMessage=driver.findElement(By.xpath("//div[@data-ui-id=\"messages-message-success\"]"));
        }catch (Exception e){
            System.out.println("Save failed");
        }


        Thread.sleep(5000);
        driver.close();
    }
}
