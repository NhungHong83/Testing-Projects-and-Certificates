package TC_07;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC07_Verify_Product_Attributes_Page {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();

        //4. Click to the Store on the left menu.
        //5. Click to the Product
        WebElement storeButton=driver.findElement(By.xpath("//a//span[text()=\"Stores\"]"));
        WebElement productButton=driver.findElement(By.xpath("//a//span[text()=\"Product\"]"));
        Actions actions=new Actions(driver);
        actions.contextClick(storeButton).moveToElement(productButton).click().perform();

        /*    Verify result
        5. The Product Product Attributes screen displayed with some element:
            + Add New Attribute button
            + Search button
            + Reset Filter link
            + Product Attribute table
            + Product Attribute table display 20 rows data.
         */
        try{//Add New Attribute button
            WebElement addButton=driver.findElement(By.xpath("//button[@id=\"add\"]"));
        }catch (Exception e){
            System.out.println("Add New Attribute button is not exist");
        }
        try{//Search button
            WebElement searchButton=driver.findElement(By.xpath("//label[@class=\"search-global-label\"]"));
        }catch (Exception e){
            System.out.println("Search button is not exist");
        }
        try{//Reset Filter link
            WebElement resetFilterLink=driver.findElement(By.xpath("//button[@id=\"id_38670a163172177b7147669f603f964b\"]//span[text()=\"Reset Filter\"]"));
        }catch (Exception e){
            System.out.println("Reset Filter link is not exist");
        }
        try{//Product Attribute table display 20 rows data.
            Select rowDatas=new Select(driver.findElement(By.xpath("//select[@id=\"attributeGrid_page-limit\"]")));
            assertEquals("20",rowDatas.getFirstSelectedOption().getText());
        }catch (Exception e){
            System.out.println("Search button is not exist");
        }

        Thread.sleep(5000);
        driver.close();
    }
}
