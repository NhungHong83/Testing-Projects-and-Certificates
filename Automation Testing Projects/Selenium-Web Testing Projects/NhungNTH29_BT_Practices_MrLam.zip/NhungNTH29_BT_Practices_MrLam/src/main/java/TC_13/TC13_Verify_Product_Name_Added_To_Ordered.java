package TC_13;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC13_Verify_Product_Name_Added_To_Ordered {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();

        //4. Click to the Sales -> Orders on the left menu.
        WebElement saleButton=driver.findElement(By.xpath("//a//span[text()=\"Sales\"]"));
        WebElement orderButton=driver.findElement(By.xpath("(//a//span[text()=\"Orders\"])[1]"));
        Actions actions=new Actions(driver);
        actions.contextClick(saleButton).moveToElement(orderButton).click().perform();

        //5. Click to the Create New Order
        WebElement createOrderButton=driver.findElement(By.xpath("//button[@id=\"add\"]"));
        createOrderButton.click();

        //6. Select first customer
        WebElement firstRow=driver.findElement(By.xpath("(//tr[@data-role=\"row\"])[1]"));
        firstRow.click();

        //7. Click to the Add Products
        WebElement addProductButton=driver.findElement(By.xpath("//button[@id=\"add_products\"]"));
        addProductButton.click();

        //8. Search and Select 4 products
        // - Erika Running Short-32-Green
        // - Erika Running Short-32-Purple
        // - Erika Running Short-32-Red
        // - ProdI-Conf


        //9. Click to the Add Selected Product(s) to Order

        //10. Add Shipping Method: Table Rate



        //11. Click to submit order

        //6. Verify Grand Total is $36.39
        try{
            WebElement grandTotal=driver.findElement(By.xpath("(//div[@class=\"data-grid-cell-content\"])[6]"));
            assertEquals("$36.39",grandTotal.getText());
        }catch (Exception e){
            System.out.println("Failed in action: Verify Grand Total is $36.39");
        }


        Thread.sleep(5000);
        driver.close();
    }
}
