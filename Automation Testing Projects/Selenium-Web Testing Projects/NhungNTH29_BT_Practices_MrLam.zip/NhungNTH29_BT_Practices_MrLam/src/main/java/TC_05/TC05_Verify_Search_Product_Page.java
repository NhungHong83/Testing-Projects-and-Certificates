package TC_05;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC05_Verify_Search_Product_Page {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();

        //4. Click to the Catalog on the left menu.
        //5. Click to the Products
        WebElement catalogButton=driver.findElement(By.xpath("//a//span[text()=\"Catalog\"]"));
        Actions actions=new Actions(driver);
        WebElement productButton=driver.findElement(By.xpath("(//span[text()=\"Products\"])[1]"));
        actions.contextClick(catalogButton).moveToElement(productButton).click().perform();


        //Verify result
        try{// Add product button
            WebElement addProductButton=driver.findElement(By.xpath("//button//span[text()=\"Add Product\"]"));
        }catch (Exception e){
            System.out.println("Add Product Button is not exist");
        }

        //6. Input search key: Savvy Shoulder Tote and click filter
        //Actual: click filters=>input search Key=>Click Apply Filters
        WebElement filterButton=driver.findElement(By.xpath("(//div//button[@class=\"action-default\"])[1]"));
        filterButton.click();
        WebElement searchKeyInput=driver.findElement(By.xpath("JM1ALQA"));
        pass.sendKeys("Savvy Shoulder Tote");
        WebElement applyFilter=driver.findElement(By.xpath("//span[text()=\"Apply Filters\"]"));
        applyFilter.click();

        //Verify
        //6. The search result display product with name: Savvy Shoulder Tote
        try{//Columns
            WebElement textContent=driver.findElement(By.xpath("//div[@class=\"data-grid-cell-content\"][text()=\"Savvy Shoulder Tote\"]"));
            assertEquals("Savvy Shoulder Tote",textContent.getText());
        }catch (Exception e){
            System.out.println("Savvy Shoulder Tote is not exist");
        }


        Thread.sleep(5000);
        driver.close();
    }
}
