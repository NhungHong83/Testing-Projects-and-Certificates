package TC_02;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC02_Verify_Create_New_Customer {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();

        //4. Click to the Customers on the left menu.
        //5. Click to the All Customers
        Actions actions=new Actions(driver);
        WebElement customerButton=driver.findElement(By.xpath("(//span[text()=\"Customers\"])[1]"));
        WebElement allCustomerButton=driver.findElement(By.xpath("(//span[text()=\"All Customers\"])[1]"));
        actions.contextClick(customerButton).moveToElement(allCustomerButton).click().perform(); // contextClick: Click chuột phải

        //6. Click Add New Customer
        WebElement addNewCustomerButton=driver.findElement(By.xpath("//button[@id=\"add\"]"));
        addNewCustomerButton.click();

        //7. Input the requite field.
        Select group=new Select(driver.findElement(By.xpath("(//select[@class=\"admin__control-select\"])[2]")));
        group.selectByIndex(1);
        WebElement  firstName=driver.findElement(By.xpath("//input[@id=\"Q7NGD6Y\"]"));
        firstName.sendKeys("Nguyen");
        WebElement  lastName=driver.findElement(By.xpath("//input[@id=\"AY5L8YG\"]"));
        lastName.sendKeys("Nhung");
        WebElement  email=driver.findElement(By.xpath("//input[@id=\"BE1YUR8\"]"));
        email.sendKeys("NhungNTH29@fpt.com.vn");

        //8. Click to the Save Customer.
        WebElement saveButton=driver.findElement(By.xpath("//button[@id=\"save\"]"));
        saveButton.click();

        //Verify result
        WebElement successMessage=driver.findElement(By.xpath("//div[@data-ui-id=\"messages-message-success\"]"));
        assertEquals("You saved the customer.",successMessage.getText());

        Thread.sleep(5000);
        driver.close();
    }
}
