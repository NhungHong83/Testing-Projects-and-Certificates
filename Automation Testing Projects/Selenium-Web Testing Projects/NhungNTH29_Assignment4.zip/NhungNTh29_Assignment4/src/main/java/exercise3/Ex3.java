package exercise3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Ex3 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("http://demo.seleniumeasy.com/basic-radiobutton-demo.html");

        WebElement radioButtonMale=driver.findElement(By.xpath("(//input[@name=\"gender\"])[1]"));
        radioButtonMale.click();


        WebElement radioGroupButton=driver.findElement(By.xpath("//input[@name=\"ageGroup\"][1]"));
        radioGroupButton.click();

        WebElement getValueButton=driver.findElement(By.xpath("(//button[@class=\"btn btn-default\"])[2]"));
        getValueButton.click();

        WebElement message=driver.findElement(By.xpath("//p[@class=\"groupradiobutton\"]"));
        System.out.println(message.getText());

        Thread.sleep(5000);
        driver.close();
    }
}
