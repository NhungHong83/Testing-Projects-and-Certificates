package exercise5;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

public class Ex5 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("http://demo.seleniumeasy.com/table-pagination-demo.html");

        WebElement table=driver.findElement(By.xpath("//table[@class=\"table table-hover\"]"));

        List<WebElement> TRs=table.findElements(By.tagName("tr"));
        List<WebElement> TDs=TRs.get(1).findElements(By.tagName("td"));
        for (WebElement td:TDs) {
            System.out.print(td.getText()+"     ");
        }
        Thread.sleep(5000);
        driver.close();
    }
}
