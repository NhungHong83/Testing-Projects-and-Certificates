package exercise2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;

public class Ex2 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("http://demo.seleniumeasy.com/basic-checkbox-demo.html");

        WebElement checkBox=driver.findElement(By.id("isAgeSelected"));
        checkBox.click();

        WebElement message=driver.findElement(By.xpath("//div[@id=\"txtAge\"]"));
        System.out.println(message.getText());

        Thread.sleep(5000);
        driver.close();
    }
}
