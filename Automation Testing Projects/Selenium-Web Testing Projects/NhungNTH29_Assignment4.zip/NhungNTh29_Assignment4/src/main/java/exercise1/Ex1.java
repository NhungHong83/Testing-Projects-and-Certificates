package exercise1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;

public class Ex1 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("http://demo.seleniumeasy.com/");
        WebElement inputForm=driver.findElement(By.xpath("(//a[contains(text(),\"Input Forms\")])[2]"));
        inputForm.click();
        WebElement simple_form_demo=driver.findElement(By.xpath("(//a[contains(text(),\"Simple Form Demo\")])[2]"));
        simple_form_demo.click();

        String text="Your Message: Automation Tester";
        WebElement input=driver.findElement(By.xpath("//input[@id=\"user-message\"]"));
        input.sendKeys(text);
        WebElement showMessButton=driver.findElement(By.xpath("(//button[@class=\"btn btn-default\"])[1]"));
        showMessButton.click();

        WebElement message=driver.findElement(By.xpath("//span[@id=\"display\"]"));
        assertEquals(message.getText().equals(text),true);

        Thread.sleep(5000);
        driver.close();
    }
}
