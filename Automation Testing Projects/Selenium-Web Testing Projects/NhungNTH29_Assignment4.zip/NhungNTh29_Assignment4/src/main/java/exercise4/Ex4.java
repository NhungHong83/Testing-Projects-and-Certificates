package exercise4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

public class Ex4 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("http://demo.seleniumeasy.com/basic-select-dropdown-demo.html");

        Select selectListDemo=new Select(driver.findElement(By.id("select-demo")));
        selectListDemo.selectByVisibleText("Monday");

        WebElement message=driver.findElement(By.xpath("//p[@class=\"selected-value\"]"));
        System.out.println(message.getText());

        Thread.sleep(5000);
        driver.close();
    }
}
