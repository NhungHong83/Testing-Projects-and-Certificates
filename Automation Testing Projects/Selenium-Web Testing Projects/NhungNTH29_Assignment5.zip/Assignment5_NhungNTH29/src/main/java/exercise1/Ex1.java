package exercise1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

public class Ex1 {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        driver.navigate().to("http://demo.guru99.com/test/drag_drop.html");
        Actions actions=new Actions(driver);
        WebElement dragButton=driver.findElement(By.xpath("//li[@id=\"fourth\"]"));
        WebElement amt=driver.findElement(By.xpath("//ol[@id=\"amt7\"]"));
        actions.dragAndDrop(dragButton,amt).perform();

        Thread.sleep(5000);
        driver.close();
    }
}
