package exercise4;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Set;

public class Ex4 {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        driver.navigate().to("https://tiki.vn/");
        Set<Cookie> cookies= driver.manage().getCookies(); //Lấy tất cả cookie
        System.out.println("Number of cookies of current domain: "+cookies.size());
        for (Cookie c: cookies) {
            System.out.println(c.getDomain());
        }

        Thread.sleep(5000);
        driver.close();
    }
}
