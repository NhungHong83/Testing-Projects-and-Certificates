package exercise3;

import common.CommonMethods;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

public class Ex3 {
    @Test
    public void test() throws InterruptedException, IOException, AWTException {
        CommonMethods commonMethods=new CommonMethods();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        Thread.sleep(1000);
        driver.navigate().to("https://demo.guru99.com/test/simple_context_menu.html");

        Actions actions=new Actions(driver);
        WebElement rightClickButton=driver.findElement(By.xpath("//span[text()=\"right click me\"]"));
        System.out.println(rightClickButton.getText());

        WebElement editItem=driver.findElement(By.xpath("//span[text()=\"Edit\"]"));
        actions.contextClick(rightClickButton).moveToElement(editItem).click().perform(); // contextClick: Click chuột phải
        Thread.sleep(2000);

        //Capturing screenshots with Robot
        BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        ImageIO.write(image, "png", new File("E://image_"+commonMethods.getAlphaNumericString(25)+".png"));
        driver.switchTo().alert().accept();

        Thread.sleep(5000);
        driver.close();
    }
}
