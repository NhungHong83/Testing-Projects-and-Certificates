package exercise2;

import common.CommonMethods;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.nio.charset.Charset;
import java.util.Random;

public class Ex2 {
    @Test
    public void test() throws InterruptedException, IOException, AWTException {
        CommonMethods commonMethods=new CommonMethods();
        WebDriver driver = new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        Thread.sleep(1000);
        driver.navigate().to("https://demo.guru99.com/test/simple_context_menu.html");

        Actions actions=new Actions(driver);
        WebElement doubleClickButton=driver.findElement(By.xpath("//button[text()=\"Double-Click Me To See Alert\"]"));
        System.out.println(doubleClickButton.getText());
        actions.doubleClick(doubleClickButton).perform();
        Thread.sleep(2000);

        //Capturing screenshots with Robot
        BufferedImage image = new Robot().createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        ImageIO.write(image, "png", new File("E://image_"+ commonMethods.getAlphaNumericString(25)+".png"));
        driver.switchTo().alert().accept();

        Thread.sleep(5000);
        driver.close();
    }

}
