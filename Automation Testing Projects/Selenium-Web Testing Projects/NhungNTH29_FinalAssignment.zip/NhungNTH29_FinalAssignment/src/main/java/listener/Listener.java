package listener;

import core.ExcelUtils;
import org.testng.ITestListener;
import org.testng.ITestResult;

public class Listener implements ITestListener {

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("Test is successfully - method: "+getTestMethodName(result)+ " is success ");
    }

    @Override
    public void onTestFailure(ITestResult result) {
        System.out.println("Test is failed - method: "+getTestMethodName(result)+ " is failed");
    }

    private static String getTestMethodName(ITestResult iTestResult){
        return iTestResult.getMethod().getConstructorOrMethod().getName();
    }

}
