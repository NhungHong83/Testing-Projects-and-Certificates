package core;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.*;

public class ExcelUtils {
    public static Object[][] getTableArray(String filePath,String sheetName, int startRow,int startCol, int totalCol){
        String[][] table=null;
        try{
            FileInputStream inputStream=new FileInputStream(new File(filePath));
            XSSFWorkbook xssfWorkbook=new XSSFWorkbook(inputStream);
            XSSFSheet xssfSheet=xssfWorkbook.getSheet(sheetName);
//            int startRow=1;
            int ci,cj;
            int totalRows=xssfSheet.getLastRowNum();
            ci=0;
            table=new String[totalRows][totalCol];
            for(int i=startRow;i<=totalRows;i++,ci++){
                cj=0;
                for(int j=startCol;j<totalCol;j++,cj++){
                    XSSFCell cell=xssfSheet.getRow(i).getCell(j);//row 1, ô đầu
                    table[ci][cj]= cell.getStringCellValue();
                }
            }
            xssfWorkbook.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
        return table;
    }

    public void writeToExcel(String filePath,String sheetName, int startRow,int startCol,String msg ){
        try{
            // Creating a workbook instances
            Workbook wb = new HSSFWorkbook();
            // Creating a sheet using predefined class
            // provided by Apache POI
            XSSFSheet sheet = (XSSFSheet) wb.getSheet(sheetName);
            // Creating a row at specific position
            // using predefined class provided by Apache POI

            // Specific row number
            Row row = sheet.createRow(startRow);
            // Specific cell number
            Cell cell = row.createCell(startCol);
            // putting value at specific position
            cell.setCellValue(msg);
            // Writing the content to Workbook
            FileOutputStream out = new FileOutputStream(new File(filePath));
            wb.write(out);
            wb.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}
