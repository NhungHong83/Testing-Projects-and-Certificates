package pages;

import core.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

public class HomePage extends BasePage {

    public HomePage(RemoteWebDriver remoteWebDriver) {
        super(remoteWebDriver);
    }

    //Menu Left
    @FindBy(xpath = "//div[@class=\"alert alert-success\"]//p")
    private WebElement loginSuccessMessage;

    @FindBy(xpath = "(//h2[text()=\"Overview Chart\"]//..//..)[1]")
    private WebElement overViewChart;

    @FindBy(xpath = "(//h2[text()=\"Quick Links\"]//..//..)[1][@class=\"box\"]")
    private WebElement quizLink;

    @FindBy(xpath = "(//h2[text()=\" Latest Five\"]//..//..)[1][@class=\"box\"]")
    private WebElement lastestFive;

    @FindBy(xpath = "(//h2[contains(text(),\"Best Sellers\")]//..//..)[1][@class=\"box\"]")
    private WebElement bestSeller;

    @FindBy(xpath = "(//span[text()=\" Products \"]//..)[1]")
    private WebElement productButton;
    @FindBy(xpath = "(//span[text()=\" List Products\"]//..)[1]")
    private WebElement listProductButton;

    @FindBy(xpath = "(//span[text()=\" Purchases \"]//..)[1]")
    private WebElement purchaseButton;
    @FindBy(xpath = "(//span[text()=\" List Purchases\"]//..)[1]")
    private WebElement listpurchaseButton;
    @FindBy(xpath = "(//span[text()=\" Add Purchase\"]//..)[1]")
    private WebElement addpurchaseButton;

    @FindBy(xpath = "(//span[text()=\" Sales \"]//..)[1]")
    //a[@id="addManually"]
    private WebElement saleButton;
    @FindBy(xpath = "(//span[text()=\" Add Sale\"]//..)[1]")
    private WebElement addSaleButton;
    @FindBy(xpath = "//li[@id=\"products_print_barcodes\"]//a")
    private WebElement printBarcodeLabelButton;
    @FindBy(xpath = "//div[@class=\"box\"]")
    private WebElement addPurchaseContent;
    @FindBy(id="loading")
    private WebElement loading;

    public void goToAddPurchasePage(){
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(loading));
        WebElement purchaseBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(purchaseButton));
        purchaseBtn.click();
        WebElement addPurchaseBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(addpurchaseButton));
        addPurchaseBtn.click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addPurchaseContent));
    }
    public void goToPurchasePage(){
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(loading));
        WebElement purchaseBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(purchaseButton));
        purchaseBtn.click();
        WebElement listPurchaseBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(listpurchaseButton));
        listPurchaseBtn.click();
    }

    public void goToAddSale(){
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(loading));
        WebElement saleBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(saleButton));
        saleBtn.click();
        WebElement addSaleBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(addSaleButton));
        addSaleBtn.click();
    }
    public void goToPrintBarcodeLabelPage(){
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(loading));
        WebElement productBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(productButton));
        productBtn.click();

        WebElement prtBarcodeLabelBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(printBarcodeLabelButton));
        prtBarcodeLabelBtn.click();
    }
    public void goToProductPage(){
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(loading));
        WebElement productBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(productButton));
        productBtn.click();
        WebElement listProductBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(listProductButton));
        listProductBtn.click();
    }

    public void verifyDashbroad(String msg){
        WebElement loginSuccessMsg = getWebDriverWait().until(ExpectedConditions.visibilityOf(loginSuccessMessage));
        Assert.assertEquals(loginSuccessMsg.getText(), msg);
        getWebDriverWait().until(ExpectedConditions.visibilityOf(overViewChart));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(quizLink));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(lastestFive));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(bestSeller));
    }




}
