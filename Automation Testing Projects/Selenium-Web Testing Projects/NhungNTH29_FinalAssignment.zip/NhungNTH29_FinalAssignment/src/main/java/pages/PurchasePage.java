package pages;

import core.BasePage;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

import java.text.Format;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

public class PurchasePage extends BasePage {

    public PurchasePage(RemoteWebDriver webDriver) {
        super(webDriver);
    }
    @FindBy(xpath = "((//table[@id=\"POData\"]//tbody//tr)[1]//td)[2]")
    private WebElement dateTimeValue;
    @FindBy(xpath = "//table[@id=\"POData\"]//tbody//tr")
    private List<WebElement> listTRs;
    @FindBy(xpath = "//table[@id=\"POData\"]//tbody//tr//td/following-sibling::td[contains(text(),\"PO\")]")
    private List<WebElement> listReferenceNo;


    public void verifyPurchaseTable(String formatDTime, String referNo,String numberPurchase) throws ParseException {
        //+ Date: format datetime by dd/mm/yyy hh:mm:ss
        SimpleDateFormat sdf = new SimpleDateFormat(formatDTime);
        Date date = sdf.parse(dateTimeValue.getText());
        //+ Reference No order by DESC
        boolean checkDESC=true;
        for (int i=0;i<listReferenceNo.size()-1;i++) {
            String referenceBefore=listReferenceNo.get(i).getText();
            String referenceAfter=listReferenceNo.get(i+1).getText();
            if(referenceBefore.compareTo(referenceAfter)<0){
                checkDESC=false;
            }
        }
        Assert.assertEquals(checkDESC, true);
        //+ Dispayed 9 Purchases
        Assert.assertEquals(Integer.parseInt(numberPurchase), listTRs.size());
    }
}
