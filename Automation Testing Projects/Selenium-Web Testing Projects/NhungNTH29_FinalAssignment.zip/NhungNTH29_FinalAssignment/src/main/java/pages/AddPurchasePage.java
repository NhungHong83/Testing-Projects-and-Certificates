package pages;

import core.BasePage;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class AddPurchasePage extends BasePage {
    RemoteWebDriver remoteWebDriver;
    public AddPurchasePage(RemoteWebDriver webDriver) {
        super(webDriver);
        this.remoteWebDriver=webDriver;
    }
//    @FindBy(xpath = "(//div[@class=\"form-group\"])[7]//div//div/following-sibling::input")

    @FindBy(id="add_item")
    private WebElement addProductInput;
    @FindBy(xpath = "(//ul[@id=\"ui-id-1\"]//li)[1]")
    private WebElement addProductSelected;




//    @FindBy(xpath = "(//div[@class=\"input-group\"]//div//span)[1]")
    @FindBy(xpath = "//div[@id=\"s2id_posupplier\"]")
    private WebElement supplierDropdown;
//    @FindBy(xpath = "//input[@id=\"s2id_autogen8_search\"]")

    @FindBy(xpath = "(//div[@class='select2-search'])[8]//input")
    private WebElement supplierDropdownInput;
    @FindBy(xpath = "(//ul[@id=\"select2-results-8\"]//li//div)[1]")
    private WebElement supplierDropdownSelected;
    @FindBy(xpath = "(//div[@class=\"col-md-4\"])[6]")
    private WebElement statusDropdown;
    @FindBy(xpath = "//div[@class=\"from-group\"]//input")
    private WebElement submitButton;
    @FindBy(xpath = "//div[@class=\"alert alert-success\"]")
    private WebElement msgSuccess;
    @FindBy(xpath = "//div[@class=\"col-md-4\"]")
    private WebElement colLoading;

    public void addPurchaseANdVerify( String supplierKey, String productKey,String message){
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(colLoading));
        //add supplier
        getWebDriverWait().until(ExpectedConditions.visibilityOf(supplierDropdown));
        supplierDropdown.click();
        WebElement e=getWebDriverWait().until(ExpectedConditions.visibilityOf(supplierDropdownInput));
        e.sendKeys(supplierKey);
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(supplierDropdownSelected));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(supplierDropdownSelected)).click();
        //add product
        WebElement addProductinput=getWebDriverWait().until(ExpectedConditions.visibilityOf(addProductInput));
        addProductinput.sendKeys(productKey);
        addProductinput.submit();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addProductSelected)).click();
        //6. Click to the Submit
        submitButton.click();
        //6. Dispayled message : Purchase successfully added
        WebElement msg=getWebDriverWait().until(ExpectedConditions.visibilityOf(msgSuccess));
        String msgsucc=msg.getText();
        Assert.assertEquals(msgsucc.contains(message.trim()), true);
    }
}
