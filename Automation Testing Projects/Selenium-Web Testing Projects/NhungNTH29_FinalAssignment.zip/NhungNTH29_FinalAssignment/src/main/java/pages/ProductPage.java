package pages;

import core.BasePage;
import entity.Product;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.util.List;

public class ProductPage extends BasePage {
    public ProductPage(RemoteWebDriver remoteWebDriver) {
        super(remoteWebDriver);
    }

    @FindBy(xpath = "(//th[@class='sorting_disabled'])[1]//following-sibling::th")
    private List<WebElement> listTitleTable;
    @FindBy(xpath = "//table[@id=\"PRData\"]//tbody//tr[@id=\"3\"]")

    private WebElement trLemon;

    @FindBy(id="pr-image")
    private WebElement image;

    @FindBy(xpath = "//img[@class=\"bcimg\"]")
    private WebElement barCode;
    @FindBy(xpath = "//img[@class=\"qrimg\"]")
    private WebElement qrCode;
    @FindBy(xpath = "//td[text()=\"Type\"]/following-sibling::td")
    private WebElement typeStandart;
    @FindBy(xpath = "(//td[text()=\"Name\"])/following-sibling::td")
    private WebElement name;

    @FindBy(xpath = "(//td[text()=\"FFR03\"])[2]")
    private WebElement code;
    @FindBy(xpath = "(//td[text()=\"Fruits\"])[2]")
    private WebElement category;
    @FindBy(xpath = "//td[text()=\"Piece (pc)\"]")
    private WebElement unit;
    @FindBy(xpath = "//td[text()=\"1.95\"]")
    private WebElement cost;
    @FindBy(xpath = "//td[text()=\"3.00\"]")
    private WebElement price;
    @FindBy(xpath = "//td[text()=\"GST @0%\"]")
    private WebElement taxRate;
    @FindBy(xpath = "//td[text()=\"Inclusive\"]")
    private WebElement taxMethod;
    @FindBy(xpath = "//td[text()=\"5.00\"]")
    private WebElement alert;
    @FindBy(xpath = "//div[text()=\"Product Details\"]/following-sibling::div//p")
    private WebElement productDetail;

    @FindBy(xpath = "//a[text()=\"2\"]")
    private WebElement secondPaging;
    @FindBy(xpath = "(//td[text()=\"Mouse\"]/following-sibling::td[8]//.)[4]")
    private WebElement actionMouseButton;
    @FindBy(xpath = "(//td[text()=\"Mouse\"]/following-sibling::td[8]//.)[8]//li[3]//a")
    private WebElement editButton;

    @FindBy(xpath = "//div[@id=\"s2id_type\"]")
    private WebElement productTypeCombobox;
    @FindBy(xpath = "//label[text()=\"Product Name\"]")
    private WebElement productName;
    @FindBy(xpath = "//label[text()=\"Product Code\"]/following-sibling::input")
    private WebElement productCodeInput;
    @FindBy(xpath = "//label[text()=\"Slug\"]")
    private WebElement slug;
    @FindBy(xpath = "//div[@id=\"s2id_barcode_symbology\"]")
    private WebElement barcodeSymbology;
//    @FindBy(xpath = "(//div[@class=\"select2-drop select2-display-none select2-drop-active\"])[2]")

    @FindBy(xpath = "//input[@id=\"s2id_autogen6_search\"]")
    private WebElement barcodeSymbolInput;

    @FindBy(xpath = "//div[text()=\"EAN8\"]")
    private WebElement barcodeSymbolFirstValue;
    @FindBy(xpath = "//div[@id=\"s2id_tax_method\"]")
    private WebElement taxMethodCombobox;

    @FindBy(xpath = "//div[text()=\"Exclusive\"]")
    private WebElement taxMethodvalue;


    @FindBy(xpath = "//input[@name=\"edit_product\"]")
    private WebElement editProductButton;

    @FindBy(xpath = "//div[@class=\"alert alert-danger\"]//p")
    private WebElement displayMessage;


    public void verifyEditProduct(String productType,String barCode_symbol,String tax_method,String msg){
        WebElement secondpaging = getWebDriverWait().until(ExpectedConditions.visibilityOf(secondPaging));
        secondpaging.click();
        WebElement actionButton = getWebDriverWait().until(ExpectedConditions.visibilityOf(actionMouseButton));
        actionButton.click();
        WebElement editbutton = getWebDriverWait().until(ExpectedConditions.visibilityOf(editButton));
        editbutton.click();
        //5. Product detail page displayed:Product Type, Product Name, Product Code, Slug, Barcode Symbology
        WebElement productTypecbx = getWebDriverWait().until(ExpectedConditions.visibilityOf(productTypeCombobox));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(productName));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(productCodeInput));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(slug));
        WebElement barcodeSymbol = getWebDriverWait().until(ExpectedConditions.visibilityOf(barcodeSymbology));
        //6. Change some filed as below:
        //+ Product Type: Combo
        //+ Barcode Symbology: EAN8
        //+ Tax Method: Exclusive
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(productTypeCombobox)).click();
        WebElement typecombobox = getWebDriverWait().until(ExpectedConditions.elementToBeClickable((By.xpath("//div[text()=\"Combo\"]")) ));
        typecombobox.click();
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(barcodeSymbology)).click();
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(barcodeSymbolInput)).click();
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(barcodeSymbolFirstValue)).click();
        taxMethodCombobox.click();
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(taxMethodvalue)).click();
        //7. Click to Edit product
        WebElement editBtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(editProductButton));
        editBtn.click();
        //7. The page displayed message: Product price doesn't match with combo items' price
        WebElement dispalyMsg = getWebDriverWait().until(ExpectedConditions.visibilityOf(displayMessage));
        Assert.assertEquals(dispalyMsg.getText(), msg);
    }
    public void openProductDetailPopupAndVerify(Product product){
        WebElement lemon = getWebDriverWait().until(ExpectedConditions.visibilityOf(trLemon));
        lemon.click();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(image));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(barCode));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(qrCode));
        WebElement type = getWebDriverWait().until(ExpectedConditions.visibilityOf(typeStandart));
        Assert.assertEquals(type.getText(), product.getType());
        WebElement productName = getWebDriverWait().until(ExpectedConditions.visibilityOf(name));
        Assert.assertEquals(productName.getText(), product.getName());
        WebElement productCode = getWebDriverWait().until(ExpectedConditions.visibilityOf(code));
        Assert.assertEquals(productCode.getText(), product.getCode());
        WebElement productCategory = getWebDriverWait().until(ExpectedConditions.visibilityOf(category));
        Assert.assertEquals(productCategory.getText(), product.getCategory());
        WebElement productUnit = getWebDriverWait().until(ExpectedConditions.visibilityOf(unit));
        Assert.assertEquals(productUnit.getText(), product.getUnit());
        WebElement productPrice = getWebDriverWait().until(ExpectedConditions.visibilityOf(price));
        Assert.assertEquals(productPrice.getText(), product.getPrice());
        WebElement taxrate = getWebDriverWait().until(ExpectedConditions.visibilityOf(taxRate));
        Assert.assertEquals(taxrate.getText(), product.getTaxRate());
        WebElement taxmethod = getWebDriverWait().until(ExpectedConditions.visibilityOf(taxMethod));
        Assert.assertEquals(taxmethod.getText(), product.getTaxMethod());
        getWebDriverWait().until(ExpectedConditions.visibilityOf(productDetail));
    }

    public void verifyProductTable(){
        for (WebElement th:listTitleTable) {
            try {
                Assert.assertEquals(th.isDisplayed(), true);
            } catch (Exception e) {
                System.out.println(e.getStackTrace());
            }
        }
    }
}
