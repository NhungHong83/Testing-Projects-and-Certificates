package pages;

import core.BasePage;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends BasePage {

    public LoginPage(RemoteWebDriver remoteWebDriver) {
        super(remoteWebDriver);
    }


    @FindBy(name="identity")
    private WebElement userName;
    @FindBy(xpath = "//input[@name=\"password\"]")
    private WebElement password;
    @FindBy(xpath = "//button[contains(text(),\"Login\")]")
    private WebElement loginButton;
    @FindBy(xpath = "//label[text()=\"Remember me\"]/../preceding-sibling::div//div")
    private WebElement rememberMeCheckBox;






    public void verifyLoginPage(){
        getWebDriverWait().until(ExpectedConditions.visibilityOf(userName));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(password));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(loginButton));
        getWebDriverWait().until(ExpectedConditions.visibilityOf(rememberMeCheckBox));
    }
    public void navigateTo(String url){
        getRemoteWebDriver().get(url);
    }

    public void login(String u, String p){
        WebElement userName=getWebDriverWait().until(ExpectedConditions.visibilityOf(this.userName));
        userName.clear();
        userName.sendKeys(u);
        password.clear();
        password.sendKeys(p);
        loginButton.click();
    }
}
