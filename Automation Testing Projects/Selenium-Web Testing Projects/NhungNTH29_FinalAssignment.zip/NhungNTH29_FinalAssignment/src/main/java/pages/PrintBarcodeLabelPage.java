package pages;

import core.BasePage;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.List;

public class PrintBarcodeLabelPage extends BasePage {
    public PrintBarcodeLabelPage(RemoteWebDriver remoteWebDriver) {
        super(remoteWebDriver);
    }

    @FindBy(xpath = "//label[text()=\"Add Product\"]/following-sibling::input")
    private WebElement addProductNameInput;
//    @FindBy(xpath = "//label[text()=\"Style\"]/following-sibling::select")
//    @FindBy(xpath = "((//div[@class=\"form-group\"])[2]//div//a//span)[1]")
    //div[@id="select2-result-label-38"]


//    @FindBy(xpath = "//ul[@id=\"select2-results-1\"]//li//div[contains(text(),\"18 per sheet\")]")
    @FindBy(xpath = "//div[@id=\"s2id_style\"]/a")
    private WebElement style;
    @FindBy(xpath = "//div[contains(text(),\"18\")]")
    private WebElement styleSelected;
    //div[contains(text(),"18")]
    @FindBy(xpath = "//div[@id=\"s2id_style\"]")
    private WebElement styleCbx;

    @FindBy(xpath = "(//div[@class=\"form-group\"])[6]//label")
    private List<WebElement> listLabelVerify;

    @FindBy(xpath = "//input[@name=\"site_name\"]")
    private WebElement siteNameCheckbox;
    @FindBy(xpath = "//input[@name=\"product_name\"]")
    private WebElement productNameCheckbox;
    @FindBy(xpath = "//input[@name=\"price\"]")
    private WebElement priceCheckbox;
    @FindBy(xpath = "//input[@name=\"currencies\"]")
    private WebElement currenciesCheckbox;
    @FindBy(xpath = "//input[@name=\"unit\"]")
    private WebElement unitCheckbox;
    @FindBy(xpath = "//input[@name=\"category\"]")
    private WebElement categoryCheckbox;
    @FindBy(xpath = "//input[@name=\"variants\"]")
    private WebElement variantsCheckbox;
    @FindBy(xpath = "//input[@name=\"product_image\"]")
    private WebElement productImgCheckbox;
    @FindBy(xpath = "//input[@name=\"check_promo\"]")
    private WebElement checkPromotionalPriceCheckbox;
    //div[@class="icheckbox_square-blue"]
//    @FindBy(xpath = "//div[@class=\"icheckbox_square-blue\"]")
//    @FindBy(xpath = "(//span[text()=\"Print:\"]//..)[1]//div")
    @FindBy(xpath = "//div[@class=\"icheckbox_square-blue\"]")
    private List<WebElement> listUnCheckbox;
    @FindBy(xpath = "(//div[@class=\"form-group\"])[7]//input")
    private WebElement updateButton;

    @FindBy(xpath = "(//span[@class=\"product_image\"]//.)[2]")
    private WebElement productImg;
    @FindBy(xpath = "//span[@class=\"barcode_site\"]")
    private WebElement barcodeSite;
    @FindBy(xpath = "//span[@class=\"barcode_name\"]")
    private WebElement barcodeName;
    @FindBy(xpath = "//span[@class=\"barcode_price\"]")
    private WebElement barcodePrice;
    @FindBy(xpath = "//span[@class=\"barcode_unit\"]")
    private WebElement barcodeUnit;
    @FindBy(xpath = "//span[@class=\"barcode_category\"]")
    private WebElement barcodeCategory;
    @FindBy(xpath = "//span[@class=\"barcode_image\"]//img")
    private WebElement barcodeImg;



    public void verifyDisplayBarcodeAfterAdd(String barcode_site, String barcode_name, String barcode_price, String barcode_unit
                                            , String barcode_category ){
        //6. The page display bar code with some info:
        //+ product_image
        //+ barcode_site: Stock Manager Advance
        //+ barcode_name: Kiwi
        //+ barcode_price: Price USD: 3.90, ERU: 2.86,
        //+ barcode_unit: Unit: 4
        //+ barcode_category: Category: Fruits
        //+ barcode_image
        getWebDriverWait().until(ExpectedConditions.visibilityOf(productImg));
        WebElement barcodesite = getWebDriverWait().until(ExpectedConditions.visibilityOf(barcodeSite));
        Assert.assertEquals(barcodesite.getText().toLowerCase(), barcode_site.toLowerCase());
        WebElement barcodename = getWebDriverWait().until(ExpectedConditions.visibilityOf(barcodeName));
        Assert.assertEquals(barcodename.getText().toLowerCase(), barcode_name.toLowerCase());
        WebElement barcodeprice = getWebDriverWait().until(ExpectedConditions.visibilityOf(barcodePrice));
        Assert.assertEquals(barcodeprice.getText().toLowerCase(), barcode_price.toLowerCase());
        WebElement barcodeunit = getWebDriverWait().until(ExpectedConditions.visibilityOf(barcodeUnit));
        Assert.assertEquals(barcodeunit.getText().toLowerCase(), barcode_unit.toLowerCase());
        WebElement barcodecategory = getWebDriverWait().until(ExpectedConditions.visibilityOf(barcodeCategory));
        Assert.assertEquals(barcodecategory.getText().toLowerCase(), barcode_category.toLowerCase());
        getWebDriverWait().until(ExpectedConditions.visibilityOf(barcodeImg));
    }
    @FindBy(xpath = "//ul[@id=\"ui-id-1\"]//li")
    private WebElement kiwiItem;

    public void createPrintBarcodeAndVerify(String productName, String productStyle) throws InterruptedException {
        //5. Add Kiwi product, Style: 18 per sheet (a4) (2.5" x 1.835") and select
        // print (site name, product name, price, Currencies, Unit, Category, Variants, Product Image, Check promotional price)
        WebElement productname = getWebDriverWait().until(ExpectedConditions.visibilityOf(addProductNameInput));
        productname.sendKeys("k");
        WebElement kiwiitem = getWebDriverWait().until(ExpectedConditions.visibilityOf(kiwiItem));
        kiwiitem.click();
        WebElement stylecbx=getWebDriverWait().until(ExpectedConditions.visibilityOf(style));
        styleCbx.click();
        WebElement stylevalue=getWebDriverWait().until(ExpectedConditions.visibilityOf(styleSelected));
        stylevalue.click();
        System.out.println();
        for (WebElement we:listUnCheckbox) {
            WebElement elementcheckbox=getWebDriverWait().until(ExpectedConditions.elementToBeClickable(we));
            elementcheckbox.click();
        }
        //6. Click to Update
        WebElement updatebtn = getWebDriverWait().until(ExpectedConditions.visibilityOf(updateButton));
        updatebtn.click();
    }
    public void verifyPrintBarcodeLabel_displayed(){
        //4. The Print Barcode/Label page displayed:Add Product, Style,
        // Print (site name, product name, price, Currencies, Unit, Category, Variants, Product Image, Check promotional price)
        for (WebElement we: listLabelVerify) {
            Assert.assertEquals(we.isDisplayed(), true);
        }
    }



}
