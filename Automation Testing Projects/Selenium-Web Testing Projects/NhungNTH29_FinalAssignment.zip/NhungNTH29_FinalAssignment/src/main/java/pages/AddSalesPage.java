package pages;

import core.BasePage;
import entity.Sales;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;

import java.time.Duration;

public class AddSalesPage extends BasePage {
    private RemoteWebDriver remoteWebDriver;
    public AddSalesPage(RemoteWebDriver webDriver) {
        super(webDriver);
        this.remoteWebDriver=webDriver;
    }
    @FindBy(xpath = "//div[@id=\"s2id_slcustomer\"]")
    private WebElement customerDropdown;
    @FindBy(xpath = "//input[@id=\"s2id_autogen12_search\"]")
    private WebElement customerDropdownInput;
    @FindBy(xpath = "(//ul[@id=\"select2-results-12\"]//li//div)[1]")
    private WebElement customerDropdownSelected;
    @FindBy(xpath = "(//div[@class=\"form-group\"])[6]//div//div/following-sibling::input")
    private WebElement addProductInput;
    @FindBy(xpath = "(//ul[@id=\"ui-id-1\"]//li)[1]")
    private WebElement addProductSelected;

    @FindBy(xpath = "//div[@class=\"fprom-group\"]//input")
    private WebElement submitAddSaleButton;
    @FindBy(xpath = "//div[@class=\"alert alert-success\"]")
    private WebElement addSuccessMessage;
    @FindBy(id="loading")
    private WebElement loading;

    public void addSales_and_Verify(Sales sales, String msg) throws InterruptedException {
        //add customer
        getWebDriverWait().until(ExpectedConditions.invisibilityOf(loading));
        WebElement customerdropdown=getWebDriverWait().until(ExpectedConditions.visibilityOf(customerDropdown));
        customerdropdown.click();
        WebElement customerInput=getWebDriverWait().until(ExpectedConditions.visibilityOf(customerDropdownInput));
        customerInput.sendKeys("a");
        getWebDriverWait().until(ExpectedConditions.elementToBeClickable(customerDropdownSelected));
        WebElement customerSelected=getWebDriverWait().until(ExpectedConditions.visibilityOf(customerDropdownSelected));
        customerSelected.click();
        //add product manually
        WebElement addProductinput=getWebDriverWait().until(ExpectedConditions.visibilityOf(addProductInput));
        addProductinput.sendKeys("ap");
        addProductinput.submit();
        getWebDriverWait().until(ExpectedConditions.visibilityOf(addProductSelected)).click();


        //submit Add Sale
        ((JavascriptExecutor) getRemoteWebDriver()).executeScript ("arguments[0].scrollIntoView();", submitAddSaleButton);
        WebElement submitSBtn=getWebDriverWait().until(ExpectedConditions.visibilityOf(submitAddSaleButton));
        submitSBtn.click();
        //6. Dispayled message : Sale successfully added
        WebElement addSuccessMsg=getWebDriverWait().until(ExpectedConditions.visibilityOf(addSuccessMessage));
        Assert.assertEquals(addSuccessMsg.getText().contains(msg), true);
    }


}
