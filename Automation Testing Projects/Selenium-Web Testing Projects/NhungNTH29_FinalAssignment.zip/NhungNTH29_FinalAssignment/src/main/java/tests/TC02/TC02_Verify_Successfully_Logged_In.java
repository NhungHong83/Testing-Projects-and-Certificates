package tests.TC02;

import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

import java.net.MalformedURLException;

public class TC02_Verify_Successfully_Logged_In extends BaseTest {
    public LoginPage loginPage;
    public String browsername;
    @Test (priority = 0)
    @Parameters({"browserName"})
    public void testNavigateAndVerifyLoginPage(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
        browsername=browserName;
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void testLoginSuccess(String TCID,String username,String password,String url,String message) throws MalformedURLException {
        loginPage.navigateTo(url);
        loginPage.login(username,password);
        HomePage homePage=new HomePage(getRemoteWD());
        homePage.verifyDashbroad(message);
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC02" ,1,0,5 );
    }
}
