package tests.TC07;

import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.PrintBarcodeLabelPage;

import java.net.MalformedURLException;

public class TC07_Verify_create_Print_Barcode_Label_successfully extends BaseTest {
    public LoginPage loginPage;
    public static String browsername;
    @Test(priority = 0)
    @Parameters({"browserName"})
    public void testNavigateAndVerifyLoginPage(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
        browsername=browserName;
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void testLoginSuccess(String TCID,String username,String password,String url)  {
        loginPage.navigateTo(url);
        loginPage.login(username,password);
    }
    @Test(priority = 2,dataProvider = "testdata_tc07")
    public void createPrintBarcode_and_verrify(String TCID,String barcode_name,String style, String barcode_site,
                                               String barcode_price, String barcode_unit, String barcode_category) throws InterruptedException {
        HomePage homePage=new HomePage(getRemoteWD());
        homePage.goToPrintBarcodeLabelPage();
        PrintBarcodeLabelPage printBarcodeLabelPage=new PrintBarcodeLabelPage(getRemoteWD());
        printBarcodeLabelPage.createPrintBarcodeAndVerify(barcode_name,style);
        printBarcodeLabelPage.verifyDisplayBarcodeAfterAdd(barcode_site,barcode_name,barcode_price,barcode_unit,barcode_category);
    }
    @DataProvider(name="testdata_tc07")
    public Object[][] getTestDataTC07(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC07" ,1,0,7 );
    }
    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC02" ,1,0,4 );
    }
}
