package tests.TC04;

import core.BaseTest;
import core.ExcelUtils;
import entity.Product;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductPage;

import java.net.MalformedURLException;

public class TC04_Verify_View_Product_Detail extends BaseTest {
    public LoginPage loginPage;
    @Test(priority = 0)
    @Parameters({"browserName"})
    public void testNavigateAndVerifyLoginPage(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void testLoginSuccess(String TCID,String username,String password,String url) throws MalformedURLException {
        loginPage.navigateTo(url);
        loginPage.login(username,password);
    }
    @Test(priority = 2,dataProvider = "testdata_tc04")
    public void verifyProductDetail(String TCID,String type, String name, String code, String category,String unit,
                                    String cost,String price, String taxRate, String taxMethod){
        HomePage homePage=new HomePage(getRemoteWD());
        homePage.goToProductPage();
        ProductPage productPage=new ProductPage(getRemoteWD());
        Product product=new Product(type,name,code,category,unit,cost, price,taxRate,taxMethod);
        productPage.openProductDetailPopupAndVerify(product);
    }
    @DataProvider(name="testdata_tc04")
    public Object[][] getTestDataTC04(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC04" ,1,0,10 );
    }
    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC02" ,1,0,4 );
    }

}
