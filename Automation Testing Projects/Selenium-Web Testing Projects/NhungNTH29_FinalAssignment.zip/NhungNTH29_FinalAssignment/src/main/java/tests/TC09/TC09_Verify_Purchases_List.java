package tests.TC09;

import core.BaseTest;
import core.ExcelUtils;
import entity.Sales;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.AddSalesPage;
import pages.HomePage;
import pages.LoginPage;
import pages.PurchasePage;

import java.net.MalformedURLException;
import java.text.ParseException;

public class TC09_Verify_Purchases_List extends BaseTest {
    public LoginPage loginPage;
    public static String browsername;
    @Test(priority = 0)
    @Parameters({"browserName"})
    public void testNavigateAndVerifyLoginPage(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
        browsername=browserName;
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void testLoginSuccess(String TCID,String username,String password,String url)  {
        loginPage.navigateTo(url);
        loginPage.login(username,password);
    }
    @Test(priority = 2,dataProvider = "testdata_tc09")
    public void TC09(String TCID, String formatDTime, String referNo,String numberPurchase) throws ParseException {
        HomePage homePage=new HomePage(getRemoteWD());
        homePage.goToPurchasePage();
        PurchasePage purchasePage=new PurchasePage(getRemoteWD());
        purchasePage.verifyPurchaseTable(formatDTime,referNo,numberPurchase);
    }
    @DataProvider(name="testdata_tc09")
    public Object[][] getTestDataTC09(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC09" ,1,0,4 );
    }
    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC02" ,1,0,4 );
    }
}
