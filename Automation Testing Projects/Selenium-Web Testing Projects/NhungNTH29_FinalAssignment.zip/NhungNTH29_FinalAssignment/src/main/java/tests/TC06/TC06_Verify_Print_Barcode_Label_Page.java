package tests.TC06;

import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;
import pages.PrintBarcodeLabelPage;
import pages.ProductPage;

import java.net.MalformedURLException;

public class TC06_Verify_Print_Barcode_Label_Page extends BaseTest {
    public LoginPage loginPage;
    @Test(priority = 0)
    @Parameters({"browserName"})
    public void testNavigateAndVerifyLoginPage(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void testLoginSuccess(String TCID,String username,String password,String url) throws MalformedURLException {
        loginPage.navigateTo(url);
        loginPage.login(username,password);
    }
    @Test(priority = 2)
    public void verifyPrintBarcodeLabelPage(){
        HomePage homePage=new HomePage(getRemoteWD());
        homePage.goToPrintBarcodeLabelPage();
        PrintBarcodeLabelPage printBarcodeLabelPage=new PrintBarcodeLabelPage(getRemoteWD());
        printBarcodeLabelPage.verifyPrintBarcodeLabel_displayed();
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC02" ,1,0,4 );
    }
}
