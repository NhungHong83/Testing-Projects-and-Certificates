package tests.TC01;

import core.BaseTest;
import core.ExcelUtils;
import org.openqa.selenium.Platform;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.LoginPage;

import java.net.MalformedURLException;
import java.net.URL;

//VD có 6 testcase thì tạo 6 class trong package tests này
public class TC01_Verify_Login_Page extends BaseTest {
    public LoginPage loginPage;
    @Test (priority = 0)
    @Parameters({"browserName"})
    public void test(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void TC01(String TCID,String url) throws MalformedURLException {
        loginPage.navigateTo(url);
        loginPage.verifyLoginPage();
    }

    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC01" ,1,0,2 );
    }

//    @Test
//    @Parameters({"browserName"})
//    public void testNavigateAndVerifyLoginPage(String browserName) throws MalformedURLException {
//        LoginPage loginPage=new LoginPage(getRemoteWebDriver(browserName));
//        loginPage.navigateTo("https://sma.tecdiary.net/admin");
//        loginPage.verifyLoginPage();
//    }



}
