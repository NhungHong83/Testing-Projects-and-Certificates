package tests.TC10;

import core.BaseTest;
import core.ExcelUtils;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pages.AddPurchasePage;
import pages.HomePage;
import pages.LoginPage;
import pages.PurchasePage;

import java.net.MalformedURLException;
import java.text.ParseException;

public class TC10_Verify_add_Purchases_successfully extends BaseTest {
    public LoginPage loginPage;
    public static String browsername;
    @Test(priority = 0)
    @Parameters({"browserName"})
    public void testNavigateAndVerifyLoginPage(String browserName) throws MalformedURLException {
        loginPage=new LoginPage(getRemoteWebDriver(browserName));
        browsername=browserName;
    }
    @Test (dataProvider = "testdata",priority = 1)
    public void testLoginSuccess(String TCID,String username,String password,String url)  {
        loginPage.navigateTo(url);
        loginPage.login(username,password);
    }
    @Test(priority = 2,dataProvider = "testdata_tc10")
    public void TC10(String TCID, String supplierKey, String productKey,String message) throws ParseException {
        HomePage homePage=new HomePage(getRemoteWD());
        homePage.goToAddPurchasePage();
        AddPurchasePage addPurchasePage=new AddPurchasePage(getRemoteWD());
        addPurchasePage.addPurchaseANdVerify(supplierKey,productKey,message);
    }
    @DataProvider(name="testdata_tc10")
    public Object[][] getTestDataTC10(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC10" ,1,0,4 );
    }
    @DataProvider(name="testdata")
    public Object[][] getTestData(){
        return ExcelUtils.getTableArray("E:\\Learn Automation Test\\AUT_Web\\final assignment\\NhungNTH29_FinalAssignment\\src\\main\\resources\\TestData\\TestData1.xlsx"
                , "TC02" ,1,0,4 );
    }
}
