package entity;

public class Product {
    private String image;
    private String barCode_QRCode;
    private String type;
    private String name;
    private String code;
    private String category;
    private String unit;
    private String cost;
    private String price;

    private String taxRate;
    private String taxMethod;
    private String alert;
    private String productDetail;

    public Product() {
    }

    public Product(String type, String name, String code, String category, String unit, String cost, String price, String taxRate, String taxMethod) {
        this.type = type;
        this.name = name;
        this.code = code;
        this.category = category;
        this.unit = unit;
        this.cost = cost;
        this.price = price;
        this.taxRate = taxRate;
        this.taxMethod = taxMethod;
    }

    public Product(String type, String name, String code, String category, String unit, String cost, String price, String taxRate, String taxMethod, String alert) {
        this.type = type;
        this.name = name;
        this.code = code;
        this.category = category;
        this.unit = unit;
        this.cost = cost;
        this.price = price;
        this.taxRate = taxRate;
        this.taxMethod = taxMethod;
        this.alert = alert;
    }

    public Product(String image, String barCode_QRCode, String type, String name, String code, String category, String unit, String cost, String price, String taxRate, String taxMethod, String alert, String productDetail) {
        this.image = image;
        this.barCode_QRCode = barCode_QRCode;
        this.type = type;
        this.name = name;
        this.code = code;
        this.category = category;
        this.unit = unit;
        this.cost = cost;
        this.price = price;
        this.taxRate = taxRate;
        this.taxMethod = taxMethod;
        this.alert = alert;
        this.productDetail = productDetail;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getBarCode_QRCode() {
        return barCode_QRCode;
    }

    public void setBarCode_QRCode(String barCode_QRCode) {
        this.barCode_QRCode = barCode_QRCode;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getTaxRate() {
        return taxRate;
    }

    public void setTaxRate(String taxRate) {
        this.taxRate = taxRate;
    }

    public String getTaxMethod() {
        return taxMethod;
    }

    public void setTaxMethod(String taxMethod) {
        this.taxMethod = taxMethod;
    }

    public String getAlert() {
        return alert;
    }

    public void setAlert(String alert) {
        this.alert = alert;
    }

    public String getProductDetail() {
        return productDetail;
    }

    public void setProductDetail(String productDetail) {
        this.productDetail = productDetail;
    }
}
