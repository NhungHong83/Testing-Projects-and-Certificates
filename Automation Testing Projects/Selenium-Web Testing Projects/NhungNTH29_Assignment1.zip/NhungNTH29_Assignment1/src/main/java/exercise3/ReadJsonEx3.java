package exercise3;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.type.TypeReference;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.List;

public class ReadJsonEx3 {

    @DataProvider(name="getColor")
    public static Object[][] credentials() throws FileNotFoundException {
        return getColors();
    }

    @Test( dataProvider = "getColor")
    public void test(Color color){
        System.out.println("color: "+color.getColor() + " - value: "+color.getValue());
    }


    public static Object[][] getColors() throws FileNotFoundException {
        JsonElement jsonData = new JsonParser().parse(new FileReader("color.json"));
        List<Color> testData = new Gson().fromJson(jsonData, new TypeToken<List<Color>>() {}.getType());
        Object[][] returnValue = new Object[testData.size()][1];
        int index = 0;
        for (Object[] each : returnValue) {
            each[0] = testData.get(index++);
        }
        return returnValue;
    }
}
