package exercise3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.io.IOException;
import java.time.Duration;
import java.util.Set;

public class Ex3 {

    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        driver.navigate().to("https://www.w3schools.com/html/tryit.asp?filename=tryhtml_iframe_height_width");

        WebDriverWait webDriverWait=new WebDriverWait(driver, Duration.ofSeconds(10));
        //4. Get and webDriverWait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[@title=\"Iframe Example\"]")));Check expected text as “This page is displayed in an iframe”
        webDriverWait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.id("iframeResult")));
        webDriverWait.until(ExpectedConditions.frameToBeAvailableAndSwitchToIt(By.xpath("//iframe[@title=\"Iframe Example\"]")));
        try{
            WebElement expectedText=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[text()=\"This page is displayed in an iframe\"]")));
        }catch (Exception e){
            System.out.println(e.getMessage());
        }



    }
}
