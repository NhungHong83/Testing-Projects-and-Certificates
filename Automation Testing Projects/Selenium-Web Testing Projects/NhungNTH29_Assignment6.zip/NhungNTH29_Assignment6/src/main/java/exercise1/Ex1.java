package exercise1;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;

import static org.testng.Assert.assertEquals;

public class Ex1 {
    @Test
    public void test() throws InterruptedException, IOException, AWTException {
        /*
        1. Open Chrome browser
        2. Maximize the browser window
        3. Navigate to https://www.seleniumeasy.com/test/javascript-alert-box-demo.html webpage
        4. In Java Script Alert Box, click “Click Me” and Capture the alert’s text.
        */
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        driver.navigate().to("http://demo.seleniumeasy.com/javascript-alert-box-demo.html");

        WebDriverWait webDriverWait=new WebDriverWait(driver, Duration.ofSeconds(5));

        WebElement  clickMeButton=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[@class=\"btn btn-default\"]")));
        clickMeButton.click();
        webDriverWait.until(ExpectedConditions.alertIsPresent());
        Alert alert=driver.switchTo().alert();

        BufferedImage image = new Robot().createScreenCapture(new java.awt.Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        ImageIO.write(image, "png", new File("E://image_"+ System.currentTimeMillis() +".png"));
        alert.accept();

        /*
        1. In Java Script Confirm Box, click “Click Me”.
        2. Get the alert’s text and click OK button
        3. Check Expected test as “You pressed OK”
        */
        WebElement confirmBoxButton=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()=\"Click me!\"][@class=\"btn btn-default btn-lg\"]")));
        confirmBoxButton.click();
        webDriverWait.until(ExpectedConditions.alertIsPresent());
        alert=driver.switchTo().alert();
        System.out.println("Get the alert’s text: "+alert.getText());
        alert.accept();

        WebElement messagePressOK=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("confirm-demo")));
        assertEquals("You pressed OK!",messagePressOK.getText());

        /*
        4. In Java Script Alert Box, click “Click for Prompt Box”
        5. Input your name.
        6. Click OK button and verify message “You have entered 'Enter name'!”
        7. Close browser
        */
        WebElement promptBoxButton=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//button[text()=\"Click for Prompt Box\"][@class=\"btn btn-default btn-lg\"]")));
        promptBoxButton.click();
        webDriverWait.until(ExpectedConditions.alertIsPresent());
        alert=driver.switchTo().alert();
        String name="Nhung";
        alert.sendKeys(name);
        alert.accept();

        WebElement messagePrompt=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("prompt-demo")));
        assertEquals("You have entered '"+name+"' !",messagePrompt.getText());

        driver.close();
    }
}
