package exercise2;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.Duration;
import java.util.Iterator;
import java.util.Set;

import static org.testng.Assert.assertEquals;

public class Ex2 {
    @Test
    public void test() throws InterruptedException, IOException, AWTException {
        /*
        1. Open Chrome browser
        2. Maximize the browser window
        */
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();

        //3. Navigate to https://www.seleniumeasy.com/test/window-popup-modal-demo.html page.
        driver.navigate().to("http://demo.seleniumeasy.com/window-popup-modal-demo.html");

        WebDriverWait webDriverWait=new WebDriverWait(driver, Duration.ofSeconds(5));

        //4. Click Follow On Twitter
        WebElement followTwitterButton=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()=\"  Follow On Twitter \"]")));
        followTwitterButton.click();

        //5. Switch to windows and get title page
        String parent=driver.getWindowHandle();
        Set<String> listWindows = driver.getWindowHandles();
        for (String w : listWindows) {
            driver.switchTo().window(w);
            try {
                webDriverWait.until(ExpectedConditions.titleContains("Twitter"));
                System.out.println(driver.getTitle());
                driver.close();
            }catch (Exception e) {

            }
        }

        //6. Back to windows parent and click Like us On Facebook.
        driver.switchTo().window(parent);
        WebElement likeOnFBButton=webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//a[text()=\"  Like us On Facebook \"]")));
        likeOnFBButton.click();

        //7. Switch to windows and get title page.
        Set<String> lsWindows = driver.getWindowHandles();
        for (String w : lsWindows) {
            if(!w.equals(parent)){
                driver.switchTo().window(w);
                System.out.println(driver.getTitle());
                driver.close();
//                try {
//                    webDriverWait.until(ExpectedConditions.titleContains("Hyderabad"));
//                    System.out.println(driver.getTitle());
//                    driver.close();
//                }catch (Exception e) {
//
//                }
            }
        }
        //8. Close brower
        driver.switchTo().window(parent);
        driver.close();
    }
}
