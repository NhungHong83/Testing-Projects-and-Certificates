package exercise4;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

public class Ex4 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new EdgeDriver();
        driver.get("https://www.lazada.vn/");
        // Maximize the browser
        driver.manage().window().maximize();
        Thread.sleep(1000);
        String text="LAZADA";
        String title= driver.getTitle();
        System.out.println(title);
        assertEquals(title.contains(text),true);
    }
}
