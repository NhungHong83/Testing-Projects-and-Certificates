package exercise1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class Ex1 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.google.com/");
        driver.manage().window().maximize();
        Thread.sleep(1000);
        driver.navigate().to("https://tiki.vn/");
        WebElement name=driver.findElement(By.xpath("//input[@data-view-id=\"main_search_form_input\"]"));
        name.sendKeys("vay hoa nhi");

        WebElement searchButton=driver.findElement(By.xpath("//button[@data-view-id=\"main_search_form_button\"]"));
        searchButton.click();
        Thread.sleep(1000);
        WebElement firstProduct=driver.findElement(By.xpath("(//div//div//h3)[1]"));
        firstProduct.click();
        WebElement title=driver.findElement(By.xpath("//h1[@class=\"title\"]"));
        WebElement price=driver.findElement(By.className("product-price__current-price"));
        System.out.println(title.getText()+" - "+price.getText());
    }
}
