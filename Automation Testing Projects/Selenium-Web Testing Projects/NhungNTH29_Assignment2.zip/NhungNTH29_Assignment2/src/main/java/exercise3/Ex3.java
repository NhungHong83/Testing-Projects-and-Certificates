package exercise3;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;
import static org.testng.AssertJUnit.assertTrue;

public class Ex3 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new FirefoxDriver();
        driver.get("https://www.amazon.com/");
        // Maximize the browser
        driver.manage().window().maximize();
        Thread.sleep(1000);
        String text="amazon.com";
        String title= driver.getTitle();
        System.out.println(title);
        assertEquals(title.contains(text),true);
    }
}
