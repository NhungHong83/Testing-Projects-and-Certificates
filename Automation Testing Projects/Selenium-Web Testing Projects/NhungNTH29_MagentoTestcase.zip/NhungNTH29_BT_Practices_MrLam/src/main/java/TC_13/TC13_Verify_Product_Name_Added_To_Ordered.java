package TC_13;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC13_Verify_Product_Name_Added_To_Ordered {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();
        Thread.sleep(1000);
        driver.navigate().refresh();
        Thread.sleep(1000);

        //4. Click to the Sales -> Orders on the left menu.
        WebElement saleButton=driver.findElement(By.xpath("//a//span[text()=\"Sales\"]"));
        saleButton.click();
        Thread.sleep(1000);
        WebElement orderButton=driver.findElement(By.xpath("//li[@data-ui-id=\"menu-magento-sales-sales-order\"]"));
        orderButton.click();
        Thread.sleep(5000);

        //5. Click to the Create New Order
        WebElement createOrderButton=driver.findElement(By.xpath("//button[@id=\"add\"]"));
        createOrderButton.click();

        //6. Select first customer
        WebElement firstRow=driver.findElement(By.xpath("(//tr[@data-role=\"row\"])[1]"));
        firstRow.click();
        Thread.sleep(2000);

        //7. Click to the Add Products
        WebElement addProduct = driver.findElement(By.id("add_products"));
        addProduct.click();

        //8. Search and Select 4 products
        // - Erika Running Short-32-Green
        // - Erika Running Short-32-Purple
        // - Erika Running Short-32-Red
        // - ProdI-Conf
        String[] strings ={"Erika Running Short-32-Green","Erika Running Short-32-Purple","Erika Running Short-32-Red"};
        for(int i = 0; i< strings.length; i++){
            WebElement reset = driver.findElement(By.xpath("(//button[@title=\"Reset Filter\"])[2]"));
            reset.click();
            Thread.sleep(1000);
            WebElement searchName = driver.findElement(By.id("sales_order_create_search_grid_filter_name"));
            searchName.sendKeys(strings[i]);
            Thread.sleep(1000);
            WebElement searchButton = driver.findElement(By.xpath("(//button[@data-ui-id=\"widget-button-4\"])[2]"));
            searchButton.click();
            Thread.sleep(1000);
            WebElement checkbox = driver.findElement(By.xpath("(//tbody)[2]//tr//input[@type=\"checkbox\"]"));
            checkbox.click();
        }


        //9. Click to the Add Selected Product(s) to Order
        WebElement addButton = driver.findElement(By.xpath("//span[contains(text(),\"Add Selected\")]//parent::button"));
        addButton.click();
        Thread.sleep(2000);

        WebElement firstProduct = driver.findElement(By.xpath("//table[@class=\"data-table admin__table-primary order-tables\"]//tbody//td[@class=\"col-product\"]/span"));
        Assert.assertEquals(firstProduct.getText(),strings[0]);

        WebElement secondProduct = driver.findElement(By.xpath("(//table[@class=\"data-table admin__table-primary order-tables\"]//tbody//td[@class=\"col-product\"]/span)[2]"));
        Assert.assertEquals(secondProduct.getText(),strings[1]);

        WebElement thirdProduct = driver.findElement(By.xpath("(//table[@class=\"data-table admin__table-primary order-tables\"]//tbody//td[@class=\"col-product\"]/span)[3]"));
        Assert.assertEquals(thirdProduct.getText(),strings[2]);

        //10. Add Shipping Method: Table Rate
        WebElement shipping = driver.findElement(By.xpath("//span[contains(text(),\"Get shipping methods\")]//parent::a"));
        shipping.click();
        Thread.sleep(1000);
//        WebElement flat = driver.findElement(By.name("order[shipping_method]"));
//        flat.click();
//        Thread.sleep(1000);


        //11. Click to submit order
        WebElement submit = driver.findElement(By.xpath("(//span[contains(text(),\"Submit\")]/parent::button)[2]"));
        submit.click();
        Thread.sleep(1000);

        //12. Verify
        WebElement message = driver.findElement(By.xpath("//div[@data-ui-id=\"messages-message-success\"]"));
        Assert.assertEquals(message.getText(),"You created the order.");



        Thread.sleep(5000);
        driver.close();
    }
}
