package TC_04;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC04_Verify_Product_Page {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();
        Thread.sleep(1000);
        driver.navigate().refresh();
        Thread.sleep(1000);

        //4. Click to the Catalog on the left menu.
        //5. Click to the Products
        WebElement catalogButton=driver.findElement(By.xpath("//a//span[text()=\"Catalog\"]"));
        catalogButton.click();
        Thread.sleep(1000);
        Actions actions=new Actions(driver);
        WebElement productButton=driver.findElement(By.xpath("(//span[text()=\"Products\"])[1]"));
        productButton.click();
//        actions.contextClick(catalogButton).moveToElement(productButton).click().perform();
        Thread.sleep(5000);

        //Verify result
        try{// Add product button
            WebElement addProductButton=driver.findElement(By.xpath("//button//span[text()=\"Add Product\"]"));
        }catch (Exception e){
            System.out.println("Add Product Button is not exist");
        }
        try{//Search Key
            WebElement searchKeyInput=driver.findElement(By.xpath("//input[@id=\"search-global\"]"));
        }catch (Exception e){
            System.out.println("Search Key Item is not exist");
        }
        try{//- Filters button
            WebElement filterButton=driver.findElement(By.xpath("(//div//button[@class=\"action-default\"])[1]"));
            assertEquals("Filters",filterButton.getText());
        }catch (Exception e){
            System.out.println("filter Button is not exist");
        }
        try{//New view
            WebElement defaultView=driver.findElement(By.xpath("(//span[@class=\"admin__action-dropdown-text\"][text()=\"Default View\"])[1]"));
            WebElement saveNewViewAs=driver.findElement(By.xpath("(//a[text()=\"Save View As...\"])[1]"));
            WebElement newView=driver.findElement(By.xpath("(//div[@class=\"action-dropdown-menu-item-edit\"]//input[@class=\"admin__control-text\"])[1]"));
            actions.contextClick(defaultView).moveToElement(saveNewViewAs).click().moveToElement(newView).click().perform();
        }catch (Exception e){
            System.out.println("New view is not exist");
        }
        try{//Columns
            WebElement columnFilter=driver.findElement(By.xpath("(//span[@class=\"admin__action-dropdown-text\"][text()=\"Columns\"])[1]"));
            assertEquals("Columns",columnFilter.getText());
        }catch (Exception e){
            System.out.println("Columns is not exist");
        }
        //Table listout product.
        try{
            WebElement table=driver.findElement(By.xpath("//table[@class=\"data-grid data-grid-draggable\"][@data-role=\"grid\"]"));
        }catch (Exception e){
            System.out.println("Table listout product is not exist");
        }

        Thread.sleep(5000);
        driver.close();
    }
}
