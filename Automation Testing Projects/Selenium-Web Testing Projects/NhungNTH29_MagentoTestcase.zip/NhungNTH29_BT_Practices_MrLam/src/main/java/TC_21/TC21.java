package TC_21;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TC21 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        WebElement username = driver.findElement(By.id("username"));
        username.sendKeys("admin");
        WebElement password = driver.findElement(By.name("login[password]"));
        password.sendKeys("admin123");
        WebElement signInButton = driver.findElement(By.xpath("//button"));
        signInButton.click();

        Thread.sleep(3000);
        driver.navigate().refresh();
        Thread.sleep(3000);

        WebElement stores = driver.findElement(By.xpath("//li[@data-ui-id=\"menu-magento-backend-stores\"]"));
        stores.click();
        Thread.sleep(1000);

        WebElement allStores = driver.findElement(By.xpath("//li[@data-ui-id=\"menu-magento-backend-system-store\"]"));
        allStores.click();
        Thread.sleep(2000);

        WebElement createStore = driver.findElement(By.id("add_group"));
        createStore.click();
        Thread.sleep(2000);

        WebElement website = driver.findElement(By.xpath("//span[contains(text(),\"Web Site\")]"));
        if (website.isDisplayed()){
            System.out.println("Web Site is displayed!");
        }

        WebElement name = driver.findElement(By.xpath("//span[contains(text(),\"Name\")]"));
        if (name.isDisplayed()){
            System.out.println("Name is displayed!");
        }

        WebElement code = driver.findElement(By.xpath("//span[contains(text(),\"Code\")]"));
        if (code.isDisplayed()){
            System.out.println("Code is displayed!");
        }

        WebElement root = driver.findElement(By.xpath("//span[contains(text(),\"Root\")]"));
        if (root.isDisplayed()){
            System.out.println("Root Category is displayed!");
        }

        Thread.sleep(1000);
        driver.close();
    }
}
