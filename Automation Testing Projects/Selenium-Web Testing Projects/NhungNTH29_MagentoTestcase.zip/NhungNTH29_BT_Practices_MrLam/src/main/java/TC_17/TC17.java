package TC_17;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC17 {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();

        //4. Click to the Marketing -> Catalog Price Rule on the left menu.
        WebElement marketingButton=driver.findElement(By.xpath("//span[text()=\"Marketing\"]/.."));
        WebElement catalogPriceRuleButton=driver.findElement(By.xpath("//span[text()=\"Catalog Price Rule\"]/.."));
        Actions actions=new Actions(driver);
        actions.contextClick(marketingButton).moveToElement(catalogPriceRuleButton).click().perform();

        //5. click to Add New Rule
        WebElement addRuleButton=driver.findElement(By.xpath("//span[text()=\"Add New Rule\"]/.."));
        addRuleButton.click();

        //6.
        // + Input  Rule Name: test
        WebElement ruleName=driver.findElement(By.xpath("//input[@id=\"NA0EUXA\"]"));
        ruleName.sendKeys("test");
        // +  Active: Yes
        //default
        // + Websites : Main Website

        // + Customer Groups : General
        Select cusGroup=new Select(driver.findElement(By.id("F2KHEI9")));
        cusGroup.selectByValue("1");
        // + Discount Amount: 10
        WebElement moreIn4=driver.findElement(By.xpath("(//div[@class=\"fieldset-wrapper-title\"])[3]"));
        moreIn4.click();
        WebElement discountAmount=driver.findElement(By.xpath("//input[@id=\"ETA9E9B\"]"));
        discountAmount.sendKeys("10");


        //7. Click Save button
        WebElement saveButton=driver.findElement(By.xpath("//button[@id=\"save\"]"));
        saveButton.click();

        //Verify - 7. The message should be displayed: You saved the rule.
        try{
            WebElement message=driver.findElement(By.xpath("//div[@data-ui-id=\"messages-message-success\"]"));
            assertEquals("You saved the rule.",message.getText());
        }catch (Exception e){
            System.out.println("Failed in action: The message should be displayed: You saved the rule.");
        }

        Thread.sleep(5000);
        driver.close();
    }
}
