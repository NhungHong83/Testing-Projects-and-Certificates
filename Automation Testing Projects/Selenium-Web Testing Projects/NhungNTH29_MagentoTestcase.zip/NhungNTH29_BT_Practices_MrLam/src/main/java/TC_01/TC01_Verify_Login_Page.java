package TC_01;

import org.openqa.selenium.By;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.Set;

import static org.testng.Assert.assertEquals;

public class TC01_Verify_Login_Page {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();



        //Verify result
        WebElement incomingMessage=driver.findElement(By.xpath("(//h1)[2]"));
        assertEquals("Incoming Message",incomingMessage.getText());

        Thread.sleep(5000);
        driver.close();
    }
}
