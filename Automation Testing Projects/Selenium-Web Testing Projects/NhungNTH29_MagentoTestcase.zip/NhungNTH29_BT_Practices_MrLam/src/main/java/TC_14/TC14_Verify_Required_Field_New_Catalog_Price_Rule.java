package TC_14;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class TC14_Verify_Required_Field_New_Catalog_Price_Rule {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();
        Thread.sleep(1000);
        driver.navigate().refresh();
        Thread.sleep(1000);

        //4. Click to the Marketing -> Catalog Price Rule on the left menu.
        WebElement marketingButton=driver.findElement(By.xpath("//span[text()=\"Marketing\"]/.."));
        marketingButton.click();
        Thread.sleep(1000);
        WebElement catalogPriceRuleButton=driver.findElement(By.xpath("//span[text()=\"Catalog Price Rule\"]/.."));
        catalogPriceRuleButton.click();
        Thread.sleep(2000);

        //5. click to Add New Rule
        WebElement addRuleButton=driver.findElement(By.xpath("//span[text()=\"Add New Rule\"]/.."));
        addRuleButton.click();

        //6. Click Save button
        WebElement saveButton=driver.findElement(By.xpath("//button[@id=\"save\"]"));
        saveButton.click();
        Thread.sleep(1000);

        //Verify - 6. The message for earch required field should be displayed: This is a required field.
        try{
            WebElement nameRequire = driver.findElement(By.xpath("//label[@class=\"admin__field-error\"]"));
            Assert.assertEquals(nameRequire.getText(),"This is a required field.");

            WebElement webRequire = driver.findElement(By.xpath("(//label[@class=\"admin__field-error\"])[2]"));
            Assert.assertEquals(webRequire.getText(),"This is a required field.");

            WebElement groupRequire = driver.findElement(By.xpath("(//label[@class=\"admin__field-error\"])[3]"));
            Assert.assertEquals(groupRequire.getText(),"This is a required field.");
        }catch (Exception e){
            System.out.println("Failed in action: The message for earch required field should be displayed: This is a required field.");
        }


        Thread.sleep(5000);
        driver.close();
    }
}
