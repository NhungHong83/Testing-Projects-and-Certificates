package TC_08;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class TC8 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        WebElement username = driver.findElement(By.id("username"));
        username.sendKeys("admin");
        WebElement password = driver.findElement(By.name("login[password]"));
        password.sendKeys("admin123");
        WebElement signInButton = driver.findElement(By.xpath("//button"));
        signInButton.click();

        Thread.sleep(3000);
        driver.navigate().refresh();
        Thread.sleep(3000);

        WebElement stores = driver.findElement(By.xpath("//li[@data-ui-id=\"menu-magento-backend-stores\"]"));
        stores.click();
        Thread.sleep(1000);

        WebElement product = driver.findElement(By.xpath("//li[@data-ui-id=\"menu-magento-catalog-catalog-attributes-attributes\"]"));
        product.click();
        Thread.sleep(3000);

        WebElement addButton = driver.findElement(By.id("add"));
        addButton.click();
        Thread.sleep(3000);

        WebElement advance = driver.findElement(By.xpath("(//strong[@class=\"admin__collapsible-title\"])[1]"));
        advance.click();
        Thread.sleep(1000);

        WebElement inputAttribute = driver.findElement(By.id("attribute_label"));
        if (inputAttribute.isDisplayed()){
            System.out.println("Default Label text is displayed!");
        }

        WebElement type = driver.findElement(By.id("frontend_input"));
        if (type.isDisplayed()){
            System.out.println("Catalog Input Type for Store Owner combobox is displayed!");
        }

        WebElement require = driver.findElement(By.id("is_required"));
        if (require.isDisplayed()){
            System.out.println("Values Required combobox is displayed!");
        }

        WebElement attribute = driver.findElement(By.id("attribute_code"));
        if (attribute.isDisplayed()){
            System.out.println("Attribute Code is displayed!");
        }

        WebElement scope = driver.findElement(By.xpath("//div[@class=\"admin__field field field-is_global  with-note\"]"));
        if (scope.isDisplayed()){
            System.out.println("Scope is displayed!");
        }

        WebElement defaultValue = driver.findElement(By.xpath("//div[@class=\"admin__field field field-default_value_text \"]"));
        if (defaultValue.isDisplayed()){
            System.out.println("Default Value is displayed!");
        }

        WebElement unique = driver.findElement(By.xpath("//div[@class=\"admin__field field field-is_unique  with-note\"]"));
        if (unique.isDisplayed()){
            System.out.println("Unique Value is displayed!");
        }

        WebElement inputValid = driver.findElement(By.xpath("//div[@class=\"admin__field field field-frontend_class \"]"));
        if (inputValid.isDisplayed()){
            System.out.println("Input Validation for Store Owner is displayed!");
        }

        WebElement option = driver.findElement(By.xpath("//div[@class=\"admin__field field field-is_used_in_grid  with-note\"]"));
        if (option.isDisplayed()){
            System.out.println("Add to Column Options is displayed!");
        }

        WebElement useFilter = driver.findElement(By.xpath("//div[@class=\"admin__field field field-is_filterable_in_grid  with-note\"]"));
        if (useFilter.isDisplayed()){
            System.out.println("Use in Filter Options is displayed!");
        }

        Thread.sleep(1000);
        driver.close();
    }
}