package TC_15;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.io.IOException;
import java.util.List;

import static org.testng.Assert.assertEquals;

public class TC15 {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();
        Thread.sleep(1000);
        driver.navigate().refresh();
        Thread.sleep(1000);

        //4. Click to the Marketing -> Catalog Price Rule on the left menu.
        WebElement marketingButton=driver.findElement(By.xpath("//span[text()=\"Marketing\"]/.."));
        marketingButton.click();
        Thread.sleep(1000);
        WebElement catalogPriceRuleButton=driver.findElement(By.xpath("//span[text()=\"Catalog Price Rule\"]/.."));
        catalogPriceRuleButton.click();
        Thread.sleep(2000);

        //5. click to Add New Rule
        WebElement addRuleButton=driver.findElement(By.xpath("//span[text()=\"Add New Rule\"]/.."));
        addRuleButton.click();
        Thread.sleep(1000);

        //6.
        // + Input  Rule Name: test
        WebElement ruleName = driver.findElement(By.name("name"));
        ruleName.sendKeys("test");
        // +  Active: Yes
        Select status = new Select(driver.findElement(By.name("is_active")));
        status.selectByValue("1");
        //default
        // + Websites : Main Website
        Select website = new Select(driver.findElement(By.name("website_ids")));
        website.selectByValue("1");

        // + Customer Groups : General
        Select groups = new Select(driver.findElement(By.name("customer_group_ids")));
        groups.selectByValue("1");
        Thread.sleep(1000);

        //7. Click Save button
        WebElement saveButton=driver.findElement(By.xpath("//button[@id=\"save\"]"));
        saveButton.click();
        Thread.sleep(1000);

        //Verify - 7. The message for  Discount Amount field should be displayed: This is a required field.
        try{
            WebElement errorText=driver.findElement(By.xpath("//label[@class=\"admin__field-error\"]"));
            assertEquals("This is a required field",errorText.getText());
        }catch (Exception e){
            System.out.println("Failed in action: The message for  Discount Amount field should be displayed: This is a required field");
        }

        Thread.sleep(5000);
        driver.close();
    }
}
