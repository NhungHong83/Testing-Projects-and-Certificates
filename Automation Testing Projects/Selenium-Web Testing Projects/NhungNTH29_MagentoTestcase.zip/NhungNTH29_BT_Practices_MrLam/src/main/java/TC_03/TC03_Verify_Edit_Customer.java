package TC_03;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import java.io.IOException;

import static org.testng.Assert.assertEquals;

public class TC03_Verify_Edit_Customer {
    @Test
    public void test() throws InterruptedException, IOException {
        WebDriver driver=new ChromeDriver();

        //1. Open the browser for scipioerp website: http://139.162.47.20/magento222/admin
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //2. input username: admin and password: admin123
        WebElement username=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        username.sendKeys("admin");
        WebElement pass=driver.findElement(By.xpath("//input[@id=\"login\"]"));
        pass.sendKeys("admin123");

        //3. Click to Signin button
        WebElement signInButton=driver.findElement(By.xpath("//button//span[text()=\"Sign in\"]"));
        signInButton.click();
        Thread.sleep(3000);
        driver.navigate().refresh();
        Thread.sleep(3000);

        //4. Click to the Customers on the left menu.
        //5. Click to the All Customers
        WebElement customerButton=driver.findElement(By.xpath("(//span[text()=\"Customers\"])[1]"));
        customerButton.click();
        Thread.sleep(1000);
        WebElement allCustomerButton=driver.findElement(By.xpath("(//span[text()=\"All Customers\"])[1]"));
        allCustomerButton.click();
        Thread.sleep(1000);

        //6. Input search key: Marie Delabre
        WebElement searchKey=driver.findElement(By.xpath("(//input[@id=\"fulltext\"])[1]"));
        searchKey.sendKeys("Marie Delabre");

        //Click search Button
        Thread.sleep(3000);
        WebElement searchButton=driver.findElement(By.xpath("(//button[@class=\"action-submit\"])[2]"));
        searchButton.click();
        Thread.sleep(1000);

        //7. Click edit
        WebElement editButton=driver.findElement(By.xpath("//a[@class=\"action-menu-item\"]"));
        editButton.click();
        Thread.sleep(1000);

        //8. Click to the Account Information
        WebElement accInforButton=driver.findElement(By.xpath("//span[text()=\"Account Information\"]"));
        accInforButton.click();
        Thread.sleep(1000);

        //Verify result
        WebElement accInforMessage=driver.findElement(By.xpath("//span[text()=\"Account Information\"][@data-bind=\"i18n: label\"]"));
        assertEquals("Account Information",accInforMessage.getText());
        Thread.sleep(5000);
        driver.close();
    }
}
