package TC_22;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;

public class TC22 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver = new ChromeDriver();
        driver.get("http://139.162.47.20/magento222/admin");
        driver.manage().window().maximize();
        Thread.sleep(1000);

        WebElement username = driver.findElement(By.id("username"));
        username.sendKeys("admin");
        WebElement password = driver.findElement(By.name("login[password]"));
        password.sendKeys("admin123");
        WebElement signInButton = driver.findElement(By.xpath("//button"));
        signInButton.click();

        Thread.sleep(3000);
        driver.navigate().refresh();
        Thread.sleep(3000);

        WebElement stores = driver.findElement(By.xpath("//li[@data-ui-id=\"menu-magento-backend-stores\"]"));
        stores.click();
        Thread.sleep(1000);

        WebElement allStores = driver.findElement(By.xpath("//li[@data-ui-id=\"menu-magento-backend-system-store\"]"));
        allStores.click();
        Thread.sleep(2000);

        WebElement createStore = driver.findElement(By.id("add_group"));
        createStore.click();
        Thread.sleep(2000);

        Select website = new Select(driver.findElement(By.id("group_website_id")));
        website.selectByValue("1");

        WebElement name = driver.findElement(By.id("group_name"));
        name.sendKeys("Nike");

        WebElement codeInput = driver.findElement(By.id("group_code"));
        codeInput.sendKeys("1100868");

        Select rootInput = new Select(driver.findElement(By.id("group_root_category_id")));
        rootInput.selectByValue("2");

        WebElement save = driver.findElement(By.id("save"));
        save.click();
        Thread.sleep(3000);

        WebElement message = driver.findElement(By.xpath("//div[@data-ui-id=\"messages-message-success\"]"));
        Assert.assertEquals(message.getText(),"You saved the store.");

        Thread.sleep(1000);
        driver.close();
    }
}
