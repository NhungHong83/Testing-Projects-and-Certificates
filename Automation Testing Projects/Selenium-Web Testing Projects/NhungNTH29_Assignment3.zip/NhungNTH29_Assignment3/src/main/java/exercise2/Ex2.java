package exercise2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;

public class Ex2 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.walmart.com/ip/VIZIO-70-Class-4K-UHD-LED-SmartCast-Smart-TV-HDR-V-Series-V705-G3/936515428");
        driver.manage().window().maximize();
        Thread.sleep(3000);

        //Title product
        WebElement titleProduct_byClass=driver.findElement(By.className("f3 b lh-copy dark-gray mt1 mb2"));
        WebElement titleProduct_byXpath=driver.findElement(By.xpath("//h1[@class=\"f3 b lh-copy dark-gray mt1 mb2\"]"));

        //Price of product
        WebElement priceProduct_byXpath=driver.findElement(By.xpath("(//span[@itemprop=\"price\"])[2]"));

        //Add to list
        WebElement addToList_byXpath=driver.findElement(By.xpath("(//button[@class=\"bg-transparent bn lh-solid pa0 sans-serif tc underline inline-button black pointer f6\"])[2]"));

        //Add to Registry
        WebElement addToRegistry_byXpath=driver.findElement(By.xpath("(//button[@class=\"bg-transparent bn lh-solid pa0 sans-serif tc underline inline-button black pointer f6\"])[3]"));

        driver.close();
    }
}
