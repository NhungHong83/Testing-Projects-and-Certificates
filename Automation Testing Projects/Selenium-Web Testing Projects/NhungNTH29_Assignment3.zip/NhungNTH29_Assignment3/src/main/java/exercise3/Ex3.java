package exercise3;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import static org.testng.AssertJUnit.assertEquals;

public class Ex3 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.booking.com/");
        // Maximize the browser
        driver.manage().window().maximize();
        Thread.sleep(3000);

        WebElement signinButton=driver.findElement(By.xpath("(//a[@class=\"bui-button bui-button--secondary js-header-login-link\"])[1]"));
        signinButton.click();

        //Email Address textbox
        WebElement email_byId=driver.findElement(By.id("username"));
        WebElement email_byName=driver.findElement(By.name("username"));
        WebElement email_byClass=driver.findElement(By.className("ZMH9h0HCYH9GGNxHnXGJ"));
        WebElement email_byXpath=driver.findElement(By.xpath("//input[@id=\"username\"]"));
        System.out.println("Email Address textbox");
        System.out.println(email_byId.getAttribute("id") +"  "+ email_byName.getAttribute("id")
                +"   "+ email_byClass.getAttribute("id")+"   "+email_byXpath.getAttribute("id"));


        //Get started button
        WebElement getStartButton_byClass=driver.findElement(By.className("whxYYRnvyHGyGqxO4ici"));
        WebElement getStartButton_byXpath=driver.findElement(By.xpath("//button[@class=\"Iiab0gVMeWOd4XcyJGA3 wPxWIS_rJCpwAWksE0s3 Ut3prtt_wDsi7NM_83Jc TuDOVH9WFSdot9jLyXlw EJWUAldA4O1mP0SSFXPm whxYYRnvyHGyGqxO4ici\"]"));
        System.out.println("Get started button");
        System.out.println(getStartButton_byClass.getAttribute("type")+"   "+getStartButton_byXpath.getAttribute("type"));

        //Sign up with Facebook
        WebElement signUp_byClass=driver.findElement(By.className("nw-social-btn-facebook"));
        WebElement signUp_byXpath=driver.findElement(By.xpath("//a[@ class=\"access-panel__social-button access-panel__social-button-facebook bui-button bui-button--secondary nw-social-btn-facebook \" ]"));
        System.out.println("Sign up with Facebook");
        System.out.println(signUp_byClass.getAttribute("title")+"   "+signUp_byXpath.getAttribute("title"));

        driver.close();
    }
}
