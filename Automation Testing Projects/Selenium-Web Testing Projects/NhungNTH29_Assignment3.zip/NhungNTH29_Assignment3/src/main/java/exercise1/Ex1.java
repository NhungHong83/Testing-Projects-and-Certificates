package exercise1;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class Ex1 {
    @Test
    public void test() throws InterruptedException {
        WebDriver driver=new ChromeDriver();
        driver.get("https://www.walmart.com/account/signup");
        // Maximize the browser
        driver.manage().window().maximize();
        Thread.sleep(1000);

        //Email Address Text Box
        WebElement email_byName=driver.findElement(By.name("Email Address"));
        WebElement email_byClass=driver.findElement(By.className("w_Fa")).findElement(By.name("Email Address"));
        WebElement email_byXpath=driver.findElement(By.xpath("//input"));


        WebElement continueButton=driver.findElement(By.xpath("//button[@role=\"button\"]"));
        continueButton.click();

        //First Name Text Box
        WebElement firstName_byId=driver.findElement(By.id("\"ld_ui_textfield_411766\""));
        WebElement firstName_byName=driver.findElement(By.name("firstName"));
        WebElement firstName_byClass=driver.findElement(By.className("w_Fa")).findElement(By.name("firstName"));
        WebElement firstName_byXpath=driver.findElement(By.xpath("//input[@id=\"ld_ui_textfield_411766\"]"));


        //Last Name Text Box
        WebElement lastName_byId=driver.findElement(By.id("ld_ui_textfield_411767"));
        WebElement lastName_byName=driver.findElement(By.name("lastName"));
        WebElement lastName_byClass=driver.findElement(By.className("w_Fa")).findElement(By.name("lastName"));
        WebElement lastName_byXpath=driver.findElement(By.xpath("//input[@id=\"ld_ui_textfield_411767\"]"));


        //Last Name Text Box
        WebElement password_byId=driver.findElement(By.id("ld_ui_textfield_411769"));
        WebElement password_byName=driver.findElement(By.name("newPassword"));
        WebElement password_byClass=driver.findElement(By.className("w_Fa")).findElement(By.name("newPassword"));
        WebElement password_byXpath=driver.findElement(By.xpath("//input[@id=\"ld_ui_textfield_411769\"]"));


        //Keep me signed in check box
        WebElement keepSignIn_byId=driver.findElement(By.id("ld_checkbox_59424"));
        WebElement keepSignIn_byClass=driver.findElement(By.className("w_Q")).findElement(By.id("ld_checkbox_59424"));
        WebElement keepSignIn_byXpath_=driver.findElement(By.xpath("//input[@id=\"ld_checkbox_59424\"]"));


        //Sign in Button
        WebElement createAccButton_byId=driver.findElement(By.name("Create Account"));
        WebElement createAccButton_byClass=driver.findElement(By.className("w_B9 w_CB w_CG w-100 mt4"));
        WebElement createAccButton_byXpath=driver.findElement(By.xpath("//button[@class=\"w_B9 w_CB w_CG w-100 mt4\"]"));

        driver.close();

    }
}
