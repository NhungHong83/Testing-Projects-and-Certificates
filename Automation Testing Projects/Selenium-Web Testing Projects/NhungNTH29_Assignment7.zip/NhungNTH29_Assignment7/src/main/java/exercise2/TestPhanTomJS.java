package exercise2;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import ru.yandex.qatools.ashot.AShot;
import ru.yandex.qatools.ashot.Screenshot;
import ru.yandex.qatools.ashot.shooting.ShootingStrategies;

import javax.imageio.ImageIO;
import java.io.File;
import java.io.IOException;

import static java.sql.DriverManager.getDriver;

public class TestPhanTomJS {
    @Test
    public void testGooglePageTitleInChrome() throws InterruptedException, IOException {
        DesiredCapabilities caps=new DesiredCapabilities();
        caps.setPlatform(Platform.WINDOWS);
        caps.setBrowserName("chrome");
        caps.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY
                , "E:\\Learn Automation Test\\AUT_Web\\phantomjs-2.1.1-windows\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe");
        RemoteWebDriver driver=new PhantomJSDriver(caps);
        driver.navigate().to("http://www.google.com");

        //Check
        Screenshot s=new AShot().shootingStrategy(ShootingStrategies.viewportPasting(1000)).takeScreenshot(driver);
        ImageIO.write(s.getImage(),"PNG",new File("E:\\Learn Automation Test\\AUT_Web\\Coding class\\image\\phantomDemo1.png"));

        String strPageTitle = driver.getTitle();
        System.out.println("Title: "+strPageTitle);
        Assert.assertTrue(strPageTitle.equalsIgnoreCase("Google"), "Page title doesn't match");
    }


}

