package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.LazyAutowired;
import com.example.springdemotest.core.annotation.Page;
import com.example.springdemotest.service.ExcelUtils;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.beans.factory.annotation.Value;

import java.io.IOException;

@Page
public class LoginPage extends BasePage {

    @Value("${application.url}")
    private String url;

    @FindBy(name = "identity")
    private WebElement userName;

    @FindBy(name = "password")
    private WebElement password;

    @FindBy(xpath = "//button[contains(text(),'Login')]")
    private WebElement loginBtn;

    @FindBy(xpath = "//label[text()='Remember me']")
    private WebElement rememberMe;

    public void goTo() throws IOException {
        driver.get(url);
    }

    public boolean verifyLoginPage(){
        return userName.isDisplayed()&& password.isDisplayed()&&loginBtn.isDisplayed()&& rememberMe.isDisplayed();
    }

    public void login(String usn, String pwd){
        userName.clear();
        userName.sendKeys(usn);
        password.clear();
        password.sendKeys(pwd);
    }

    public void clickLogin(){
        loginBtn.click();
    }


}
