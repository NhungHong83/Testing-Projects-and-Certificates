package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

@Page
public class ProductDetailPage extends BasePage {

    @FindBy(xpath = "(//label[text()='Product Type']/..)[1]")
    private WebElement productType;

    @FindBy(xpath = "(//label[text()='Product Name']/..)[1]")
    private WebElement productName;

    @FindBy(xpath = "(//label[text()='Product Code']/..)[1]")
    private WebElement productCode;

    @FindBy(xpath = "(//label[text()='Slug']/..)[1]")
    private WebElement slug;

    @FindBy(xpath = "(//label[text()='Barcode Symbology']/..)[1]")
    private WebElement barcodeSymbology;

    @FindBy(id = "s2id_type")
    private WebElement selectPrdType;

    @FindBy(id = "s2id_barcode_symbology")
    private WebElement selectBarcode;

    @FindBy(xpath = "(//input[@class='select2-input'])[12]")
    private WebElement searchBarcode;

    @FindBy(id = "s2id_tax_method")
    private WebElement selectTaxMethod;

    @FindBy(name = "edit_product")
    private WebElement editSubmit;

    @FindBy(xpath = "//p[contains(text(),\"Product price doesn't match with combo items' price\")]")
    private WebElement message;

    @FindBy(id = "loading")
    private WebElement loading;

    public boolean verifyDetailProductDisplay(){
        return wait.until(ExpectedConditions.visibilityOf(productType)).isDisplayed()&
        productName.isDisplayed()&
        productCode.isDisplayed()&
        slug.isDisplayed()&
        barcodeSymbology.isDisplayed();
    }

    public void editProduct(String prdType,String barcode,String taxMethod){
        //select product type
        wait.until(ExpectedConditions.visibilityOf(selectPrdType)).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='"+prdType+"']"))).click();
        //select barcode symbology
        barcodeSymbology.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='"+barcode+"']"))).click();
        //select tax method
        selectTaxMethod.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='"+taxMethod+"']"))).click();

    }

    public void editSubmit(){
        wait.until(ExpectedConditions.visibilityOf(editSubmit)).click();
    }

    public boolean verifyEditProduct(String expectMsg){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        WebElement msg = wait.until(ExpectedConditions.visibilityOf(message));
        return msg.getText().equals(expectMsg);
    }
}
