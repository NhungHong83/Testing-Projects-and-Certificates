package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

@Page
public class PrintBarcodePage extends BasePage {

    @FindBy(id = "add_item")
    private WebElement addProduct;

    @FindBy(xpath = "(//label[text()='Style']/..)[1]")
    private WebElement style;

    @FindBy(id = "s2id_style")
    private WebElement styleList;

    @FindBy(id = "site_name")
    private WebElement siteName;

    @FindBy(id = "product_name")
    private WebElement productName;

    @FindBy(id = "price")
    private WebElement price;

    @FindBy(xpath = "(//ins[@class='iCheck-helper'])[4]")
    private WebElement currencies;

    @FindBy(xpath = "(//ins[@class='iCheck-helper'])[5]")
    private WebElement unit;

    @FindBy(xpath = "(//ins[@class='iCheck-helper'])[6]")
    private WebElement category;

    @FindBy(xpath = "(//ins[@class='iCheck-helper'])[7]")
    private WebElement variants;

    @FindBy(xpath = "(//ins[@class='iCheck-helper'])[8]")
    private WebElement productImage;

    @FindBy(id = "check_promo")
    private WebElement checkPromo;

    @FindBy(xpath = "//input[@value='Update']")
    private WebElement updateBtn;

    //product barcode
    @FindBy(className = "product_image")
    private WebElement prdImage;

    @FindBy(className = "barcode_site")
    private WebElement barcodeSite;

    @FindBy(className = "barcode_name")
    private WebElement barcodeName;

    @FindBy(className = "barcode_price")
    private WebElement barcodePrice;

    @FindBy(className = "barcode_unit")
    private WebElement barcodeUnit;

    @FindBy(className = "barcode_category")
    private WebElement barcodeCategory;

    @FindBy(className = "barcode_image")
    private WebElement barcodeImage;

    @FindBy(id = "loading")
    private WebElement loading;

    public boolean verifyBarcodePage(){
        return wait.until(ExpectedConditions.visibilityOf(addProduct)).isDisplayed()&
                style.isDisplayed()&
                siteName.isDisplayed()&
                productName.isDisplayed()&
                price.isDisplayed()&
                currencies.isDisplayed()&
                unit.isDisplayed()&
                category.isDisplayed()&
                variants.isDisplayed()&
                productImage.isDisplayed()&
                checkPromo.isDisplayed();
    }

    public void addProduct(String prdName,String styleInput){
        wait.until(ExpectedConditions.visibilityOf(addProduct)).sendKeys(prdName);
        wait.until(ExpectedConditions.invisibilityOf(loading));
        styleList.click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[text()='"+styleInput+"']"))).click();
        currencies.click();
        unit.click();
        category.click();
        variants.click();
        productImage.click();

    }

    public void updateClick(){
        updateBtn.click();
    }

    public boolean verifyNewBarcodeProduct(String bcSite, String bcName,String bcPrice,String bcUnit,String bcCategory){
        return wait.until(ExpectedConditions.visibilityOf(prdImage)).isDisplayed()&
        barcodeSite.getText().equals(bcSite)&
        barcodeName.getText().equals(bcName)&
        barcodePrice.getText().equals(bcPrice)&
        barcodeUnit.getText().equals(bcUnit)&
        barcodeCategory.getText().equals(bcCategory)&
        barcodeImage.isDisplayed();
    }

}
