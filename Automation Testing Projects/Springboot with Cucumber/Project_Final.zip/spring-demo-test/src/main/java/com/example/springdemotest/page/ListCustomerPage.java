package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
@Page
public class ListCustomerPage extends BasePage {
    //Column of customers table
    @FindBy(xpath = "//th[text()=\"Company\"]")
    private WebElement company;

    @FindBy(xpath = "//th[text()=\"Name\"]")
    private WebElement name;

    @FindBy(xpath = "//th[text()=\"Email Address\"]")
    private WebElement emailAddress;

    @FindBy(xpath = "//th[text()=\"Phone\"]")
    private WebElement phone;

    @FindBy(xpath = "//th[text()=\"Price Group\"]")
    private WebElement priceGroup;

    @FindBy(xpath = "//th[text()=\"Customer Group\"]")
    private WebElement customerGroup;

    @FindBy(xpath = "//th[text()=\"VAT Number\"]")
    private WebElement VATNumber;

    @FindBy(xpath = "//th[text()=\"GST Number\"]")
    private WebElement GSTNumber;

    @FindBy(xpath = "//th[text()=\"Deposit\"]")
    private WebElement deposit;

    @FindBy(xpath = "//th[text()=\"Award Points\"]")
    private WebElement awardPoints;

    public boolean verifyListCustomerPage(){
        return wait.until(ExpectedConditions.visibilityOf(company)).isDisplayed()&
                name.isDisplayed()&
                emailAddress.isDisplayed()&
                phone.isDisplayed()&
                priceGroup.isDisplayed()&
                customerGroup.isDisplayed()&
                VATNumber.isDisplayed()&
                GSTNumber.isDisplayed()&
                deposit.isDisplayed()&
                awardPoints.isDisplayed();
    }

}
