package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.List;

@Page
public class AddSalePage extends BasePage {

    @FindBy(id = "s2id_slcustomer")
    private WebElement customerList;

    @FindBy(id = "s2id_autogen12_search")
    private WebElement customerInput;

    @FindBy(xpath = "//span[text()='Walk-in Customer']")
    private WebElement customerSelected;

    @FindBy(id = "add_item")
    private WebElement productNameInput;

    @FindBy(xpath = "//tbody[@class ='ui-sortable']/tr")
    private List<WebElement> rows;

    @FindBy(id = "add_sale")
    private WebElement addSaleBtn;

    @FindBy(xpath = "//div[@class='alert alert-success']")
    private WebElement addSuccessMsg;

    @FindBy(id = "loading")
    private WebElement loading;

    public void addSale(String customerName,String productName){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(customerList)).click();
        wait.until(ExpectedConditions.visibilityOf(customerInput)).sendKeys(customerName);
        wait.until(ExpectedConditions.visibilityOf(customerSelected)).click();
        productNameInput.sendKeys(productName);
//        if (rows.size() > 0){
//            wait.until(ExpectedConditions.visibilityOf(addSaleBtn)).click();
//            WebElement msg = wait.until(ExpectedConditions.visibilityOf(addSuccessMsg));
//            Assert.assertTrue(msg.getText().contains(message));
//        }
    }

    public void submitClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.elementToBeClickable(addSaleBtn)).click();
    }

    public boolean verifyMessage(String successMsg){
        return wait.until(ExpectedConditions.visibilityOf(addSuccessMsg)).getText().contains(successMsg);
    }

}
