package com.example.springdemotest.service;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Value;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

public class ExcelUtils {
    @Value("${excel.filepath}")
    public static String excelpath;

    public static List<String> getData(String sheetName, int startCol, int totalCol ) throws IOException {
        List<String> data = new ArrayList<>();

        FileInputStream inputStream = new FileInputStream(new File("E:\\Learn Automation Test\\Learning course - Spring Boot\\Code\\Project_Final\\spring_testcase.xlsx"));
//        FileInputStream inputStream = new FileInputStream(new File(excelpath+"\\spring_testcase.xlsx"));
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
        XSSFSheet sheet = workbook.getSheet(sheetName);

        int startRow = 1;
        int totalRow = sheet.getLastRowNum();
        int number = 0;
        for(int i=startRow; i<=totalRow; i++){
            for(int j=startCol; j<totalCol; j++){
                XSSFCell cell = sheet.getRow(i).getCell(j);
                data.add(cell.getStringCellValue());
            }
        }
        return data;
    }

}
