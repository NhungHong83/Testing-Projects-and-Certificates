package com.example.springdemotest.base;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.testng.AbstractTestNGSpringContextTests;

@SpringBootTest
public class SpringBaseTest extends AbstractTestNGSpringContextTests {
}
