package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

@Page
public class AddCustomerForm extends BasePage {

    @FindBy(id = "company")
    private WebElement companyInput;

    @FindBy(id = "name")
    private WebElement nameInput;

    @FindBy(id = "email_address")
    private WebElement emailInput;

    @FindBy(id = "phone")
    private WebElement phoneInput;

    @FindBy(id = "address")
    private WebElement addressInput;

    @FindBy(id = "city")
    private WebElement cityInput;

    @FindBy(xpath = "//input[@name='add_customer']")
    private WebElement submit;

    @FindBy(xpath = "//div[@class='alert alert-success']")
    private WebElement addSuccessMsg;

    public void inputCustomerFields(String company, String name, String email, String phone, String address, String city){
        wait.until(ExpectedConditions.visibilityOf(companyInput)).sendKeys(company);
        nameInput.sendKeys(name);
        emailInput.sendKeys(email);
        phoneInput.sendKeys(phone);
        addressInput.sendKeys(address);
        cityInput.sendKeys(city);
    }

    public void addCustomerClick(){
        submit.click();
    }

    public boolean verifySuccess(String msg){
        wait.until(ExpectedConditions.visibilityOf(addSuccessMsg)).isDisplayed();
        return addSuccessMsg.getText().contains(msg);
    }
}
