package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.List;

@Page
public class ProductsListPage extends BasePage {

    @FindBy(id = "loading")
    private WebElement loading;

    //search input
    @FindBy(xpath = "//input[@aria-controls='PRData']")
    private WebElement searchInput;

    //product found success condition
    @FindBy(xpath = "//div[text()='Showing 1 to 1 of 1 entries (filtered from 24 total entries)']")
    private WebElement successCondition;

    @FindBy(xpath = "//tbody[@role='alert']/descendant::tr")
    private List<WebElement> TRs;

    //Action drop down after product found
    @FindBy(xpath = "//button[text()='Actions ']")
    private WebElement actionsList;

    @FindBy(xpath = "//a[contains(text(),'Edit Product')]")
    private WebElement editProduct;

    //Table columns
    @FindBy(xpath = "(//th[text()='Image'])[1]")
    private WebElement imageCol;

    @FindBy(xpath = "(//th[text()='Code'])[1]")
    private WebElement codeCol;

    @FindBy(xpath = "(//th[text()='Name'])[1]")
    private WebElement nameCol;

    @FindBy(xpath = "(//th[text()='Brand'])[1]")
    private WebElement brandCol;

    @FindBy(xpath = "(//th[text()='Category'])[1]")
    private WebElement categoryCol;

    @FindBy(xpath = "(//th[text()='Cost'])[1]")
    private WebElement costCol;

    @FindBy(xpath = "(//th[text()='Price'])[1]")
    private WebElement priceCol;

    @FindBy(xpath = "(//th[text()='Quantity'])[1]")
    private WebElement quantityCol;

    @FindBy(xpath = "(//th[text()='Unit'])[1]")
    private WebElement unitCol;

    @FindBy(xpath = "(//th[text()='Alert Quantity'])[1]")
    private WebElement alertQuantityCol;

    @FindBy(xpath = "(//th[text()='Actions'])[1]")
    private WebElement actionsCol;

    //Lemon product
    @FindBy(xpath = "//td[text()='Lemon']")
    private WebElement lemon;

    @FindBy(id = "pr-image")
    private WebElement lemonImage;

    @FindBy(xpath = "//td[text()='Barcode & QRcode']/..")
    private WebElement lemonQRCode;

    @FindBy(xpath = "(//td[text()='Type']/following::td)[1]")
    private WebElement lemonType;

    @FindBy(xpath = "(//td[text()='Name']/following::td)[1]")
    private WebElement lemonName;

    @FindBy(xpath = "(//td[text()='Code']/following::td)[1]")
    private WebElement lemonCode;

    @FindBy(xpath = "(//td[text()='Category']/following::td)[1]")
    private WebElement lemonCategory;

    @FindBy(xpath = "(//td[text()='Unit']/following::td)[1]")
    private WebElement lemonUnit;

    @FindBy(xpath = "(//td[text()='Cost']/following::td)[1]")
    private WebElement lemonCost;

    @FindBy(xpath = "(//td[text()='Price']/following::td)[1]")
    private WebElement lemonPrice;

    @FindBy(xpath = "(//td[text()='Tax Rate']/following::td)[1]")
    private WebElement lemonTaxRate;

    @FindBy(xpath = "(//td[text()='Tax Method']/following::td)[1]")
    private WebElement lemonTaxMethod;

    @FindBy(xpath = "(//td[text()='Alert Quantity']/following::td)[1]")
    private WebElement lemonAlertQuantity;

    @FindBy(xpath = "//div[text()='Product Details']/..")
    private WebElement lemonDetail;

    @FindBy(xpath = "//td[text()='Mouse']")
    private WebElement productLink;

    @FindBy(xpath = "//a[@data-original-title='Edit Product']")
    private WebElement editBtn;

    @FindBy(id = "PRData_processing")
    private WebElement processing;

    public boolean verifyProductListTable(){
        return codeCol.isDisplayed() &
                nameCol.isDisplayed()&
                brandCol.isDisplayed()&
                categoryCol.isDisplayed()&
                costCol.isDisplayed()&
                priceCol.isDisplayed()&
                quantityCol.isDisplayed()&
                unitCol.isDisplayed()&
                alertQuantityCol.isDisplayed()&
                actionsCol.isDisplayed();
    }

    public void lemonClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(lemon)).click();
    }

    public boolean verifyProductDetail(String type, String name, String code, String category, String unit, String cost, String price, String taxRate, String taxMethod, String alert){
        return wait.until(ExpectedConditions.visibilityOf(lemonImage)).isDisplayed()&
                lemonQRCode.isDisplayed()&
                lemonType.getText().equals(type)&
                lemonName.getText().equals(name)&
                lemonCode.getText().equals(code)&
                lemonCategory.getText().equals(category)&
                lemonUnit.getText().equals(unit)&
                lemonCost.getText().equals(cost)&
                lemonPrice.getText().equals(price)&
                lemonTaxRate.getText().equals(taxRate)&
                lemonTaxMethod.getText().equals(taxMethod)&
                lemonAlertQuantity.getText().equals(alert)&
                lemonDetail.isDisplayed();
    }

    public void searchProduct(String prdName){
        wait.until(ExpectedConditions.visibilityOf(searchInput)).sendKeys(prdName);
        wait.until(ExpectedConditions.invisibilityOf(processing));
        if(TRs.size()==1){
            wait.until(ExpectedConditions.invisibilityOf(loading));
            wait.until(ExpectedConditions.visibilityOf(productLink)).click();
            wait.until(ExpectedConditions.invisibilityOf(loading));
            wait.until(ExpectedConditions.visibilityOf(editBtn)).click();
        }
    }

}
