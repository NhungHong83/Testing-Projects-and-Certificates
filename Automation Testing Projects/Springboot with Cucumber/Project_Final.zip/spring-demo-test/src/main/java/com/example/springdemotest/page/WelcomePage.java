package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

@Page
public class WelcomePage extends BasePage {

    @FindBy(xpath = "//div[@id = 'loading']")
    private WebElement loading;

    //Main dashboard
    @FindBy(xpath = "//p[text()='You are successfully logged in.']")
    private WebElement message;

    @FindBy(xpath = "//h2[text()='Overview Chart']/../..")
    private WebElement overviewChart;

    @FindBy(xpath = "//h2[text()='Quick Links']/../..")
    private WebElement quickLinks;

    @FindBy(xpath = "//h2[text()=' Latest Five']/../..")
    private WebElement latestFive;

    @FindBy(xpath = "(//h2[contains(text(),'Best Sellers')]/../..)[1]")
    private WebElement bestSeller1;

    @FindBy(xpath = "(//h2[contains(text(),'Best Sellers')]/../..)[2]")
    private WebElement bestSeller2;

    //Left Menu Bar
    @FindBy(xpath = "//span[text()=' Products ']")
    private WebElement productsDropDown;

    @FindBy(xpath = "//span[text()=' List Products']")
    private WebElement listProducts;

    @FindBy(xpath = "//span[text()=' Print Barcode/Label']")
    private WebElement printBarcode;

    @FindBy(xpath = "//span[text()=' Sales ']")
    private WebElement salesDropDown;

    @FindBy(xpath = "//span[text()=' Add Sale']")
    private WebElement addSales;

    @FindBy(xpath = "//span[text()=' Purchases ']")
    private WebElement purchasesDropDown;

    @FindBy(xpath = "//span[text()=' List Purchases']")
    private WebElement listPurchase;

    @FindBy(xpath = "//span[text()=' Add Purchase']")
    private WebElement addPurchase;

    @FindBy(xpath = "//span[text()=' People ']")
    private WebElement peopleDropDown;

    @FindBy(xpath = "//span[text()=' Add Customer']")
    private WebElement addCustomer;

    @FindBy(xpath = "//span[text()=' List Customers']")
    private WebElement listCustomer;

    @FindBy(xpath = "//span[text()=' Add Supplier']")
    private WebElement addSupplier;

    @FindBy(xpath = "//span[text()=\" Overview Chart\"]")
    private WebElement overviewChartLeftMenu;

    @FindBy(xpath = "//span[text()=' Reports ']")
    private WebElement reportsDropDown;

    @FindBy(xpath = "//span[text()=\" Calendar\"]")
    private WebElement calendar;


    public boolean verifyWelcomePage(String msg){
        Assert.assertEquals(this.message.getText(),msg);
        return overviewChart.isDisplayed() &
        quickLinks.isDisplayed() &
        latestFive.isDisplayed() &
        bestSeller1.isDisplayed() &
        bestSeller2.isDisplayed();
    }

    public void productsClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.elementToBeClickable(productsDropDown)).click();
    }

    public void listProductsClick(){
        wait.until(ExpectedConditions.elementToBeClickable(listProducts)).click();
    }

    public void barcodeClick(){
        wait.until(ExpectedConditions.elementToBeClickable(printBarcode)).click();
    }

    public void saleClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(salesDropDown)).click();
        wait.until(ExpectedConditions.visibilityOf(addSales)).click();
    }


    public void listPurchaseClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(purchasesDropDown)).click();
        wait.until(ExpectedConditions.visibilityOf(listPurchase)).click();
    }

    public void addPurchaseClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(purchasesDropDown)).click();
        wait.until(ExpectedConditions.visibilityOf(addPurchase)).click();
    }

    public void addCustomerClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(peopleDropDown)).click();
        wait.until(ExpectedConditions.visibilityOf(addCustomer)).click();
    }
    public void listCustomerClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(peopleDropDown)).click();
        wait.until(ExpectedConditions.visibilityOf(listCustomer)).click();
    }

    public void addSupplierClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(peopleDropDown)).click();
        wait.until(ExpectedConditions.visibilityOf(addSupplier)).click();
    }
    public void overViewChartClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(reportsDropDown)).click();
        wait.until(ExpectedConditions.visibilityOf(overviewChartLeftMenu)).click();
    }

    public void calendarClick(){
        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(calendar)).click();
    }

}
