package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

@Page
public class ListPurchasesPage extends BasePage {

    @FindBy(xpath = "//tbody[@role='alert']/tr/td[@class=' sorting_1']")
    private List<WebElement> dates;

    @FindBy(xpath = "//tbody[@role='alert']/tr/td[@class=' sorting_2']")
    private List<WebElement> referenceNo;

    @FindBy(xpath = "//tbody[@role='alert']/tr")
    private List<WebElement> rows;

    @FindBy(xpath = "//div[contains(text(),'entries')]")
    private WebElement info;

    public boolean dateFormValidate(String format,String value) throws ParseException {

        boolean valid;
        try{
            SimpleDateFormat dateFormat = new SimpleDateFormat(format);
            dateFormat.setLenient(false);
            dateFormat.parse(value);
            valid = true;
        }catch(Exception e){
            valid = false;
        }
        return valid;
    }

    public void validatePurchaseTable(String format,String number) throws ParseException {

        //Date: format datetime by dd/mm/yyy hh:mm:ss
        for(WebElement date : dates){
            System.out.println(date.getText());
            Assert.assertTrue(dateFormValidate(format,date.getText()));
        }

        List<Integer> refList = new ArrayList<>();
        for(WebElement refNo : referenceNo){
            int index = Integer.parseInt(refNo.getText().substring(10));
            refList.add(index);
        }

        //Reference No order by DESC
        for(int i=0; i<refList.size();i++){
            try{
                if(refList.get(i) > refList.get(i+1))
                    continue;
                else{
                    System.out.println("Wrong order");
                    break;
                }
            }catch (Exception e){
                System.out.println("End of reference No");
            }
        }

        //Displayed 9 Purchases
        wait.until(ExpectedConditions.visibilityOf(info));
        Assert.assertTrue(info.getText().contains(number));
    }

}
