package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.testng.Assert;

import java.util.List;

@Page
public class AddPurchasePage extends BasePage {

    @FindBy(id = "s2id_posupplier")
    private WebElement poSupplier;

    @FindBy(id = "s2id_autogen8_search")
    private WebElement searchSupplier;

    @FindBy(xpath = "//span[text()='Amazing Toys']")
    private WebElement supplier;

    @FindBy(id = "add_item")
    private WebElement addItem;

    @FindBy(xpath = "//div[@class='alert alert-success']")
    private WebElement addSuccessMsg;

    @FindBy(name = "add_pruchase")
    private WebElement addButton;

    @FindBy(xpath = "//tbody[@class ='ui-sortable']/tr")
    private List<WebElement> rows;

    @FindBy(id = "loading")
    private WebElement loading;

    public void addPurchase(String supplierName,String item){

        wait.until(ExpectedConditions.invisibilityOf(loading));
        wait.until(ExpectedConditions.visibilityOf(poSupplier)).click();
        wait.until(ExpectedConditions.visibilityOf(searchSupplier)).sendKeys(supplierName);
        wait.until(ExpectedConditions.visibilityOf(supplier)).click();
        addItem.sendKeys(item);
    }

    public void clickSubmit(){
        wait.until(ExpectedConditions.visibilityOf(addButton)).click();
    }

    public boolean verifyPurchaseSuccessfully(String successMsg){
        WebElement msg = wait.until(ExpectedConditions.visibilityOf(addSuccessMsg));
        return msg.getText().contains(successMsg);
    }



}
