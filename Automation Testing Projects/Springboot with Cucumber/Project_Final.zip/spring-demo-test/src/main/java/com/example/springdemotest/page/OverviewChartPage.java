package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
@Page
public class OverviewChartPage extends BasePage {
    @FindBy(xpath = "//p[text()=\"Warehouse Stock Chart\"]")
    private WebElement wareStockChart;

    @FindBy(xpath = "//p[text()=\"Best Sellers\"]")
    private WebElement bestSellers;

    @FindBy(xpath = "//p[text()=\"Product Quantity Alerts\"]")
    private WebElement productQuantityAlert;

    @FindBy(xpath = "//p[text()=\"Product Expiry Alerts\"]")
    private WebElement productExpiryAlert;

    @FindBy(xpath = "//p[text()=\"Products Report\"]")
    private WebElement productReport;

    @FindBy(xpath = "//p[text()=\"Daily Sales\"]")
    private WebElement dailySales;

    @FindBy(xpath = "//p[text()=\"Monthly Sales\"]")
    private WebElement monthlySales;

    @FindBy(xpath = "//p[text()=\"Sales Report\"]")
    private WebElement salesReport;

    @FindBy(xpath = "//p[text()=\"Payments Report\"]")
    private WebElement paymentReport;

    @FindBy(xpath = "//p[text()=\"Profit and/or Loss\"]")
    private WebElement profitLoss;

    @FindBy(xpath = "//p[text()=\"Purchases Report\"]")
    private WebElement purchasesReport;

    @FindBy(xpath = "//p[text()=\"Customers Report\"]")
    private WebElement customerReport;

    @FindBy(xpath = "//p[text()=\"Suppliers Report\"]")
    private WebElement supplierReport;

    @FindBy(xpath = "//p[text()=\"Staff Report\"]")
    private WebElement staffReport;

    public boolean verifyQuickLinkTable(){
        return wait.until(ExpectedConditions.visibilityOf(wareStockChart)).isDisplayed()&
                bestSellers.isDisplayed()&
                productQuantityAlert.isDisplayed()&
                productExpiryAlert.isDisplayed()&
                productReport.isDisplayed()&
                dailySales.isDisplayed()&
                monthlySales.isDisplayed()&
                salesReport.isDisplayed()&
                paymentReport.isDisplayed()&
                profitLoss.isDisplayed()&
                purchasesReport.isDisplayed()&
                customerReport.isDisplayed()&
                supplierReport.isDisplayed()&
                staffReport.isDisplayed();
    }
}
