package com.example.springdemotest.core.config;

import com.example.springdemotest.core.annotation.LazyConfiguration;
import com.example.springdemotest.core.annotation.ThreadScopeBean;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Primary;

@LazyConfiguration
public class WebDriverConfig {

    @ThreadScopeBean
    @Primary
    public WebDriver chromeDriver(){
        return new ChromeDriver();
    }


    @ThreadScopeBean
    @ConditionalOnProperty(name = "browser",havingValue = "firefox")
    public WebDriver firefoxDriver(){
        return new FirefoxDriver();
    }

}
