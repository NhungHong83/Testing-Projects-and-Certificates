package com.example.springdemotest.bdd.step_defs;

import com.example.springdemotest.core.annotation.LazyAutowired;
import com.example.springdemotest.page.*;
import com.example.springdemotest.service.ExcelUtils;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.testng.Assert;

import java.io.IOException;
import java.text.ParseException;
import java.util.List;

@SpringBootTest
public class StepDefinition {

    @LazyAutowired
    private LoginPage loginPage;

    @LazyAutowired
    private WelcomePage welcomePage;

    @LazyAutowired
    private ProductsListPage productsListPage;

    @LazyAutowired
    private ProductDetailPage productDetailPage;

    @LazyAutowired
    private PrintBarcodePage printBarcodePage;

    @LazyAutowired
    private AddSalePage addSalePage;

    @LazyAutowired
    private ListPurchasesPage listPurchasesPage;

    @LazyAutowired
    private AddPurchasePage addPurchasePage;

    @LazyAutowired
    private AddCustomerForm addCustomerForm;

    @LazyAutowired
    private ListCustomerPage listCustomerPage;

    @LazyAutowired
    private AddSupplierForm addSupplierForm;

    @LazyAutowired
    private OverviewChartPage overviewChartPage;

    @LazyAutowired
    private CalendarPage calendarPage;

    @Given("Navigate to login page successfully")
    public void launchToLoginPage() throws IOException {
        loginPage.goTo();
    }

    @Then("The login page should be displayed: username combobox,password text,login button, remember me")
    public void verifyLoginPage() {
        loginPage.verifyLoginPage();
    }

    @When("I input user {string} and {string}")
    public void iInputUserAnd(String userName, String password) throws IOException {
        List<String> data = ExcelUtils.getData("TC02",0,4);
        userName = data.get(1);
        password = data.get(2);
        loginPage.login(userName,password);
    }

    @And("I click the Login button")
    public void iClickTheLoginButton() {
        loginPage.clickLogin();
    }

    @Then("The Dashboard page displayed Message:{string}, Overview Chart, Quick Links, Latest Five, Best Sellers")
    public void verifyLoginSuccessfully(String msg) throws IOException {
        List<String> data = ExcelUtils.getData("TC02",0,4);
        msg = data.get(3);
        Assert.assertTrue(welcomePage.verifyWelcomePage(msg));
    }

    @And("I click to the Products")
    public void iClickToTheProducts() {
        welcomePage.productsClick();
    }

    @And("I click to the List Products")
    public void iClickToTheListProducts() {
        welcomePage.listProductsClick();
    }


    @Then("Product table displayed column: Image, Code, Name, Brand, Category, Cost, Price, Quantity, Unit, Alert Quantity, Actions")
    public void verifyListProducts() {
        Assert.assertTrue(productsListPage.verifyProductListTable());
    }

    @And("I click to the Lemon Product")
    public void iClickToTheLemonProduct() {
        productsListPage.lemonClick();
    }

    @Then("The product detail page displayed:  Product image,Barcode & Qrcode,Type: {string},Name: {string},Code: {string},Category: {string},Unit: {string},Cost: {string},Price: {string},Tax Rate: {string},Tax Method: {string},Alert: {string},Product Details")
    public void verifyProductDetail(String type, String name, String code, String category, String unit, String cost, String price, String taxRate, String taxMethod, String alert) throws IOException {
        List<String> data = ExcelUtils.getData("TC04",0,13);
        type = data.get(3);
        name = data.get(4);
        code = data.get(5);
        category = data.get(6);
        unit = data.get(7);
        cost = data.get(8);
        price = data.get(9);
        taxRate = data.get(10);
        taxMethod = data.get(11);
        alert = data.get(12);
        Assert.assertTrue(productsListPage.verifyProductDetail(type, name, code, category, unit, cost, price, taxRate, taxMethod, alert));
    }

    @And("I select the {string} product and click to Edit Product")
    public void selectProductAndClickEdit(String productName) throws IOException {
        List<String> data = ExcelUtils.getData("TC05",0,8);
        productName = data.get(3);
        productsListPage.searchProduct(productName);
    }

    @Then("Product detail page displayed:Product Type, Product Name, Product Code, Slug, Barcode Symbology")
    public void verifyEditProduct() {
        Assert.assertTrue(productDetailPage.verifyDetailProductDisplay());
    }

    @When("I change some field: Product Type:{string}, Barcode Symbology: {string}, Tax Method: {string}")
    public void editProduct(String type, String barcode, String method) throws IOException {
        List<String> data = ExcelUtils.getData("TC05",0,8);
        type = data.get(4);
        barcode = data.get(5);
        method = data.get(6);
        productDetailPage.editProduct(type, barcode, method);
    }

    @And("I click to Edit Product")
    public void iClickToEditProduct() {
        productDetailPage.editSubmit();
    }

    @Then("The page displayed message: {string}")
    public void verifyDisplayedMessage(String message) throws IOException {
        List<String> data = ExcelUtils.getData("TC05",0,8);
        message = data.get(7);
        Assert.assertTrue(productDetailPage.verifyEditProduct(message));
    }


    @And("I click to the Print Barcode Label")
    public void iClickToThePrintBarcodeLabel() {
        welcomePage.barcodeClick();
    }

    @Then("The Print Barcode Label page displayed:Add Product, Style, Print \\(site name, product name, price, Currencies, Unit, Category, Variants, Product Image, Check promotional price)")
    public void verifyPrintBarcodePage() {
       printBarcodePage.verifyBarcodePage();
    }


    @And("I add {string} product, Style: {string}, and select print site name, product name, price, Currencies, Unit, Category, Variants, Product Image, Check promotional price")
    public void addNewProduct(String prdName, String style) throws IOException {
        List<String> data = ExcelUtils.getData("TC07",0,10);
        prdName = data.get(3);
        style = data.get(4);
        printBarcodePage.addProduct(prdName,style);
    }

    @And("I click Update")
    public void iClickUpdate() {
        printBarcodePage.updateClick();
    }

    @Then("The page display bar code with some info: product_image,barcode_site:{string},barcode_name: {string},barcode_price: {string},barcode_unit: {string},barcode_category: {string},barcode_image")
    public void verifyAddedProduct(String bcSite, String bcName, String bcPrice, String bcUnit, String bcCategory) throws IOException {
        List<String> data = ExcelUtils.getData("TC07",0,10);
        bcSite = data.get(5);
        bcName = data.get(6);
        bcPrice = data.get(7);
        bcUnit = data.get(8);
        bcCategory = data.get(9);
        Assert.assertTrue(printBarcodePage.verifyNewBarcodeProduct(bcSite, bcName, bcPrice, bcUnit, bcCategory));
    }

    @And("I click to the Sales, Add Sale")
    public void iClickToTheSalesAddSale() {
        welcomePage.saleClick();
    }

    @And("I input required fields : {string}, {string}")
    public void iInputRequiredFields(String customerName, String productName) throws IOException {
        List<String> data = ExcelUtils.getData("TC08",0,6);
        customerName = data.get(3);
        productName = data.get(4);
        addSalePage.addSale(customerName, productName);
    }

    @And("I click to the Submit")
    public void iClickToTheSubmit() {
        addSalePage.submitClick();
    }

    @Then("Screen displayed message: {string}")
    public void screenDisplayedMessage(String msg) throws IOException {
        List<String> data = ExcelUtils.getData("TC09",0,6);
        msg = data.get(5);
        Assert.assertTrue(addSalePage.verifyMessage(msg));
    }

    @And("I click to the Purchases, List Purchases")
    public void iClickToThePurchasesListPurchases() {
        welcomePage.listPurchaseClick();
    }

    @Then("The Purchases table displayed with column:Date: format datetime by {string},Reference No order by DESC,Displayed {string} Purchases")
    public void verifyListPurchases(String format, String number) throws IOException, ParseException {
        List<String> data = ExcelUtils.getData("TC09",0,5);
        format = data.get(3);
        number = data.get(4);
        int num = Integer.parseInt(number);
        listPurchasesPage.validatePurchaseTable(format,number);
    }

    @And("I click to the Purchases, Add Purchases")
    public void iClickToThePurchasesAddPurchases() {
        welcomePage.addPurchaseClick();
    }

    @And("I input required input fields: {string},{string}")
    public void iInputRequiredInputFields(String supplierName, String item) throws IOException {
        List<String> data = ExcelUtils.getData("TC10",0,6);
        supplierName = data.get(3);
        item = data.get(4);
        addPurchasePage.addPurchase(supplierName,item);
    }

    @And("I click to the submit")
    public void clickSubmit() {
        addPurchasePage.clickSubmit();
    }

    @Then("The Screen displayed message: {string}")
    public void theScreenDisplayedMessage(String msg) {
        Assert.assertTrue(addPurchasePage.verifyPurchaseSuccessfully(msg));
    }


    @And("I click to the People, Add Customer")
    public void iClickToThePeopleAddCustomer() {
        welcomePage.addCustomerClick();
    }

    @And("I input required fields : {string}, {string}, {string}, {string},{string},{string}")
    public void iInputRequiredFields(String company, String name, String email, String phone, String address, String city) throws IOException {
        List<String> data = ExcelUtils.getData("TC11",0,10);
        company = data.get(3);
        name = data.get(4);
        email = data.get(5);
        phone = data.get(6);
        address = data.get(7);
        city = data.get(8);
        addCustomerForm.inputCustomerFields(company,name,email,phone,address,city);
    }

    @And("I click Add Customer")
    public void iClickAddCustomer() {
        addCustomerForm.addCustomerClick();
    }

    @Then("Then The Screen displayed message: {string}")
    public void verifyAddCustomer(String msg) throws IOException {
        List<String> data = ExcelUtils.getData("TC11",0,10);
        msg = data.get(9);
        Assert.assertTrue(addCustomerForm.verifySuccess(msg));
    }

    @And("I click to the People, List Customers")
    public void iClickPeopleListCustomers() {
        welcomePage.listCustomerClick();
    }

    @Then("The Customers table displayed with column: Company, Name, Email Address, Phone, Price Group, Customer Group, VAT Number, GST Number, Deposit, Award Points")
    public void verifyCustomerTable() {
        Assert.assertTrue(listCustomerPage.verifyListCustomerPage());
    }

    @And("I click to the People, Add Supplier")
    public void iClickPeopleAddSupplier() {
        welcomePage.addSupplierClick();
    }

    @And("I input required input fields : {string}, {string}, {string}, {string}, {string}, {string},")
    public void iInputRequiredInputFields(String company, String name, String email, String phone, String address, String city) throws IOException {
        List<String> data = ExcelUtils.getData("TC13",0,10);
        company = data.get(3);
        name = data.get(4);
        email = data.get(5);
        phone = data.get(6);
        address = data.get(7);
        city = data.get(8);
        addSupplierForm.inputSupplierFields(company,name,email,phone,address,city);
    }

    @And("I click to the Add Supplier")
    public void iClickAddSupplier() {
        addSupplierForm.addSupplierClick();
    }

    @Then("Supplier Screen displayed message: {string}")
    public void thenAddSupplierScreenDisplayedMessage(String msg) throws IOException {
        List<String> data = ExcelUtils.getData("TC13",0,10);
        msg = data.get(9);
        Assert.assertTrue(addSupplierForm.verifySuccess(msg));
    }

    @And("I click to the Reports, Overview Chart")
    public void iClickReportsOverviewChart() {
        welcomePage.overViewChartClick();
    }

    @Then("Quick Links table displayed with: Warehouse Stock Chart,Best Sellers,Product Quantity Alerts, Product Expiry Alerts, Products Report, Daily Sales, Monthly Sales, Sales Report, Payments Report, Profit and or Loss, Purchases Report, Customers Report,Suppliers Report,Staff Report")
    public void verifyQuickLinkTable() {
        Assert.assertTrue(overviewChartPage.verifyQuickLinkTable());
    }

    @And("I click to the Calendar")
    public void iClickCalendar() {
        welcomePage.calendarClick();
    }

    @And("I click to the {string}")
    public void iClickToThe(String date) throws IOException {
        List<String> data = ExcelUtils.getData("TC15",0,6);
        date = data.get(3);
        calendarPage.clickDate(date);
    }

    @And("I add the {string}")
    public void iAddThe(String title) throws IOException {
        List<String> data = ExcelUtils.getData("TC15",0,6);
        title = data.get(4);
        calendarPage.addTitle(title);
    }

    @And("I click to the Add event")
    public void iClickToTheAddEvent() {
        calendarPage.addEventClick();
    }

    @Then("Calendar Screen displayed message: {string}")
    public void calendarScreenDisplayedMessage(String msg) throws IOException {
        List<String> data = ExcelUtils.getData("TC15",0,6);
        msg = data.get(5);
        Assert.assertTrue(calendarPage.verifySuccess(msg));
    }
}
