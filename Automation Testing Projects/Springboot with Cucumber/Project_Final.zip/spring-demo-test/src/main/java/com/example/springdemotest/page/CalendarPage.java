package com.example.springdemotest.page;

import com.example.springdemotest.base.BasePage;
import com.example.springdemotest.core.annotation.Page;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
@Page
public class CalendarPage extends BasePage {
    @FindBy(xpath = "//input[@name=\"title\"]")
    private WebElement titleInput;

    @FindBy(id = "add-event")
    private WebElement addEventButton;

    @FindBy(xpath = "//div[@class='alert alert-success']")
    private WebElement addSuccessMsg;
    public void clickDate(String date){
//        WebElement e=driver.findElement(By.xpath("//td[@data-date=\""+date+"\"]"));
        WebElement e=wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//td[@data-date=\""+date+"\"]")));
        wait.until(ExpectedConditions.elementToBeClickable(e)).click();
    }
    public void addTitle(String title){
        wait.until(ExpectedConditions.visibilityOf(titleInput)).sendKeys(title);
    }
    public void addEventClick(){
        wait.until(ExpectedConditions.visibilityOf(addEventButton)).click();
    }

    public boolean verifySuccess(String msg){
        wait.until(ExpectedConditions.visibilityOf(addSuccessMsg)).isDisplayed();
        return addSuccessMsg.getText().contains(msg);
    }
}
