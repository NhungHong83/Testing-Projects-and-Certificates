package com.example.springdemotest.bdd.cucumber_hooks;

import com.example.springdemotest.core.annotation.LazyAutowired;
import com.example.springdemotest.service.ScreenShotService;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Scenario;
import org.openqa.selenium.WebDriver;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Lazy;

public class CucumberHooks {

    @LazyAutowired
    private ScreenShotService service;

    @LazyAutowired
    private ApplicationContext ctx;

    @AfterStep
    public void afterStep(Scenario scenario){
        if(scenario.isFailed()){
            scenario.embed(this.service.getScreenShot(),"image/png", scenario.getName());
        }
    }

    @After
    public void afterScenario(){
        this.ctx.getBean(WebDriver.class).quit();
    }

}
