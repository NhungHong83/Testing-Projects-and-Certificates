package com.example.springdemotest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
