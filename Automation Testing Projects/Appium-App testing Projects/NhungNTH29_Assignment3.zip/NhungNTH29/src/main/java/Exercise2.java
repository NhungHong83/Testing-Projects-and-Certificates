import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Exercise2 {
    AndroidDriver androidDriver;
    @Test
    public void test() throws MalformedURLException, InterruptedException {
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","R58M72M45JV");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability("appium:appPackage","vn.tiki.app.tikiandroid");
        desiredCapabilities.setCapability("appium:appActivity","vn.tiki.android.shopping.homeV3.HomeActivity");
        androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        WebDriverWait webDriverWait=new WebDriverWait(androidDriver,Duration.ofSeconds(30));
        //Step 2: Click menu bar
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("vn.tiki.app.tikiandroid.homeV3:id/image"))).click();
        //Step 3: Click Danh Muc San Pham (không có Danh mục sản phẩm)
        //Step 4: Scroll to “Hàng Quốc Tế” in Left menu
        swipeMobileUptoElementLeftMenu(By.xpath("//android.widget.TextView[@text=\"Cross Border - Hàng Quốc Tế\"]"));

        //Step 5: Scroll to panel “Laptop & Máy Vi Tính”
        swipeMobileDownToElement(By.xpath("(//android.widget.TextView[contains(@text,\"Laptop - Máy Vi Tính - Linh kiện\")])[1]"));
        //Step 6: Click to the “Laptop”
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//android.widget.TextView[contains(@text,\"Laptop - Máy Vi Tính - Linh kiện\")])[1]")));
//        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[contains(@text,\"Phụ kiện thời trang\")]"))).click();
        try{
            webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.android.packageinstaller:id/permission_allow_button"))).click();
        }catch (Exception e){
        }
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text=\"Laptop\"]"))).click();
        //Step 6: Click to the first product.
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//android.view.ViewGroup[@resource-id=\"vn.tiki.app.tikiandroid:id/product_badges_container\"])[1]"))).click();


        //Step 7: Scroll to the “Thông tin chi tiết”
        swipeMobileUptoElement(By.xpath("//android.widget.TextView[@text=\"Thông Tin Chi Tiết\"]"));
        //Step 8: Verify “Danh mục”, “Thương Hiệu”, “Nơi Sản Xuất” and “SKU” would be displayed.
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text=\"Danh mục\"]")));
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text=\"Thương hiệu\"]")));
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text=\"Xuất xứ thương hiệu\"]")));
//        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text=\"Xem Tất Cả\"]"))).click();

    }
    public void swipe(int startx, int starty, int endx, int endy) {
        new TouchAction(androidDriver).longPress(PointOption.point(startx, starty))
                .moveTo(PointOption.point(endx, endy))
                .release().perform();
    }
    public void swipeMobileUptoElement(By by) {
        boolean check=false;
        Dimension size = androidDriver.manage().window().getSize();
        int starty = (int) (size.height * 0.8);
        int endy = (int) (size.height * 0.2);
        int startx = 136;
        try{
            check=androidDriver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx,starty,startx,endy);
            try{
                check=androidDriver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
    public void swipeMobileUptoElementLeftMenu(By by) {
        boolean check=false;
        Dimension size = androidDriver.manage().window().getSize();
        int starty = (int) (size.height * 0.8);
        int endy = (int) (size.height * 0.2);
        int startx = 136;
        try{
            check=androidDriver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx,starty,startx,endy);
            try{
                check=androidDriver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
    public void swipeMobileDownToElement(By by) {
        boolean check=false;
        Dimension size = androidDriver.manage().window().getSize();
        int starty = (int) (size.height * 0.8);
        int endy = (int) (size.height * 0.2);
        int startx = size.width / 2;
        try{
            check=androidDriver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx, endy, startx, starty);
            try{
                check=androidDriver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
}
