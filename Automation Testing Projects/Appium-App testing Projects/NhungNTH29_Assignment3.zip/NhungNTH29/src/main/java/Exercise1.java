import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Exercise1 {
    AndroidDriver androidDriver;
    @Test
    public void test() throws MalformedURLException, InterruptedException {
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","R58M72M45JV");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability("appium:appPackage","vn.tiki.app.tikiandroid");
        desiredCapabilities.setCapability("appium:appActivity","vn.tiki.android.shopping.homeV3.HomeActivity");
        androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        WebDriverWait webDriverWait=new WebDriverWait(androidDriver,Duration.ofSeconds(30));
        //Step 2: Click menu bar
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("vn.tiki.app.tikiandroid.homeV3:id/image"))).click();
        //Step 3: Click Danh Muc San Pham (không có Danh mục sản phẩm)
        //Step 4: Click Thời Trang (Không có Thời Trang)
        //Step 5: Scroll to panel “Moi nhat” and click “Xem tat ca”
        //Step 6: In the panel “Thời Trang”, click to “Phụ kiện thời trang”
        swipeMobileUptoElement(By.xpath("//android.widget.TextView[contains(@text,\"Phụ kiện thời trang\")]"));
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[contains(@text,\"Phụ kiện thời trang\")]"))).click();
        try{
            webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("com.android.packageinstaller:id/permission_allow_button"))).click();
        }catch (Exception e){
        }
        //Step 7: In the panel “Phụ kiện thời trang” click to “Trang sức” (Không có trang sức)
        //Step 8: In the panel “Trang sức” click to “Trang sức bạc”
        //Thay thế => Click "Phụ kiện thời trang nữ"
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[contains(@text,\"Phụ kiện thời trang nữ\")]"))).click();
        //Step 9: Click first the product
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//android.view.ViewGroup[@resource-id=\"vn.tiki.app.tikiandroid:id/product_badges_container\"])[1]"))).click();
        // and verify the product name, product price would be displayed.
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("vn.tiki.app.tikiandroid.productDetail2:id/image")));
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@content-desc=\"pdp_product_name\"]")));
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("vn.tiki.app.tikiandroid.productDetail2:id/tvPrice")));
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.id("vn.tiki.app.tikiandroid.productDetail2:id/pdp3_main_cta_title")));
    }
    public void swipe(int startx, int starty, int endx, int endy) {
        new TouchAction(androidDriver).longPress(PointOption.point(startx, starty))
                .moveTo(PointOption.point(endx, endy))
                .release().perform();
    }
    public void swipeMobileUptoElement(By by) {
        boolean check=false;
        Dimension size = androidDriver.manage().window().getSize();
        int starty = (int) (size.height * 0.8);
        int endy = (int) (size.height * 0.2);
        int startx = size.width / 2;
        try{
            check=androidDriver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx,starty,startx,endy);
            try{
                check=androidDriver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
}
