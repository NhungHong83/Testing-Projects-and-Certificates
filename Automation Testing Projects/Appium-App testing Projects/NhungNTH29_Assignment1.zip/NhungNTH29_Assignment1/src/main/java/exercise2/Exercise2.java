package exercise2;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Exercise2 {
    @Test
    public void test() throws MalformedURLException {
        //Step 1: Open ShopStyle Fashion Cash Back app.
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","emulator-5554");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability("appium:appPackage","com.shopstyle");
        desiredCapabilities.setCapability("appium:appActivity","com.shopstyle.activity.HomeActivity");
        AndroidDriver androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        androidDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        //Step 2: Click to the “Skip” button.
        WebElement skip= androidDriver.findElement(By.id("com.shopstyle:id/skipText"));
        skip.click();
        //Step 3: Click to the “Shop Women's Fashion”.
        WebElement femaleFashion= androidDriver.findElement(By.id("com.shopstyle:id/btnFemale"));
        femaleFashion.click();
        //Step 4: Click to the Menu icon on top.
        //Step 5: Click to the setting
        WebElement setting= androidDriver.findElement(By.id("com.shopstyle:id/toolbarSettings"));
        setting.click();
        //Step 6: Verify the Account, Preferences should be displayed.
        WebElement account= androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@text,\"ACCOUNT\")]"));
        System.out.println(account.getText());
        WebElement preferences= androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@text,\"PREFERENCES\")]"));
        System.out.println(preferences.getText());

    }
}
