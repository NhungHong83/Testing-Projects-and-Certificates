package exercise1;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Exercise1 {
    @Test
    public void test() throws MalformedURLException {
        //Step 1: Open ShopStyle Fashion Cash Back app.
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","emulator-5554");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability("appium:appPackage","com.shopstyle");
        desiredCapabilities.setCapability("appium:appActivity","com.shopstyle.activity.HomeActivity");
        AndroidDriver androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        androidDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        //Step 2: Click to the “Skip” button.
        WebElement skip= androidDriver.findElement(By.id("com.shopstyle:id/skipText"));
        skip.click();
        //Step 3: Click to the “Shop Men's Fashion”.
        WebElement shopMenFashion= androidDriver.findElement(By.id("com.shopstyle:id/btnMale"));
        shopMenFashion.click();
        //Step 4: Click to the “Categories”.
        WebElement categories= androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@text,\"CATEGOR\")]"));
        categories.click();
        //Step 5: Click to the “Bags”.
        WebElement bags= androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@text,\"Bags\")]"));
        bags.click();
        //Step 6: Click to the “Backpacks”.
        WebElement backpacks= androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@text,\"Backpacks\")]"));
        backpacks.click();
        //Step 7: Click to the first item
        WebElement firstProduct= androidDriver.findElement(By.id("com.shopstyle:id/productCardLayout"));
        firstProduct.click();
        //Step 8: Verify product price and product name should be displayed.
        WebElement productPrice= androidDriver.findElement(By.id("com.shopstyle:id/sale_price"));
        System.out.println(productPrice.getText());
        WebElement productName= androidDriver.findElement(By.id("com.shopstyle:id/productBrand"));
        System.out.println(productName.getText());
    }
}
