package exercise3;

import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Exercise3 {
    @Test
    public void test() throws MalformedURLException {
        //Step 1: Open ShopStyle Fashion Cash Back app.
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","emulator-5554");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability("appium:appPackage","com.shopstyle");
        desiredCapabilities.setCapability("appium:appActivity","com.shopstyle.activity.HomeActivity");
        AndroidDriver androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        androidDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));
        //Step 2: Click to the “Skip” button.
        WebElement skip= androidDriver.findElement(By.id("com.shopstyle:id/skipText"));
        skip.click();
        //Step 3: Click to the “Shop Women's Fashion”.
        WebElement femaleFashion= androidDriver.findElement(By.id("com.shopstyle:id/btnFemale"));
        femaleFashion.click();
        //Step 4: Click to the “My Brands”
        WebElement myBrands= androidDriver.findElement(By.id("com.shopstyle:id/bottom_bar_brands"));
        myBrands.click();
        //Step 5: Click to the Manage My Brands
        WebElement manageMyBrands= androidDriver.findElement(By.id("com.shopstyle:id/btnMyBrands"));
        manageMyBrands.click();
        //Step 6: Verify My Brands and All Brands should be displayed.
        WebElement myBrandsList= androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@text,\"MY BRANDS\")]"));
        System.out.println(myBrandsList.getText());
        WebElement allBrands= androidDriver.findElement(By.xpath("//android.widget.TextView[contains(@text,\"ALL BRANDS\")]"));
        System.out.println(allBrands.getText());

    }
}
