package stepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyStepdefs_ex2 {
    @Given("the user navigates to the Google home page")
    public void theUserNavigatesToTheGoogleHomePage() {
        
    }

    @When("the user entered {string} at the search bar")
    public void theUserEnteredAtTheSearchBar(String arg0) {
        
    }

    @Then("the results page shows links related to {string}")
    public void theResultsPageShowsLinksRelatedTo(String arg0) {
        
    }

    @And("image links for {string}")
    public void imageLinksFor(String arg0) {
        
    }

    @And("video links for {string}")
    public void videoLinksFor(String arg0) {
        
    }

    @Given("a web browser is on the Google page")
    public void aWebBrowserIsOnTheGooglePage() {
        
    }

    @When("the search phrase {string} is entered")
    public void theSearchPhraseIsEntered(String arg0) {
        
    }

    @Then("results for {string} are shown")
    public void resultsForAreShown(String arg0) {
        
    }

    @And("the following related results are shown")
    public void theFollowingRelatedResultsAreShown() {
        
    }

    @Given("a level is started")
    public void aLevelIsStarted() {
        
    }

    @When("the player pushes the {string} button Or the player pushes the {string} button")
    public void thePlayerPushesTheButtonOrThePlayerPushesTheButton(String arg0, String arg1) {
        
    }

    @Then("Mario jumps straight up")
    public void marioJumpsStraightUp() {
        
    }

    @When("the player pushes the {string} button")
    public void thePlayerPushesTheButton(String arg0) {
    }
}
