package stepDef;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class MyStepdefs_ex1 {
    @Given("Web browser opens successfully")
    public void webBrowserOpensSuccessfully() {
        
    }

    @When("Navigate to https://www.google.com/")
    public void navigateToHttpsWwwGoogleCom() {
        
    }

    @Then("The web page loaded successfully and the Google image displayed.")
    public void theWebPageLoadedSuccessfullyAndTheGoogleImageDisplayed() {
        
    }


    @When("Enter “panda” in the search bar")
    public void enterPandaInTheSearchBar() {
        
    }

    @Then("Links related to “panda” was shown on the results page")
    public void linksRelatedToPandaWasShownOnTheResultsPage() {
        
    }

    @When("Click on the “Images” link at the top of the results page")
    public void clickOnTheImagesLinkAtTheTopOfTheResultsPage() {
        
    }

    @Then("Images related to “panda” was shown on the results page.")
    public void imagesRelatedToPandaWasShownOnTheResultsPage() {
    }
}
