import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

public class Exercise2 {
    AndroidDriver androidDriver;
    @Test
    public void test() throws MalformedURLException, InterruptedException {
        //Import hết các DesiredCapabilities vào ( copy từ appium vào)
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","R58M72M45JV");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability(CapabilityType.BROWSER_NAME,"Chrome");
        androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        WebDriverWait webDriverWait=new WebDriverWait(androidDriver,Duration.ofSeconds(30));
        androidDriver.get("https://www.google.com");
        androidDriver.navigate().to("http://shopee.vn");
//        Thread.sleep(3000);
////        androidDriver.context("Shopee Việt Nam | Mua và Bán Trên Ứng Dụng Di Động Hoặc Website (WEBVIEW_chrome)");
        webDriverWait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@class=\"app-container\"]"))).click();
        rightLeftSwipe(By.xpath("(//div[text()=\"Shopee Mall\"]//..)[1]"));
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[text()=\"Shopee Mall\"]//..)[1]"))).click();


//        searchBox.sendKeys("Appium for mobile automation");
//        searchBox.sendKeys(Keys.ENTER);

//        androidDriver.close();
    }
    public void rightLeftSwipe(By by) {
        boolean check=false;
        Dimension size = androidDriver.manage().window().getSize();
        int startx = (int) 973;
        int endx = (int) 90;
        int starty = 1000;
        try{
            check=androidDriver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx,starty,endx,starty);
            try{
                check=androidDriver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
    public void swipe(int startx, int starty, int endx, int endy) {
        new TouchAction(androidDriver).longPress(PointOption.point(startx, starty))
                .moveTo(PointOption.point(endx, endy))
                .release().perform();
    }
}
