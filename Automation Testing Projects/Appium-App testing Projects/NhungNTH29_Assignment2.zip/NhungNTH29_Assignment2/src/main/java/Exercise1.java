import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import static org.testng.Assert.assertEquals;

public class Exercise1 {
    AndroidDriver androidDriver;
    @Test
    public void test() throws MalformedURLException, InterruptedException {
        //Import hết các DesiredCapabilities vào ( copy từ appium vào)
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","R58M72M45JV");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability(CapabilityType.BROWSER_NAME,"Chrome");
        androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        WebDriverWait webDriverWait=new WebDriverWait(androidDriver,Duration.ofSeconds(30));
        androidDriver.get("https://www.google.com");
        WebElement searchBox = androidDriver.findElement(By.name("q"));
        searchBox.sendKeys("appium testing");
        searchBox.sendKeys(Keys.ENTER);
        webDriverWait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("(//div[@class=\"oewGkc LeUQr CCgQ5 MUxGbd v0nnCb lEBKkf\"])[1]"))).click();
//        androidDriver.findElement(By.xpath("(//div[@class=\"oewGkc LeUQr CCgQ5 MUxGbd v0nnCb lEBKkf\"])[1]")).click();
        System.out.println(androidDriver.getTitle());
        assertEquals("“Appium: Mobile App Automation Made Awesome.",androidDriver.getTitle());

//        androidDriver.close();
    }
}
