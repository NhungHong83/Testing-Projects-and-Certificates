import io.appium.java_client.android.AndroidDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import static org.testng.Assert.assertEquals;

public class Exercise3 {
    @Test
    public void test() throws MalformedURLException, InterruptedException {
        //Import hết các DesiredCapabilities vào ( copy từ appium vào)
        DesiredCapabilities desiredCapabilities=new DesiredCapabilities();
        desiredCapabilities.setCapability("appium:deviceName","Samsung");
        desiredCapabilities.setCapability("platformName","Android");
        desiredCapabilities.setCapability("appium:udid","R58M72M45JV");
        desiredCapabilities.setCapability("appium:automationName","UiAutomator2");
        desiredCapabilities.setCapability("appium:appPackage","com.example.hybridtestapp");
        desiredCapabilities.setCapability("appium:appActivity","com.example.hybridtestapp.MainActivity");
        AndroidDriver androidDriver=new AndroidDriver(new URL("http://localhost:4723/wd/hub"),desiredCapabilities);
        androidDriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(30));

        try{
            WebElement continuee= androidDriver.findElement(By.id("com.android.permissioncontroller:id/continue_button"));
            continuee.click();
            WebElement okBtn= androidDriver.findElement(By.id("android:id/button1"));
            okBtn.click();
        }catch (Exception e){

        }

        Thread.sleep(3000);
        androidDriver.context("WEBVIEW_com.example.hybridtestapp");


        String firstName="Nguyen";
        WebElement fname= androidDriver.findElement(By.name("fname"));
        fname.sendKeys(firstName);
        WebElement lname= androidDriver.findElement(By.name("lname"));
        lname.sendKeys("Nhung");
        WebElement age= androidDriver.findElement(By.name("age"));
        age.sendKeys("22");
        WebElement username= androidDriver.findElement(By.name("username"));
        username.sendKeys("NhungNTH29");
        WebElement pass= androidDriver.findElement(By.xpath("//input[@id=\"psw\"]"));
        pass.sendKeys("123456");
        androidDriver.findElement(By.xpath("//input[@id=\"register\"]")).click();
        WebElement message= androidDriver.findElement(By.xpath("//body"));
        System.out.println(message.getText());
        String[] words=message.getText().split("\\s");
        boolean checkExist=false;
        for(String w:words){
            if(w.trim().equals(firstName)){
                checkExist=true;
            }
        }
        assertEquals(checkExist,true);
//        androidDriver.close();
    }
}
