package stepDef;

import Page.*;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

import static org.testng.Assert.assertEquals;

public class MyStepdefs {
    LoginPage loginPage=new LoginPage();
    HomePage homePage=new HomePage();
    HomeDecorPage homeDecorPage=new HomeDecorPage();
    CartPage cartPage=new CartPage();
    ProductDetailPage productDetailPage=new ProductDetailPage();
    @Given("Open Banggood Easy Online Shopping App successfull")
    public void openBanggoodEasyOnlineShoppingAppSuccessfull() {
        assertEquals(homePage.isOpenSuccessful(),true);
    }

    @When("Click to the Category on footer menu")
    public void clickToTheCategoryOnFooterMenu() {
        homePage.clickToTheCategoryOnFooterMenu();
    }

    @And("Scroll and click to Home and Garden in Left menu")
    public void scrollAndClickToHomeAndGardenInLeftMenu() {
        homePage.scrollAndClickHome_Garden();
    }
    @And("After the right category displayed, click to the Home Decor")
    public void afterTheRightCategoryDisplayedClickToTheHomeDecor() {
        homePage.click_HomeDecor();
    }


    @And("Click to the Filter and input price from 20 to 30")
    public void clickToTheFilterAndInputPrice() {
        homeDecorPage.clickFilter_InputPrice();
    }

    @And("Click Done")
    public void clickDone() {
        homeDecorPage.clickDone();
    }

    @And("Click first product")
    public void clickFirstProduct() {
        homeDecorPage.clickFirstProduct();
    }

    @Then("Product name displayed and product price in range 20 to 30.")
    public void productNameDisplayedAndProductPriceInRangeTo() {
        productDetailPage.verifyProduct();
    }

    @When("At the Home screen, scroll to Hot Categories")
    public void atTheHomeScreenScrollToHotCategories() {
        homePage.scrollToHotCategories();
    }


    @And("Click to the first category")
    public void clickToTheFirstCategory() {
        homePage.clickfirstHotCategory();
    }

    @And("Click to the first product")
    public void clickToTheFirstProduct() {
        homePage.clickfirstHotProduct();
    }

    @Then("The product detail page displayed: Product name, product price, Buy now button and Add to Cart button")
    public void theProductDetailPageDisplayedProductNameProductPriceBuyNowButtonAndAddToCartButton() {
        productDetailPage.verifyHotProduct();
    }

    @When("Click Add to cart")
    public void clickAddToCart() {
        productDetailPage.addToCart();
    }

    @And("Click to Add to cart button")
    public void clickToAddToCartButton() {
        productDetailPage.addToCart();
    }

    @And("Click to Cart icon on footer")
    public void clickToCartIconOnFooter() {
        productDetailPage.clickCartIcon();
    }

    @Then("Product name, Product size, Product price and quantity displayed.")
    public void productNameProductSizeProductPriceAndQuantityDisplayed() {
        cartPage.verifyProductInCart();
    }


    @When("Click Account on footer menu")
    public void clickAccountOnFooterMenu() {
        homePage.clickAccount();

    }

    @And("Click View All Order")
    public void clickViewAllOrder() {
        homePage.clickViewAllOrder();
    }

    @Then("Login screen displayed with: Email, password and SignIn button")
    public void loginScreenDisplayedWithEmailPasswordAndSignInButton() {
        loginPage.verifyLoginPage();

    }
}
