package Page;

import Core.AppiumBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

import static org.testng.Assert.assertEquals;

public class ProductDetailPage extends AppiumBase {
    public ProductDetailPage() {
        PageFactory.initElements(getDriver(), this);
    }

    @FindBy(id = "com.banggood.client:id/tv_product_name")
    private WebElement productName;
    @FindBy(id = "com.banggood.client:id/btn_slide_buy")
    private WebElement buyNowButton;
    @FindBy(id = "com.banggood.client:id/btn_slide_cart")
    private WebElement addToCartButton;
    @FindBy(id = "com.banggood.client:id/tv_product_price")
    private WebElement productPrice;
    @FindBy(id = "com.banggood.client:id/menu_cart_icon")
    private WebElement cartIcon;
    public void verifyProduct(){
         webDriverWait.until(ExpectedConditions.visibilityOf(productName));
        String[] arrOfStr = productPrice.getText().split("₫", 2);
        assertEquals(Integer.valueOf(arrOfStr[0])<30 && Integer.valueOf(arrOfStr[0])>20,true);
    }
    public void verifyHotProduct(){
        webDriverWait.until(ExpectedConditions.visibilityOf(productName));
        webDriverWait.until(ExpectedConditions.visibilityOf(productPrice));
        webDriverWait.until(ExpectedConditions.visibilityOf(buyNowButton));
        webDriverWait.until(ExpectedConditions.visibilityOf(addToCartButton));
    }
    public void addToCart(){
        webDriverWait.until(ExpectedConditions.visibilityOf(addToCartButton)).click();
    }
    public void clickCartIcon(){
        webDriverWait.until(ExpectedConditions.visibilityOf(cartIcon)).click();
    }
}
