package Page;

import Core.AppiumBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CartPage extends AppiumBase {
    public CartPage() {
        PageFactory.initElements(getDriver(), this);
    }
    @FindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_name\"])[1]")
    private WebElement productName;
    @FindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_price\"])[1]")
    private WebElement productPrice;
    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_options\"]")
    private WebElement productSize;
    @FindBy(id = "com.banggood.client:id/edit_qty")
    private WebElement productQty;
    public void verifyProductInCart(){
        webDriverWait.until(ExpectedConditions.visibilityOf(productName));
        webDriverWait.until(ExpectedConditions.visibilityOf(productPrice));
        webDriverWait.until(ExpectedConditions.visibilityOf(productSize));
        webDriverWait.until(ExpectedConditions.visibilityOf(productQty));
    }

}
