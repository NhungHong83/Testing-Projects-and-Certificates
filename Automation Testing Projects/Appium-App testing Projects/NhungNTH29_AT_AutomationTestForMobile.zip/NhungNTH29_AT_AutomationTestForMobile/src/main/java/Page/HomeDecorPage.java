package Page;

import Core.AppiumBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomeDecorPage extends AppiumBase {
    public HomeDecorPage() {
        PageFactory.initElements(getDriver(), this);
    }
    @FindBy(id = "com.banggood.client:id/slide_filter_entry")
    private WebElement filter;
    @FindBy(id = "com.banggood.client:id/edit_price_max")
    private WebElement priceMax;
    @FindBy(id = "com.banggood.client:id/edit_price_min")
    private WebElement priceMin;
    @FindBy(id = "com.banggood.client:id/btn_done")
    private WebElement lamXongButton;
//    @FindBy(xpath = "(//android.view.ViewGroup)[7]")
    @FindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_name\"])[1]")
    private WebElement firstProduct;


    public void clickFilter_InputPrice(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(filter)).click();
        webDriverWait.until(ExpectedConditions.visibilityOf(priceMin)).sendKeys("20");
        webDriverWait.until(ExpectedConditions.visibilityOf(priceMax)).sendKeys("30");
    }
    public void clickDone(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(lamXongButton)).click();
    }
    public void clickFirstProduct(){
        webDriverWait.until(ExpectedConditions.visibilityOf(firstProduct));
        webDriverWait.until(ExpectedConditions.elementToBeClickable(firstProduct)).click();
    }
}
