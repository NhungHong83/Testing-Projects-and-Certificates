package Page;

import Core.AppiumBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends AppiumBase {
    public LoginPage() {
        PageFactory.initElements(getDriver(), this);
    }
    @FindBy(id = "com.banggood.client:id/et_email")
    private WebElement email;
    @FindBy(id = "com.banggood.client:id/et_pwd")
    private WebElement pass;
    @FindBy(id = "com.banggood.client:id/btn_sign_in")
    private WebElement signinButton;

    public void verifyLoginPage(){
        webDriverWait.until(ExpectedConditions.visibilityOf(email));
        webDriverWait.until(ExpectedConditions.visibilityOf(pass));
        webDriverWait.until(ExpectedConditions.visibilityOf(signinButton));

    }
}
