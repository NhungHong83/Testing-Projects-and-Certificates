package Page;

import Core.AppiumBase;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends AppiumBase {

    public HomePage() {
        PageFactory.initElements(getDriver(), this);
    }

    @FindBy(id = "com.banggood.client:id/search_box_view")
    private WebElement searchBoxHomePage;
//    @FindBy(xpath = "//android.widget.TextView[@text=\"thể loại\"]")

    @FindBy(id = "com.banggood.client:id/main_tab_category")
    private WebElement theLoai;
    @FindBy(id = "com.banggood.client:id/main_tab_account")
    private WebElement account;
    @FindBy(id = "com.banggood.client:id/tv_view_all")
    private WebElement viewAllOrder;

    @FindBy(xpath = "//android.widget.TextView[@text=\"Nhà và vườn\"]//..")
//    @FindBy(xpath = "(//android.widget.LinearLayout)[14]")
    private WebElement nhaVaVuon;
//    @FindBy(xpath = "//android.widget.TextView[@text=\"Trang trí nhà\"]//..")
    @FindBy(xpath = "(//android.widget.LinearLayout[@resource-id=\"com.banggood.client:id/ll_category_title\"])[4]")
    private WebElement trangTriNha;

    @FindBy(xpath = "//android.widget.TextView[@text=\"Thể loại hot\"]")
    private WebElement theLoaiHot;
    @FindBy(xpath = "(//android.widget.ImageView[@resource-id=\"com.banggood.client:id/iv_product\"])[8]")
    private WebElement firstHotCate;
    @FindBy(xpath = "(//android.widget.TextView[@resource-id=\"com.banggood.client:id/tv_product_name\"])[1]")
    private WebElement firstHotProduct;
    public void clickAccount(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(account)).click();
    }
    public void clickViewAllOrder(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(viewAllOrder)).click();
    }
public void scrollToHotCategories(){
    swipeMobileUptoElement(By.xpath("//android.widget.TextView[@text=\"Thể loại hot\"]"),2);
}
    public void clickfirstHotCategory(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(firstHotCate)).click();
    }
    public void clickfirstHotProduct(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(firstHotProduct)).click();
    }
    public boolean isOpenSuccessful(){
        WebElement e=webDriverWait.until(ExpectedConditions.visibilityOf(searchBoxHomePage));
        return e.isDisplayed();
    }
    public void clickToTheCategoryOnFooterMenu(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(theLoai)).click();
    }
    public void scrollAndClickHome_Garden(){
        try{
            swipeMobileUptoElement(By.xpath("//android.widget.TextView[@text=\"Nhà và vườn\"]//.."),10);
        }catch (Exception e){}

        webDriverWait.until(ExpectedConditions.elementToBeClickable(nhaVaVuon)).click();
    }
    public void click_HomeDecor(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(trangTriNha)).click();
    }

    public void swipe(int startx, int starty, int endx, int endy) {
        new TouchAction(driver).longPress(PointOption.point(startx, starty))
                .moveTo(PointOption.point(endx, endy))
                .release().perform();
    }
    public void swipeMobileUptoElement(By by, int rateWidth) {
        boolean check=false;
        Dimension size = driver.manage().window().getSize();
        int starty = (int) (size.height * 0.8);
        int endy = (int) (size.height * 0.2);
        int startx = size.width / rateWidth;
        try{
            check=driver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx,starty,startx,endy);
            try{
                check=driver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
    public void rightLeftSwipeToElement(By by) {
        boolean check=false;
        Dimension size = driver.manage().window().getSize();
        int startx = (int) (size.width * 0.90);
        int endx = (int) (size.width * 0.10);
        int starty = size.height / 2;
        try{
            check=driver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx, starty, endx, starty);
            try{
                check=driver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
}
