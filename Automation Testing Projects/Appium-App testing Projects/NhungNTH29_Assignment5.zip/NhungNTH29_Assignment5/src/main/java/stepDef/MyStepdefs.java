package stepDef;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import pages.CategoryPage;
import pages.HomePage;
import pages.ProductDetailPage;

public class MyStepdefs {
    HomePage homePage=new HomePage();
    CategoryPage categoryPage=new CategoryPage();
    ProductDetailPage productDetailPage=new ProductDetailPage();
    @Given("Open Tiki App successfully")
    public void openTikiAppSuccessfully() {
        homePage.displayedTikiApp();
    }

    @When("Click menu bar")
    public void clickMenuBar() {
        homePage.clickMenuBar();
    }

    @And("Click Danh Muc San Pham")
    public void clickDanhMucSanPham() {
    }

    @And("Click Laptop – May Vi Tinh")
    public void clickLaptopMayViTinh() {
        categoryPage.clickLaptop_Mayvitinh();
    }

    @And("Scroll to panel “Moi nhat” and click “Xem tat ca”")
    public void scrollToPanelMoiNhatAndClickXemTatCa() {
        categoryPage.scrollToPanelMoiNhatAndClickXemTatCa();
    }

    @And("Click first the product")
    public void clickFirstTheProduct() {
        categoryPage.clickFirstProduct();
    }


    @Then("Product name, product price displayed")
    public void productNameProductPriceDisplayed() {
        productDetailPage.verifyProduct();
    }

    @And("Click Thời Trang")
    public void clickThoiTrang() {
        categoryPage.clickThoiTrangNam();
    }

    @And("Close popup")
    public void closePopup() {
//        categoryPage.closePopup();
    }

    @And("Scroll to panel “Moi nhat” and click “Xem tat ca” của mục Thời Trang")
    public void scrollToPanelMoiNhatAndClickXemTatCaCuaMucThoiTrang() {

    }

    @And("In the panel “Thời Trang”, click to “Phụ kiện thời trang”")
    public void inThePanelThoiTrangClickToPhuKienThoiTrang() {
    categoryPage.clickPhuKienThoiTrang();
    }

    @And("In the panel “Phụ kiện thời trang” click to “Trang sức”")
    public void inThePanelPhuKienThoiTrangClickToTrangSuc() {

    }

    @And("In the panel “Trang sức” click to “Trang sức bạc”")
    public void inThePanelTrangSucClickToTrangSucBac() {
        categoryPage.clickToTrangSucBac();
    }

    @And("Click first the product of “Trang sức bạc”")
    public void clickFirstTheProductOfTrangSucBac() {
        categoryPage.clickFirstTheProductOfTrangSucBac();
    }

}
