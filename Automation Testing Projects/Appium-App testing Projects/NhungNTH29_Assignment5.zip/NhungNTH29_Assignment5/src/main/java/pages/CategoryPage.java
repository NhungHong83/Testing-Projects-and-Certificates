package pages;

import core.AppiumBase;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CategoryPage  extends AppiumBase {
    public CategoryPage() {
        PageFactory.initElements(getDriver(), this);
    }
    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvContent\"][contains(@text,\"Laptop - Máy Vi Tính - Linh kiện\")]")
    private WebElement laptop_mayvitinhMenu;
    @FindBy(xpath = "//android.widget.TextView[@text=\"Thiết Bị Lưu Trữ\"]")
    private WebElement thietBiLuuTru;
    @FindBy(id = "vn.tiki.app.tikiandroid.category2:id/tvAll")
    private WebElement xemTatCaButton;
    @FindBy(xpath = "(//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvAll\"])[1]")
    private WebElement tatCaMatKinhNuButton;
    @FindBy(xpath = "(//android.view.ViewGroup[@resource-id=\"vn.tiki.app.tikiandroid:id/product_badges_container\"])[1]")
    private WebElement firstProduct;


    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvContent\"][contains(@text,\"Phụ kiện thời trang\")]")
    private WebElement phuKienThoiTrang;
    @FindBy(xpath = "//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvContent\"][contains(@text,\"Thời trang nam\")]")
    private WebElement thoiTrangNam;
    public void clickThoiTrangNam(){
        //Khong co muc Thời trang=> click Thời trang nam
        swipeMobileUptoElement(By.xpath("//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvContent\"][contains(@text,\"Thời trang nam\")]"),10);
        webDriverWait.until(ExpectedConditions.elementToBeClickable(thoiTrangNam)).click();
    }
    public void clickPhuKienThoiTrang(){
        swipeMobileUptoElement(By.xpath("//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvContent\"][contains(@text,\"Phụ kiện thời trang\")]"),10);
        webDriverWait.until(ExpectedConditions.elementToBeClickable(phuKienThoiTrang)).click();
    }
    public void clickToTrangSucBac(){
        //Khong co muc TrangSucBac=> click Mắt kính
        webDriverWait.until(ExpectedConditions.elementToBeClickable(tatCaMatKinhNuButton)).click();
        try{
            driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();
        }catch (Exception e){
        }
    }
    public void clickFirstTheProductOfTrangSucBac(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(firstProduct)).click();
    }

    public void clickLaptop_Mayvitinh(){
        swipeMobileUptoElement(By.xpath("//android.widget.TextView[@resource-id=\"vn.tiki.app.tikiandroid.category2:id/tvContent\"][contains(@text,\"Laptop - Máy Vi Tính - Linh kiện\")]"),10);
        webDriverWait.until(ExpectedConditions.elementToBeClickable(laptop_mayvitinhMenu)).click();
    }
    public void scrollToPanelMoiNhatAndClickXemTatCa(){
        //Khong co muc Moi nhat=> scroll to "Thiet bi luu tru"
        swipeMobileUptoElement(By.xpath("//android.widget.TextView[@text=\"Thiết Bị Lưu Trữ\"]"),2);
        webDriverWait.until(ExpectedConditions.elementToBeClickable(xemTatCaButton)).click();
        try{
            driver.findElement(By.id("com.android.packageinstaller:id/permission_allow_button")).click();
        }catch (Exception e){
        }
    }

    public void clickFirstProduct(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(firstProduct)).click();
    }


    public void swipe(int startx, int starty, int endx, int endy) {
        new TouchAction(driver).longPress(PointOption.point(startx, starty))
                .moveTo(PointOption.point(endx, endy))
                .release().perform();
    }
    public void swipeMobileUptoElement(By by, int rateWidth) {
        boolean check=false;
        Dimension size = driver.manage().window().getSize();
        int starty = (int) (size.height * 0.8);
        int endy = (int) (size.height * 0.2);
        int startx = size.width / rateWidth;
//        int startx=136;
        System.out.println(size+"   "+startx);

        try{
            check=driver.findElement(by).isDisplayed();
        }catch (Exception e){}
        while (!check){
            swipe(startx,starty,startx,endy);
            try{
                check=driver.findElement(by).isDisplayed();
            }catch (Exception e){}
        }
    }
}
