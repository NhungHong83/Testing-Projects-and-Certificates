package pages;

import core.AppiumBase;
import io.appium.java_client.TouchAction;
import io.appium.java_client.touch.offset.PointOption;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class HomePage extends AppiumBase {

    public HomePage() {
        PageFactory.initElements(getDriver(), this);
    }

    @FindBy(id = "vn.tiki.app.tikiandroid.homeV3:id/image")
    private WebElement menuBar;




    public void displayedTikiApp(){
        webDriverWait.until(ExpectedConditions.visibilityOf(menuBar));
    }
    public void clickMenuBar(){
        webDriverWait.until(ExpectedConditions.elementToBeClickable(menuBar)).click();
    }




}
