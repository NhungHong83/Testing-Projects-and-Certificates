package pages;

import core.AppiumBase;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class ProductDetailPage extends AppiumBase {
    public ProductDetailPage() {
        PageFactory.initElements(getDriver(), this);
    }

    @FindBy(xpath = "//android.widget.TextView[@content-desc=\"pdp_product_name\"]")
    private WebElement productName;
    @FindBy(id = "vn.tiki.app.tikiandroid.productDetail2:id/tvPrice")
    private WebElement productPrice;

    public void verifyProduct(){
        webDriverWait.until(ExpectedConditions.visibilityOf(productName));
        webDriverWait.until(ExpectedConditions.visibilityOf(productPrice));
    }
}
