import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.FeatureWrapper;
import io.cucumber.testng.PickleWrapper;
import io.cucumber.testng.TestNGCucumberRunner;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

@CucumberOptions(
        features = "src/main/resources/tiki.feature",
        glue = "stepDef",
        tags = "@EX2"
)
public class Runner {
    private TestNGCucumberRunner testNGCucumberRunner;

    @BeforeClass
    public void before(){
        testNGCucumberRunner = new TestNGCucumberRunner(this.getClass());
    }

    @Test(dataProvider = "getScenario")
    public void runnerScenario(PickleWrapper pickleWrapper, FeatureWrapper featureWrapper){
        testNGCucumberRunner.runScenario(pickleWrapper.getPickle());
    }
    @DataProvider
    public Object[][] getScenario(){
        return testNGCucumberRunner.provideScenarios();
    }

    @AfterClass
    public void after(){
        testNGCucumberRunner.finish();
    }
}
